/**
 * =========================================================================================
 *  HARİTA TOOL / GNSS POS WEB STUDIO - İHA & FOTOGRAMETRİ SENSÖR VERİTABANI (DroneDatabase)
 * =========================================================================================
 *  - Profesyonel Fotogrametri İHA Platformları (DJI Matrice, Mavic 3E/T/M, Phantom 4 RTK, Trinity Pro vb.)
 *  - Metrik Kamera & LiDAR Sensör Parametreleri (Sensör Boyutları, Odak Uzaklığı, Çözünürlük, Deklanşör)
 *  - Dinamik Harici JSON Yükleme & Otomatik UI Senkronizasyonu
 * =========================================================================================
 */

const DEFAULT_DRONE_DATABASE = {
  drones: [
    {
      id: "dji_m400_heavy",
      brand: "DJI",
      model: "DJI Matrice 400",
      maxFlightTimeMin: 50,
      safeFlightTimeMin: 35,
      defaultSpeedMs: 16,
      maxSpeedMs: 25,
      maxSpeedKmh: 90.0,
      windResistanceMs: 15,
      supportedPayloads: ["zen_p1_35", "zen_p1_24", "zen_p1_50", "zen_l2", "zen_l3", "zen_h30", "zen_h30t", "sony_ilx_lr1"],
      sportMaxSpeedMs: 25,
      minSpeedMs: 2
    },
    {
      id: "dji_m4e",
      brand: "DJI",
      model: "DJI Matrice 4 Enterprise",
      maxFlightTimeMin: 47,
      safeFlightTimeMin: 34,
      defaultSpeedMs: 15,
      maxSpeedMs: 21,
      maxSpeedKmh: 75.6,
      windResistanceMs: 12,
      supportedPayloads: ["m4e_built_in"],
      sportMaxSpeedMs: 21,
      minSpeedMs: 2
    },
    {
      id: "dji_m4t",
      brand: "DJI",
      model: "DJI Matrice 4 Thermal",
      maxFlightTimeMin: 47,
      safeFlightTimeMin: 32,
      defaultSpeedMs: 13,
      maxSpeedMs: 21,
      maxSpeedKmh: 75.6,
      windResistanceMs: 12,
      supportedPayloads: ["m4t_built_in"],
      sportMaxSpeedMs: 21,
      minSpeedMs: 2
    },
    {
      id: "dji_m350_rtk",
      brand: "DJI",
      model: "DJI Matrice 350 RTK",
      maxFlightTimeMin: 55,
      safeFlightTimeMin: 36,
      defaultSpeedMs: 13,
      maxSpeedMs: 15,
      maxSpeedKmh: 54.0,
      windResistanceMs: 12,
      supportedPayloads: ["zen_p1_35", "zen_p1_24", "zen_p1_50", "zen_l2", "zen_l1", "zen_h30", "zen_h30t", "sony_ilx_lr1"],
      sportMaxSpeedMs: 23,
      minSpeedMs: 2
    },
    {
      id: "dji_m300_rtk",
      brand: "DJI",
      model: "DJI Matrice 300 RTK",
      maxFlightTimeMin: 55,
      safeFlightTimeMin: 32,
      defaultSpeedMs: 12,
      maxSpeedMs: 15,
      maxSpeedKmh: 54.0,
      windResistanceMs: 12,
      supportedPayloads: ["zen_p1_35", "zen_p1_24", "zen_p1_50", "zen_l2", "zen_l1", "zen_h30", "zen_h30t"],
      sportMaxSpeedMs: 23,
      minSpeedMs: 2
    },
    {
      id: "dji_m30_series",
      brand: "DJI",
      model: "DJI Matrice 30",
      maxFlightTimeMin: 41,
      safeFlightTimeMin: 30,
      defaultSpeedMs: 12,
      maxSpeedMs: 15,
      maxSpeedKmh: 54.0,
      windResistanceMs: 15,
      supportedPayloads: ["m30_built_in"],
      sportMaxSpeedMs: 23,
      minSpeedMs: 2
    },
    {
      id: "dji_m30t_series",
      brand: "DJI",
      model: "DJI Matrice 30T",
      maxFlightTimeMin: 41,
      safeFlightTimeMin: 28,
      defaultSpeedMs: 11,
      maxSpeedMs: 15,
      maxSpeedKmh: 54.0,
      windResistanceMs: 15,
      supportedPayloads: ["m30t_built_in"],
      sportMaxSpeedMs: 23,
      minSpeedMs: 2
    },
    {
      id: "dji_m210_rtk",
      brand: "DJI",
      model: "DJI Matrice 210 RTK V2",
      maxFlightTimeMin: 33,
      safeFlightTimeMin: 24,
      defaultSpeedMs: 10,
      maxSpeedMs: 14,
      maxSpeedKmh: 50.4,
      windResistanceMs: 12,
      supportedPayloads: ["zen_p1_35", "zen_l1"],
      sportMaxSpeedMs: 22.6,
      minSpeedMs: 2
    },
    {
      id: "dji_m600_pro",
      brand: "DJI",
      model: "DJI Matrice 600 Pro",
      maxFlightTimeMin: 35,
      safeFlightTimeMin: 22,
      defaultSpeedMs: 8,
      maxSpeedMs: 12,
      maxSpeedKmh: 43.2,
      windResistanceMs: 8,
      supportedPayloads: ["zen_p1_35", "sony_ilx_lr1", "sony_rx1r2"],
      sportMaxSpeedMs: 18,
      minSpeedMs: 2
    },
    {
      id: "dji_m3e",
      brand: "DJI",
      model: "DJI Mavic 3 Enterprise",
      maxFlightTimeMin: 45,
      safeFlightTimeMin: 32,
      defaultSpeedMs: 13,
      maxSpeedMs: 15,
      maxSpeedKmh: 54.0,
      windResistanceMs: 12,
      supportedPayloads: ["m3e_built_in"],
      sportMaxSpeedMs: 21,
      minSpeedMs: 2
    },
    {
      id: "dji_m3t",
      brand: "DJI",
      model: "DJI Mavic 3 Thermal",
      maxFlightTimeMin: 45,
      safeFlightTimeMin: 30,
      defaultSpeedMs: 10,
      maxSpeedMs: 15,
      maxSpeedKmh: 54.0,
      windResistanceMs: 12,
      supportedPayloads: ["m3t_built_in"],
      sportMaxSpeedMs: 21,
      minSpeedMs: 2
    },
    {
      id: "dji_m3m",
      brand: "DJI",
      model: "DJI Mavic 3 Multispectral",
      maxFlightTimeMin: 43,
      safeFlightTimeMin: 30,
      defaultSpeedMs: 11,
      maxSpeedMs: 15,
      maxSpeedKmh: 54.0,
      windResistanceMs: 12,
      supportedPayloads: ["m3m_built_in"],
      sportMaxSpeedMs: 21,
      minSpeedMs: 2
    },
    {
      id: "dji_p4rtk",
      brand: "DJI",
      model: "DJI Phantom 4 RTK",
      maxFlightTimeMin: 30,
      safeFlightTimeMin: 22,
      defaultSpeedMs: 8,
      maxSpeedMs: 13.8,
      maxSpeedKmh: 49.7,
      windResistanceMs: 10,
      supportedPayloads: ["p4rtk_built_in"],
      sportMaxSpeedMs: 20,
      minSpeedMs: 2
    },
    {
      id: "dji_inspire3",
      brand: "DJI",
      model: "DJI Inspire 3",
      maxFlightTimeMin: 28,
      safeFlightTimeMin: 20,
      defaultSpeedMs: 13,
      maxSpeedMs: 15,
      maxSpeedKmh: 54.0,
      windResistanceMs: 14,
      supportedPayloads: ["zen_p1_35", "zen_p1_24", "zen_p1_50"],
      sportMaxSpeedMs: 26,
      minSpeedMs: 2
    },
    {
      id: "trinity_pro",
      brand: "Quantum Systems",
      model: "Quantum Systems Trinity Pro",
      maxFlightTimeMin: 90,
      safeFlightTimeMin: 75,
      defaultSpeedMs: 17,
      maxSpeedMs: 18,
      maxSpeedKmh: 64.8,
      windResistanceMs: 12,
      supportedPayloads: ["sony_ilx_lr1", "sony_rx1r2", "micasense_rededge_p"],
      sportMaxSpeedMs: 22,
      minSpeedMs: 13
    },
    {
      id: "trinity_f90",
      brand: "Quantum Systems",
      model: "Quantum Systems Trinity F90+",
      maxFlightTimeMin: 90,
      safeFlightTimeMin: 70,
      defaultSpeedMs: 17,
      maxSpeedMs: 18,
      maxSpeedKmh: 64.8,
      windResistanceMs: 12,
      supportedPayloads: ["sony_rx1r2", "micasense_rededge_p"],
      sportMaxSpeedMs: 22,
      minSpeedMs: 13
    },
    {
      id: "wingtra_one_gen2",
      brand: "Wingtra",
      model: "WingtraOne GEN II",
      maxFlightTimeMin: 59,
      safeFlightTimeMin: 48,
      defaultSpeedMs: 16,
      maxSpeedMs: 18,
      maxSpeedKmh: 64.8,
      windResistanceMs: 12,
      supportedPayloads: ["sony_ilx_lr1", "sony_rx1r2", "micasense_rededge_p"],
      sportMaxSpeedMs: 20,
      minSpeedMs: 12
    },
    {
      id: "custom_drone",
      brand: "Özel",
      model: "Özel İHA Platformu",
      maxFlightTimeMin: 40,
      safeFlightTimeMin: 30,
      defaultSpeedMs: 12,
      maxSpeedMs: 15,
      maxSpeedKmh: 54.0,
      windResistanceMs: 12,
      supportedPayloads: ["custom_cam", "zen_p1_35", "m3e_built_in", "sony_ilx_lr1"],
      sportMaxSpeedMs: 25,
      minSpeedMs: 2
    }
  ],
  cameras: [
    {
      id: "zen_p1_35",
      name: "DJI Zenmuse P1 (35mm)",
      sensorWidthMm: 35.9,
      sensorHeightMm: 24.0,
      focalLengthMm: 35.0,
      imageWidthPx: 8192,
      imageHeightPx: 5460,
      megapixels: 45,
      pixelSizeUm: 4.4,
      shutterType: "Mekanik (Global)",
      minTriggerIntervalSec: 0.7,
      sensorW: 35.9,
      sensorH: 24.0,
      focalMm: 35.0,
      imageW: 8192,
      imageH: 5460,
      minTriggerIntervalS: 0.7
    },
    {
      id: "zen_p1_24",
      name: "DJI Zenmuse P1 (24mm)",
      sensorWidthMm: 35.9,
      sensorHeightMm: 24.0,
      focalLengthMm: 24.0,
      imageWidthPx: 8192,
      imageHeightPx: 5460,
      megapixels: 45,
      pixelSizeUm: 4.4,
      shutterType: "Mekanik (Global)",
      minTriggerIntervalSec: 0.7,
      sensorW: 35.9,
      sensorH: 24.0,
      focalMm: 24.0,
      imageW: 8192,
      imageH: 5460,
      minTriggerIntervalS: 0.7
    },
    {
      id: "zen_p1_50",
      name: "DJI Zenmuse P1 (50mm)",
      sensorWidthMm: 35.9,
      sensorHeightMm: 24.0,
      focalLengthMm: 50.0,
      imageWidthPx: 8192,
      imageHeightPx: 5460,
      megapixels: 45,
      pixelSizeUm: 4.4,
      shutterType: "Mekanik (Global)",
      minTriggerIntervalSec: 0.7,
      sensorW: 35.9,
      sensorH: 24.0,
      focalMm: 50.0,
      imageW: 8192,
      imageH: 5460,
      minTriggerIntervalS: 0.7
    },
    {
      id: "zen_l2",
      name: "DJI Zenmuse L2 LiDAR + RGB",
      sensorWidthMm: 17.3,
      sensorHeightMm: 13.0,
      focalLengthMm: 12.3,
      imageWidthPx: 5280,
      imageHeightPx: 3956,
      megapixels: 20,
      pixelSizeUm: 3.3,
      shutterType: "Mekanik",
      minTriggerIntervalSec: 0.7,
      sensorW: 17.3,
      sensorH: 13.0,
      focalMm: 12.3,
      imageW: 5280,
      imageH: 3956,
      minTriggerIntervalS: 0.7
    },
    {
      id: "zen_l1",
      name: "DJI Zenmuse L1 LiDAR + RGB",
      sensorWidthMm: 13.2,
      sensorHeightMm: 8.8,
      focalLengthMm: 8.8,
      imageWidthPx: 5472,
      imageHeightPx: 3648,
      megapixels: 20,
      pixelSizeUm: 2.4,
      shutterType: "Mekanik",
      minTriggerIntervalSec: 1.0,
      sensorW: 13.2,
      sensorH: 8.8,
      focalMm: 8.8,
      imageW: 5472,
      imageH: 3648,
      minTriggerIntervalS: 1.0
    },
    {
      id: "zen_l3",
      name: "DJI Zenmuse L3 (Ultra LiDAR + FullFrame)",
      sensorWidthMm: 35.9,
      sensorHeightMm: 24.0,
      focalLengthMm: 28.0,
      imageWidthPx: 8192,
      imageHeightPx: 5460,
      megapixels: 45,
      pixelSizeUm: 4.4,
      shutterType: "Mekanik",
      minTriggerIntervalSec: 0.5,
      sensorW: 35.9,
      sensorH: 24.0,
      focalMm: 28.0,
      imageW: 8192,
      imageH: 5460,
      minTriggerIntervalS: 0.5
    },
    {
      id: "zen_h30",
      name: "DJI Zenmuse H30 (Geniş + Zoom)",
      sensorWidthMm: 9.6,
      sensorHeightMm: 7.2,
      focalLengthMm: 6.8,
      imageWidthPx: 8000,
      imageHeightPx: 6000,
      megapixels: 48,
      pixelSizeUm: 1.2,
      shutterType: "Elektronik",
      minTriggerIntervalSec: 1.0,
      sensorW: 9.6,
      sensorH: 7.2,
      focalMm: 6.8,
      imageW: 8000,
      imageH: 6000,
      minTriggerIntervalS: 1.0
    },
    {
      id: "zen_h30t",
      name: "DJI Zenmuse H30T (Termal + LRF)",
      sensorWidthMm: 9.6,
      sensorHeightMm: 7.2,
      focalLengthMm: 6.8,
      imageWidthPx: 8000,
      imageHeightPx: 6000,
      megapixels: 48,
      pixelSizeUm: 1.2,
      shutterType: "Elektronik",
      minTriggerIntervalSec: 1.0,
      sensorW: 9.6,
      sensorH: 7.2,
      focalMm: 6.8,
      imageW: 8000,
      imageH: 6000,
      minTriggerIntervalS: 1.0
    },
    {
      id: "m4e_built_in",
      name: "DJI Matrice 4E Kamera (20MP)",
      sensorWidthMm: 17.3,
      sensorHeightMm: 13.0,
      focalLengthMm: 12.3,
      imageWidthPx: 5280,
      imageHeightPx: 3956,
      megapixels: 20,
      pixelSizeUm: 3.3,
      shutterType: "Mekanik",
      minTriggerIntervalSec: 0.5,
      sensorW: 17.3,
      sensorH: 13.0,
      focalMm: 12.3,
      imageW: 5280,
      imageH: 3956,
      minTriggerIntervalS: 0.5
    },
    {
      id: "m4t_built_in",
      name: "DJI Matrice 4T Kamera",
      sensorWidthMm: 9.6,
      sensorHeightMm: 7.2,
      focalLengthMm: 4.5,
      imageWidthPx: 8000,
      imageHeightPx: 6000,
      megapixels: 48,
      pixelSizeUm: 1.2,
      shutterType: "Elektronik",
      minTriggerIntervalSec: 1.5,
      sensorW: 9.6,
      sensorH: 7.2,
      focalMm: 4.5,
      imageW: 8000,
      imageH: 6000,
      minTriggerIntervalS: 1.5
    },
    {
      id: "m30_built_in",
      name: "DJI Matrice 30 Kamera",
      sensorWidthMm: 6.4,
      sensorHeightMm: 4.8,
      focalLengthMm: 4.5,
      imageWidthPx: 8000,
      imageHeightPx: 6000,
      megapixels: 48,
      pixelSizeUm: 0.8,
      shutterType: "Elektronik",
      minTriggerIntervalSec: 1.0,
      sensorW: 6.4,
      sensorH: 4.8,
      focalMm: 4.5,
      imageW: 8000,
      imageH: 6000,
      minTriggerIntervalS: 1.0
    },
    {
      id: "m30t_built_in",
      name: "DJI Matrice 30T Kamera (Termal)",
      sensorWidthMm: 6.4,
      sensorHeightMm: 4.8,
      focalLengthMm: 4.5,
      imageWidthPx: 8000,
      imageHeightPx: 6000,
      megapixels: 48,
      pixelSizeUm: 0.8,
      shutterType: "Elektronik",
      minTriggerIntervalSec: 1.5,
      sensorW: 6.4,
      sensorH: 4.8,
      focalMm: 4.5,
      imageW: 8000,
      imageH: 6000,
      minTriggerIntervalS: 1.5
    },
    {
      id: "m3e_built_in",
      name: "DJI Mavic 3E Kamera (20MP)",
      sensorWidthMm: 17.3,
      sensorHeightMm: 13.0,
      focalLengthMm: 12.3,
      imageWidthPx: 5280,
      imageHeightPx: 3956,
      megapixels: 20,
      pixelSizeUm: 3.3,
      shutterType: "Mekanik",
      minTriggerIntervalSec: 0.7,
      sensorW: 17.3,
      sensorH: 13.0,
      focalMm: 12.3,
      imageW: 5280,
      imageH: 3956,
      minTriggerIntervalS: 0.7
    },
    {
      id: "m3t_built_in",
      name: "DJI Mavic 3T Kamera",
      sensorWidthMm: 6.4,
      sensorHeightMm: 4.8,
      focalLengthMm: 4.5,
      imageWidthPx: 8000,
      imageHeightPx: 6000,
      megapixels: 48,
      pixelSizeUm: 0.8,
      shutterType: "Elektronik",
      minTriggerIntervalSec: 2.0,
      sensorW: 6.4,
      sensorH: 4.8,
      focalMm: 4.5,
      imageW: 8000,
      imageH: 6000,
      minTriggerIntervalS: 2.0
    },
    {
      id: "m3m_built_in",
      name: "DJI Mavic 3M Kamera (20MP)",
      sensorWidthMm: 17.3,
      sensorHeightMm: 13.0,
      focalLengthMm: 12.3,
      imageWidthPx: 5280,
      imageHeightPx: 3956,
      megapixels: 20,
      pixelSizeUm: 3.3,
      shutterType: "Mekanik",
      minTriggerIntervalSec: 0.7,
      sensorW: 17.3,
      sensorH: 13.0,
      focalMm: 12.3,
      imageW: 5280,
      imageH: 3956,
      minTriggerIntervalS: 0.7
    },
    {
      id: "p4rtk_built_in",
      name: "DJI Phantom 4 RTK Kamera (20MP)",
      sensorWidthMm: 13.2,
      sensorHeightMm: 8.8,
      focalLengthMm: 8.8,
      imageWidthPx: 5472,
      imageHeightPx: 3648,
      megapixels: 20,
      pixelSizeUm: 2.4,
      shutterType: "Mekanik",
      minTriggerIntervalSec: 1.5,
      sensorW: 13.2,
      sensorH: 8.8,
      focalMm: 8.8,
      imageW: 5472,
      imageH: 3648,
      minTriggerIntervalS: 1.5
    },
    {
      id: "sony_ilx_lr1",
      name: "Sony ILX-LR1 (61MP)",
      sensorWidthMm: 35.7,
      sensorHeightMm: 23.8,
      focalLengthMm: 35.0,
      imageWidthPx: 9504,
      imageHeightPx: 6336,
      megapixels: 61,
      pixelSizeUm: 3.76,
      shutterType: "Mekanik",
      minTriggerIntervalSec: 0.5,
      sensorW: 35.7,
      sensorH: 23.8,
      focalMm: 35.0,
      imageW: 9504,
      imageH: 6336,
      minTriggerIntervalS: 0.5
    },
    {
      id: "sony_rx1r2",
      name: "Sony RX1R II (42.4MP)",
      sensorWidthMm: 35.9,
      sensorHeightMm: 24.0,
      focalLengthMm: 35.0,
      imageWidthPx: 7952,
      imageHeightPx: 5304,
      megapixels: 42.4,
      pixelSizeUm: 4.5,
      shutterType: "Leaf Shutter",
      minTriggerIntervalSec: 0.8,
      sensorW: 35.9,
      sensorH: 24.0,
      focalMm: 35.0,
      imageW: 7952,
      imageH: 5304,
      minTriggerIntervalS: 0.8
    },
    {
      id: "micasense_rededge_p",
      name: "MicaSense RedEdge-P",
      sensorWidthMm: 5.7,
      sensorHeightMm: 4.3,
      focalLengthMm: 5.5,
      imageWidthPx: 2048,
      imageHeightPx: 1536,
      megapixels: 3.1,
      pixelSizeUm: 2.8,
      shutterType: "Global",
      minTriggerIntervalSec: 1.0,
      sensorW: 5.7,
      sensorH: 4.3,
      focalMm: 5.5,
      imageW: 2048,
      imageH: 1536,
      minTriggerIntervalS: 1.0
    },
    {
      id: "custom_cam",
      name: "Özel Kamera / Sensör",
      sensorWidthMm: 23.5,
      sensorHeightMm: 15.6,
      focalLengthMm: 16.0,
      imageWidthPx: 6000,
      imageHeightPx: 4000,
      megapixels: 24,
      pixelSizeUm: 3.9,
      shutterType: "Mekanik",
      minTriggerIntervalSec: 1.0,
      sensorW: 23.5,
      sensorH: 15.6,
      focalMm: 16.0,
      imageW: 6000,
      imageH: 4000,
      minTriggerIntervalS: 1.0
    }
  ]
};

class DroneDatabaseManager {
  constructor() {
    this.data = JSON.parse(JSON.stringify(DEFAULT_DRONE_DATABASE));
    this.fetchExternalJson();
  }

  /**
   * data/drone_sensors.json dosyasından güncel sensör veritabanını asenkron çeker
   */
  async fetchExternalJson() {
    try {
      const response = await fetch(`data/drone_sensors.json?t=${Date.now()}`);
      if (response.ok) {
        const json = await response.json();
        if (json.drones && json.cameras) {
          this.data = json;
          if (typeof window !== "undefined" && window.refreshDroneDatabaseUI) {
            window.refreshDroneDatabaseUI();
          }
        }
      }
    } catch (err) {
      // Çevrimdışı veya dosya yoksa gömülü DEFAULT_DRONE_DATABASE kullanılmaya devam eder
    }
  }

  getDrones() {
    return this.data.drones || [];
  }

  getDrone(droneId) {
    return (this.data.drones || []).find(d => d.id === droneId) || null;
  }

  getCameras() {
    return this.data.cameras || [];
  }

  getCamera(cameraId) {
    return (this.data.cameras || []).find(c => c.id === cameraId) || null;
  }

  getCamerasForDrone(droneId) {
    const drone = this.getDrone(droneId);
    if (!drone || !drone.supportedPayloads) {
      return this.getCameras();
    }
    return this.getCameras().filter(cam => drone.supportedPayloads.includes(cam.id));
  }
}

const defaultDroneManager = new DroneDatabaseManager();

if (typeof window !== "undefined") {
  window.DroneDatabase = defaultDroneManager;
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = defaultDroneManager;
  module.exports.DroneDatabaseManager = DroneDatabaseManager;
  module.exports.DEFAULT_DRONE_DATABASE = DEFAULT_DRONE_DATABASE;
}