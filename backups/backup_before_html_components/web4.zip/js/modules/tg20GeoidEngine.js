class Tg20GeoidEngine {
  constructor() {
    this.isLoaded = false;
    this.isLoading = false;
    this.modelName = "TG-20 (Türkiye Hibrit Jeoidi 2020)";
    this.minLat = 35.5;
    this.maxLat = 42.5;
    this.minLon = 25.5;
    this.maxLon = 45;
    this.dLat = 1 / 60;
    this.dLon = 1 / 60;
    this.nRows = 421;
    this.nCols = 1171;
    this.headerSize = 146;
    this.scale = 0.001;
    this.gridDataUint16 = null;
    this.gridDataFloat = null;
    this.loadPromise = null;
    this.tryLoadEmbeddedModel();
  }
  tryLoadEmbeddedModel() {
    if (this.isLoaded) {
      return true;
    }
    if (typeof window !== "undefined" && window.TG20_GEOID_MODEL) {
      try {
        const model = window.TG20_GEOID_MODEL;
        this.modelName = model.name || this.modelName;
        this.minLat = model.minLat || this.minLat;
        this.maxLat = model.maxLat || this.maxLat;
        this.minLon = model.minLon || this.minLon;
        this.maxLon = model.maxLon || this.maxLon;
        this.dLat = model.dLat || this.dLat;
        this.dLon = model.dLon || this.dLon;
        this.nRows = model.nRows || this.nRows;
        this.nCols = model.nCols || this.nCols;
        this.scale = model.scale || 0.001;
        const binStr = atob(model.data);
        const len = binStr.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
          bytes[i] = binStr.charCodeAt(i);
        }
        this.gridDataUint16 = new Uint16Array(bytes.buffer);
        this.isLoaded = true;
        return true;
      } catch (err) {
        console.warn("Gömülü TG-20 optimize model yükleme hatası:", err);
      }
    }
    if (typeof window !== "undefined" && window.TG20_GGF_BASE64) {
      try {
        const raw = window.TG20_GGF_BASE64;
        const binStr = atob(raw);
        const len = binStr.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
          bytes[i] = binStr.charCodeAt(i);
        }
        this.loadBuffer(bytes.buffer);
        return true;
      } catch (err) {
        console.warn("Gömülü GGF Base64 yükleme hatası:", err);
      }
    }
    return false;
  }
  async loadFromUrl(url = "./data/TG20.ggf") {
    if (this.isLoaded) {
      return true;
    }
    if (this.tryLoadEmbeddedModel()) {
      return true;
    }
    if (this.isLoading && this.loadPromise) {
      return this.loadPromise;
    }
    this.isLoading = true;
    this.loadPromise = (async () => {
      try {
        const res = await fetch(url);
        if (!res.ok) {
          throw new Error("TG20.ggf indirilemedi (HTTP " + res.status + ")");
        }
        const buffer = await res.arrayBuffer();
        this.loadBuffer(buffer);
        this.isLoaded = true;
        this.isLoading = false;
        return true;
      } catch (err) {
        this.isLoading = false;
        if (this.tryLoadEmbeddedModel()) {
          return true;
        }
        throw err;
      }
    })();
    return this.loadPromise;
  }
  async loadFromFile(file) {
    const buffer = await file.arrayBuffer();
    this.loadBuffer(buffer);
    this.modelName = file.name.replace(/\.[^/.]+$/, "");
    return true;
  }
  loadBuffer(buf) {
    const byteOffset = buf.byteOffset || 0;
    const arrayBuffer = buf.buffer || buf;
    const view = new DataView(arrayBuffer, byteOffset, buf.byteLength || arrayBuffer.byteLength);
    this.minLat = view.getFloat64(48, true);
    this.maxLat = view.getFloat64(56, true);
    this.minLon = view.getFloat64(64, true);
    this.maxLon = view.getFloat64(72, true);
    this.dLat = view.getFloat64(80, true);
    this.dLon = view.getFloat64(88, true);
    this.nRows = view.getInt32(96, true);
    this.nCols = view.getInt32(100, true);
    const totalNodes = this.nRows * this.nCols;
    const gridSlice = arrayBuffer.slice(byteOffset + this.headerSize, byteOffset + this.headerSize + totalNodes * 4);
    this.gridDataFloat = new Float32Array(gridSlice);
    this.gridDataUint16 = null;
    this.isLoaded = true;
  }
  getGeoidHeight(lat, lon) {
    if (!this.isLoaded) {
      this.tryLoadEmbeddedModel();
      if (!this.isLoaded) {
        throw new Error("TG-20 Jeoit Modeli henüz yüklenmedi.");
      }
    }
    if (lat < this.minLat || lat > this.maxLat || lon < this.minLon || lon > this.maxLon) {
      return null;
    }
    const rFloat = (this.maxLat - lat) / this.dLat;
    const cFloat = (lon - this.minLon) / this.dLon;
    const r0 = Math.floor(rFloat);
    const c0 = Math.floor(cFloat);
    const r1 = Math.min(this.nRows - 1, r0 + 1);
    const c1 = Math.min(this.nCols - 1, c0 + 1);
    const dr = rFloat - r0;
    const dc = cFloat - c0;
    let q11;
    let q12;
    let q21;
    let q22;
    if (this.gridDataUint16) {
      q11 = this.gridDataUint16[r0 * this.nCols + c0] * this.scale;
      q12 = this.gridDataUint16[r0 * this.nCols + c1] * this.scale;
      q21 = this.gridDataUint16[r1 * this.nCols + c0] * this.scale;
      q22 = this.gridDataUint16[r1 * this.nCols + c1] * this.scale;
    } else if (this.gridDataFloat) {
      q11 = this.gridDataFloat[r0 * this.nCols + c0];
      q12 = this.gridDataFloat[r0 * this.nCols + c1];
      q21 = this.gridDataFloat[r1 * this.nCols + c0];
      q22 = this.gridDataFloat[r1 * this.nCols + c1];
    } else {
      return null;
    }
    const top = q11 * (1 - dc) + q12 * dc;
    const bottom = q21 * (1 - dc) + q22 * dc;
    return top * (1 - dr) + bottom * dr;
  }

  /**
   * Tıklanan noktanın etrafındaki 4 TG-20 ızgara düğüm noktasını (NW, NE, SW, SE),
   * ondülasyon değerlerini ve enterpolasyon ağırlıklarını detaylı döndürür.
   */
  getGeoidInterpolationDetails(lat, lon) {
    if (!this.isLoaded) {
      if (!this.tryLoadEmbeddedModel()) {
        return null;
      }
    }
    if (lat < this.minLat || lat > this.maxLat || lon < this.minLon || lon > this.maxLon) {
      return null;
    }
    const rFloat = (this.maxLat - lat) / this.dLat;
    const cFloat = (lon - this.minLon) / this.dLon;
    const r0 = Math.floor(rFloat);
    const c0 = Math.floor(cFloat);
    const r1 = Math.min(this.nRows - 1, r0 + 1);
    const c1 = Math.min(this.nCols - 1, c0 + 1);
    const dr = rFloat - r0;
    const dc = cFloat - c0;
    let q11, q12, q21, q22;
    if (this.gridDataUint16) {
      q11 = this.gridDataUint16[r0 * this.nCols + c0] * this.scale;
      q12 = this.gridDataUint16[r0 * this.nCols + c1] * this.scale;
      q21 = this.gridDataUint16[r1 * this.nCols + c0] * this.scale;
      q22 = this.gridDataUint16[r1 * this.nCols + c1] * this.scale;
    } else if (this.gridDataFloat) {
      q11 = this.gridDataFloat[r0 * this.nCols + c0];
      q12 = this.gridDataFloat[r0 * this.nCols + c1];
      q21 = this.gridDataFloat[r1 * this.nCols + c0];
      q22 = this.gridDataFloat[r1 * this.nCols + c1];
    } else {
      return null;
    }

    const wNW = (1 - dr) * (1 - dc);
    const wNE = (1 - dr) * dc;
    const wSW = dr * (1 - dc);
    const wSE = dr * dc;

    const latNorth = this.maxLat - r0 * this.dLat;
    const latSouth = this.maxLat - r1 * this.dLat;
    const lonWest = this.minLon + c0 * this.dLon;
    const lonEast = this.minLon + c1 * this.dLon;

    const top = q11 * (1 - dc) + q12 * dc;
    const bottom = q21 * (1 - dc) + q22 * dc;
    const interpolatedN = top * (1 - dr) + bottom * dr;

    return {
      interpolatedN: interpolatedN,
      lat: lat,
      lon: lon,
      dr: dr,
      dc: dc,
      cellBounds: [
        [latSouth, lonWest], // SW
        [latSouth, lonEast], // SE
        [latNorth, lonEast], // NE
        [latNorth, lonWest]  // NW
      ],
      nodes: {
        nw: { id: "NW", label: "Kuzeybatı (NW)", lat: latNorth, lon: lonWest, N: q11, weight: wNW, weightPercent: (wNW * 100).toFixed(1) },
        ne: { id: "NE", label: "Kuzeydoğu (NE)", lat: latNorth, lon: lonEast, N: q12, weight: wNE, weightPercent: (wNE * 100).toFixed(1) },
        sw: { id: "SW", label: "Güneybatı (SW)", lat: latSouth, lon: lonWest, N: q21, weight: wSW, weightPercent: (wSW * 100).toFixed(1) },
        se: { id: "SE", label: "Güneydoğu (SE)", lat: latSouth, lon: lonEast, N: q22, weight: wSE, weightPercent: (wSE * 100).toFixed(1) }
      }
    };
  }

  reduceHeight(lat, lon, h) {
    const N = this.getGeoidHeight(lat, lon);
    if (N === null) {
      return {
        lat: lat,
        lon: lon,
        h: h,
        N: null,
        H: h,
        inBounds: false,
        model: this.modelName,
        status: "TG-20 Kapsamı Dışı (35.5°-42.5°K, 25.5°-45.0°D)"
      };
    }
    const H = h - N;
    return {
      lat: lat,
      lon: lon,
      h: h,
      N: N,
      H: H,
      inBounds: true,
      model: this.modelName,
      status: "Başarılı (TG-20)"
    };
  }
  reduceHeightFromTM(y, x, h, epsgCode, geodesyEngine) {
    if (!geodesyEngine) {
      throw new Error("Projeksiyon dönüşümü için GeodesyEngine gereklidir.");
    }
    const geo = geodesyEngine.transformCoordinate({
      c1: y,
      c2: x,
      c3: h
    }, epsgCode, "EPSG:4326");
    const result = this.reduceHeight(geo.lat, geo.lon, h);
    return {
      ...result,
      y: y,
      x: x,
      epsgCode: epsgCode
    };
  }
  batchReducePoints(points, inputEpsg, geodesyEngine) {
    const isWgs84 = inputEpsg === "EPSG:4326";
    return points.map(pt => {
      let lat = isWgs84 ? pt.c1 : 0;
      let lon = isWgs84 ? pt.c2 : 0;
      let y = isWgs84 ? 0 : pt.c1;
      let x = isWgs84 ? 0 : pt.c2;
      const h = pt.h || 0;
      if (!isWgs84) {
        const geo = geodesyEngine.transformCoordinate({
          c1: y,
          c2: x,
          c3: h
        }, inputEpsg, "EPSG:4326");
        lat = geo.lat;
        lon = geo.lon;
      }
      const res = this.reduceHeight(lat, lon, h);
      return {
        name: pt.name,
        y: y,
        x: x,
        lat: lat,
        lon: lon,
        h: h,
        N: res.N,
        H: res.H,
        inBounds: res.inBounds,
        status: res.status
      };
    });
  }
  generateReductionReport(points, projectName = "Kadastro_TG20_Kot_Indirgeme") {
    const dateStr = new Date().toLocaleDateString("tr-TR");
    let report = "========================================================================================\n          GNSS POS WEB STUDIO - TG-20 TÜRKİYE HİBRİT JEOİDİ İNDİRGEME RAPORU            \n========================================================================================\nProje Adı           : " + projectName + "\nJeoit Modeli        : Harita Genel Müdürlüğü TG-20 (Türkiye Hibrit Jeoidi 2020)\nTarih               : " + dateStr + "\nToplam Nokta Sayısı : " + points.length + "\nTemel Bağıntı       : H (Ortometrik Nivelman Kotu) = h (Elipsoit Kotu) - N (Jeoit Undülasyonu)\n----------------------------------------------------------------------------------------\nNOKTA ADI     ENLEM (Lat)   BOYLAM (Lon)    ELİPSOİT (h)   JEOİT (N)   ORTOMETRİK (H)  DURUM\n----------------------------------------------------------------------------------------\n";
    points.forEach(pt => {
      const name = (pt.name || "P").padEnd(12, " ");
      const latStr = pt.lat.toFixed(6).padStart(12, " ");
      const lonStr = pt.lon.toFixed(6).padStart(12, " ");
      const hStr = pt.h.toFixed(3).padStart(12, " ");
      const nStr = (pt.N !== null ? (pt.N >= 0 ? "+" : "") + pt.N.toFixed(3) : "--").padStart(10, " ");
      const orthoStr = (pt.H !== null ? pt.H.toFixed(3) : "--").padStart(14, " ");
      const status = pt.inBounds ? "TG-20 OK" : "Dışında";
      report += name + " " + latStr + " " + lonStr + " " + hStr + " " + nStr + " " + orthoStr + "   " + status + "\n";
    });
    report += "========================================================================================\n";
    return report;
  }
  generatePrintableReport(points, projectTitle = "TG-20 ORTOMETRİK KOT İNDİRGEME PROJESİ") {
    const dateStr = new Date().toLocaleDateString("tr-TR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric"
    });
    const timeStr = new Date().toLocaleTimeString("tr-TR", {
      hour: "2-digit",
      minute: "2-digit"
    });
    const evaluated = points.map(pt => {
      const res = this.reduceHeight(pt.lat, pt.lon, pt.h);
      return {
        name: pt.name || "P",
        lat: pt.lat,
        lon: pt.lon,
        h: pt.h,
        N: res.N !== null ? res.N : pt.N !== null ? pt.N : null,
        H: res.H !== null ? res.H : pt.H !== null ? pt.H : pt.h - (res.N || 0),
        inBounds: res.inBounds,
        status: res.status
      };
    });
    const inBounds = evaluated.filter(p => p.inBounds && p.N !== null);
    const avgN = inBounds.length > 0 ? inBounds.reduce((acc, p) => acc + p.N, 0) / inBounds.length : 0;
    const minN = inBounds.length > 0 ? Math.min(...inBounds.map(p => p.N)) : 0;
    const maxN = inBounds.length > 0 ? Math.max(...inBounds.map(p => p.N)) : 0;
    let html = `
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>TG-20 Jeoit İndirgeme Raporu - GNSS Pos Web Studio</title>
  <style>
    @page {
      size: A4 portrait;
      margin: 12mm 15mm 15mm 15mm;
    }
    * {
      box-sizing: border-box;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, Helvetica, Arial, sans-serif;
      font-size: 10.5px;
      color: #1e293b;
      background: #ffffff;
      margin: 0;
      padding: 0;
      line-height: 1.45;
    }
    .report-container {
      width: 100%;
      max-width: 210mm;
      margin: 0 auto;
    }
    .header-banner {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 2px solid #0f766e;
      padding-bottom: 10px;
      margin-bottom: 12px;
    }
    .brand-title {
      font-size: 15px;
      font-weight: 800;
      color: #0f766e;
      letter-spacing: 0.5px;
      text-transform: uppercase;
    }
    .brand-sub {
      font-size: 10px;
      color: #64748b;
      font-weight: 600;
    }
    .report-title-box {
      text-align: center;
      background: #f0fdfa;
      border: 1px solid #ccfbf1;
      padding: 10px 14px;
      border-radius: 6px;
      margin-bottom: 14px;
    }
    .report-title-box h1 {
      font-size: 14px;
      font-weight: 800;
      color: #115e59;
      margin: 0 0 3px 0;
      text-transform: uppercase;
      letter-spacing: 0.3px;
    }
    .report-title-box p {
      font-size: 10.5px;
      color: #0f766e;
      margin: 0;
      font-weight: 500;
    }
    .meta-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 6px;
      padding: 10px 14px;
      margin-bottom: 12px;
      font-size: 10.5px;
    }
    .meta-item {
      display: flex;
      justify-content: space-between;
      padding: 2px 0;
    }
    .meta-label {
      color: #64748b;
      font-weight: 600;
    }
    .meta-value {
      color: #0f172a;
      font-weight: 700;
      font-family: 'Consolas', 'Courier New', monospace;
    }
    .formula-card {
      background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
      border: 1px solid #cbd5e1;
      border-left: 4px solid #0d9488;
      padding: 8px 14px;
      border-radius: 4px;
      margin-bottom: 14px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 10px;
    }
    .formula-math {
      font-size: 12px;
      font-weight: 700;
      color: #0f766e;
      font-family: 'Cambria Math', 'Times New Roman', serif;
    }
    .formula-stats {
      font-size: 10.5px;
      color: #475569;
      display: flex;
      gap: 12px;
    }
    .formula-stats strong {
      color: #0f172a;
      font-family: 'Consolas', monospace;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 14px;
      font-size: 9.5px;
    }
    thead {
      display: table-header-group;
    }
    tr {
      page-break-inside: avoid;
    }
    th {
      background-color: #0f766e;
      color: #ffffff;
      font-weight: 700;
      text-transform: uppercase;
      font-size: 9px;
      letter-spacing: 0.3px;
      padding: 6px 4px;
      border: 1px solid #0d9488;
      text-align: center;
    }
    td {
      border: 1px solid #cbd5e1;
      padding: 5px 4px;
      text-align: center;
      color: #1e293b;
    }
    tbody tr:nth-child(even) {
      background-color: #f8fafc;
    }
    tbody tr:hover {
      background-color: #f1f5f9;
    }
    .col-name {
      font-weight: 700;
      color: #0f172a;
      text-align: left;
      padding-left: 8px;
    }
    .col-mono {
      font-family: 'Consolas', 'Courier New', monospace;
      font-size: 9.5px;
    }
    .col-geoid {
      font-family: 'Consolas', 'Courier New', monospace;
      font-weight: 800;
      color: #b45309;
      background: #fef3c7;
    }
    .col-ortho {
      font-family: 'Consolas', 'Courier New', monospace;
      font-weight: 800;
      color: #065f46;
      background: #d1fae5;
    }
    .badge-ok {
      background: #dcfce7;
      color: #166534;
      font-weight: 700;
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 8.5px;
      border: 1px solid #bbf7d0;
    }
    .badge-out {
      background: #fee2e2;
      color: #991b1b;
      font-weight: 700;
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 8.5px;
      border: 1px solid #fecaca;
    }
    .disclaimer-card {
      background: #fffbeb;
      border: 1px solid #fde68a;
      border-left: 4px solid #d97706;
      border-radius: 4px;
      padding: 10px 12px;
      margin-top: 14px;
      font-size: 9px;
      color: #92400e;
      line-height: 1.5;
    }
    .disclaimer-title {
      font-weight: 800;
      text-transform: uppercase;
      display: flex;
      align-items: center;
      gap: 6px;
      margin-bottom: 4px;
      color: #b45309;
      font-size: 9.5px;
    }
    .footer-bar {
      margin-top: 14px;
      padding-top: 8px;
      border-top: 1px solid #e2e8f0;
      display: flex;
      justify-content: space-between;
      font-size: 8.5px;
      color: #94a3b8;
    }
    .report-meta-right { text-align: right; font-size: 9.5px; color: #64748b; }
    .th-num { width: 4%; }
    .th-name { width: 20%; text-align: left; padding-left: 8px; }
    .th-coord { width: 15%; }
    .th-elev { width: 14%; }
    .th-status { width: 4%; }
    .col-dim { color: #64748b; }
    .print-btn-float {
      position: fixed;
      top: 14px;
      right: 14px;
      background: #0f766e;
      color: #ffffff;
      border: none;
      border-radius: 6px;
      padding: 10px 18px;
      font-size: 13px;
      font-weight: 700;
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(15, 118, 110, 0.35);
      display: flex;
      align-items: center;
      gap: 8px;
      z-index: 9999;
      transition: all 0.2s;
    }
    .print-btn-float:hover {
      background: #115e59;
      transform: translateY(-1px);
    }
    @media print {
      .print-btn-float {
        display: none !important;
      }
      body {
        margin: 0;
        padding: 0;
      }
    }
  </style>
</head>
<body>

  <button class="print-btn-float" onclick="window.print()">
    🖨️ Yazdır / PDF Kaydet
  </button>

  <div class="report-container">
    
    <!-- Top Branding Banner -->
    <div class="header-banner">
      <div>
        <div class="brand-title">HARİTA TOOLS — JEODEZİ & GNSS STÜDYOSU</div>
        <div class="brand-sub">Profesyonel Jeodezi, Fotogrametri & GNSS Hesaplama Platformu | Geografik Harita ve Coğrafi Bilgi Teknolojileri</div>
      </div>
      <div class="report-meta-right">
        <div><strong>TG-20 Jeoit İndirgeme Çetelesi</strong></div>
        <div>Tarih / Saat: <strong>${dateStr} ${timeStr}</strong></div>
      </div>
    </div>

    <!-- Report Title Box -->
    <div class="report-title-box">
      <h1>TG-20 TÜRKİYE HİBRİT JEOİDİ ORTOMETRİK KOT İNDİRGEME RAPORU</h1>
      <p>GPS / GNSS Ölçümlerinin TUDKA-99 Helmert Ortometrik Nivelman Kotuna İndirgenmesi (BÖHHBÜY Standartları)</p>
    </div>

    <!-- Metadata Grid -->
    <div class="meta-grid">
      <div class="meta-item">
        <span class="meta-label">Proje / İş Adı:</span>
        <span class="meta-value">${projectTitle}</span>
      </div>
      <div class="meta-item">
        <span class="meta-label">Hesaplama Tarihi:</span>
        <span class="meta-value">${dateStr} - ${timeStr}</span>
      </div>
      <div class="meta-item">
        <span class="meta-label">Kullanılan Jeoit Modeli:</span>
        <span class="meta-value">HGM TG-20 (Türkiye Hibrit Jeoidi 2020)</span>
      </div>
      <div class="meta-item">
        <span class="meta-label">Grid Çözünürlüğü:</span>
        <span class="meta-value">1' x 1' (492.991 Grid Noktası)</span>
      </div>
      <div class="meta-item">
        <span class="meta-label">Enterpolasyon Metodu:</span>
        <span class="meta-value">Çift Doğrusal (Bilinear) Enterpolasyon</span>
      </div>
      <div class="meta-item">
        <span class="meta-label">Toplam Nokta Sayısı:</span>
        <span class="meta-value">${evaluated.length} Nokta (${inBounds.length} Kapsam İçi)</span>
      </div>
    </div>

    <!-- Mathematical Formula & Summary Card -->
    <div class="formula-card">
      <div class="formula-math">
        <strong>Temel Formül:</strong>&nbsp;&nbsp; H<sub>ortometrik</sub> = h<sub>elipsoit</sub> − N<sub>TG-20</sub>
      </div>
      <div class="formula-stats">
        <span>Ortalama N: <strong>${avgN > 0 ? "+" : ""}${avgN.toFixed(3)} m</strong></span>
        <span>Min N: <strong>${minN > 0 ? "+" : ""}${minN.toFixed(3)} m</strong></span>
        <span>Max N: <strong>${maxN > 0 ? "+" : ""}${maxN.toFixed(3)} m</strong></span>
      </div>
    </div>

    <!-- Reduction Points Table -->
    <table>
      <thead>
        <tr>
          <th class="th-num">#</th>
          <th class="th-name">Nokta No / Adı</th>
          <th class="th-coord">WGS-84 Enlem (ϕ)</th>
          <th class="th-coord">WGS-84 Boylam (λ)</th>
          <th class="th-elev">Elipsoit Kotu (h / m)</th>
          <th class="th-elev">TG-20 Undülasyon (N / m)</th>
          <th class="th-elev">Ortometrik Kot (H / m)</th>
          <th class="th-status">Durum</th>
        </tr>
      </thead>
      <tbody>`;
    evaluated.forEach((pt, idx) => {
      const nStr = pt.N !== null ? (pt.N >= 0 ? "+" : "") + pt.N.toFixed(3) : "Kapsam Dışı";
      const hStr = pt.H !== null ? pt.H.toFixed(3) : pt.h.toFixed(3);
      const badgeCls = pt.inBounds ? "badge-ok" : "badge-out";
      const badgeText = pt.inBounds ? "TG-20 OK" : "Dışında";
      html += `
        <tr>
          <td class="col-mono col-dim">${idx + 1}</td>
          <td class="col-name">${pt.name}</td>
          <td class="col-mono">${pt.lat.toFixed(6)}°</td>
          <td class="col-mono">${pt.lon.toFixed(6)}°</td>
          <td class="col-mono">${pt.h.toFixed(3)} m</td>
          <td class="col-geoid">${nStr} m</td>
          <td class="col-ortho">${hStr} m</td>
          <td><span class="${badgeCls}">${badgeText}</span></td>
        </tr>`;
    });
    html += `
      </tbody>
    </table>

    <!-- Legal Disclaimer & Software Notice -->
    <div class="disclaimer-card">
      <div class="disclaimer-title">
        <span>⚠️ Yasal Bilgilendirme ve Sorumluluk Reddi Beyanı</span>
      </div>
      <div>
        Bu hesaplama raporu, Harita Genel Müdürlüğü (HGM) tarafından yayımlanan resmi TG-20 Türkiye Hibrit Jeoidi 2020 modeli grid düğüm noktaları ve çift doğrusal (bilinear) enterpolasyon algoritması kullanılarak <strong>Harita Tools</strong> yazılımı tarafından teknik hesaplama ve kontrol amaçlı olarak üretilmiştir. 
        İşbu raporda yer alan ortometrik kot indirgemeleri (<em>H = h − N</em>) mühendislik hesap desteği niteliğinde olup, Tapu ve Kadastro Genel Müdürlüğü (TKGM) veya Harita Genel Müdürlüğü (HGM) tarafından doğrudan tanzim edilmiş resmi bir onay veya tescil belgesi yerine geçmez. Resmi kadastro, imar ve altyapı projelerinde yürürlükteki Büyük Ölçekli Harita ve Harita Bilgileri Üretim Yönetmeliği (BÖHHBÜY) ile ilgili kamu idarelerinin teknik standartları doğrultusunda yetkili harita/geomatik mühendisi denetiminde işlem yapılması esastır.
      </div>
    </div>

    <!-- Footer Bar -->
    <div class="footer-bar">
      <div>Harita Tools © 2026 | Jeodezi & GNSS Stüdyosu — Geografik Harita ve Coğrafi Bilgi Teknolojileri</div>
      <div>Referans: HGM TG-20 (TUDKA-99 Düşey Kontrol Sistemi)</div>
      <div>Sayfa 1 / 1</div>
    </div>

  </div>

</body>
</html>`;
    return html;
  }
}
if (typeof module !== "undefined" && module.exports) {
  module.exports = Tg20GeoidEngine;
}