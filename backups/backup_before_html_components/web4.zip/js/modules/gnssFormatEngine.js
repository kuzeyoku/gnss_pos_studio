/**
 * =========================================================================================
 *  HARİTA TOOL / GNSS POS WEB STUDIO - GNSS KADASTRO & VERİ FORMAT MOTORU (GnssFormatEngine)
 * =========================================================================================
 *  - SurvCE / SurvStar (.RW5), FieldGenius / Carlson (.RAW), CHC LandStar / CSV, Trimble (.JXL)
 *  - Çift Okuma Kontrolü & Fark Analizi (BÖHHBÜY: dS ≤ 7cm, Δt ≥ 60 dk, Ortalama Koordinat Hesabı)
 *  - TG-20 Türkiye Hibrit Jeoidi ile Elipsoit Kotundan Ortometrik Kota İndirgeme (H = h - N)
 *  - Netcad (.NCN / .KOS), AutoCAD (.DXF), Google Earth (.KML) ve Kadastro CSV / HTML Rapor İhracı
 *  - DXF Çizim Dosyalarını GeoJSON Web Harita Vektör Katmanına Dönüştürme
 * =========================================================================================
 */

class GnssFormatEngine {
  constructor() {
    this.rawPoints = [];
    this.matchedPairs = [];
    this.unmatchedPoints = [];
    this.detectedBrand = "AUTO";
    this.geodesy = typeof GeodesyEngine !== "undefined" ? new GeodesyEngine() : null;
    this.centralMeridian = 30;
    this.geoidN = 34.455;
    this.isTg20Applied = false;
  }

  /**
   * Evrensel Otonom GNSS Karar Motoru (Universal Pattern & Data-Type Decision Engine)
   * Hiçbir marka veya yazılım adına bakmaksızın, doğrudan gelen verinin tipine,
   * sayısal büyüklüklerine ve desenlerine göre otonom karar verir.
   */
  parseData(content, fileName = "") {
    const text = content.trim();
    if (!text) return [];

    // 1. XML Veri Yapısı (JXL / LandXML vb.)
    if (text.startsWith("<?xml") || text.includes("<JOBFile") || text.includes("<FieldBook") || fileName.toLowerCase().endsWith(".jxl")) {
      this.detectedBrand = "XML Tabanlı Geodezik Veri";
      return this.parseTrimbleJxl(text);
    }

    // 2. Bloklu ve Etiketli Saha Kayıt Formatları (RW5, RAW, Saha Günlükleri)
    if (text.includes("GPS,") || text.includes("GS,") || text.includes("BP,") || text.includes("EP,") || text.includes("SP,") || text.includes("JB,") || text.includes("--")) {
      this.detectedBrand = "Otonom Saha Ölçü Akışı";
      return this.parseRw5(text);
    }

    // 3. Tablo / CSV / Ayrılmış Sütunlu Veri
    const firstLine = text.split("\n")[0] || "";
    if (firstLine.includes(",") || firstLine.includes(";") || firstLine.includes("\t")) {
      this.detectedBrand = "Tablo / Ayrılmış Sütunlu Koordinat Akışı";
      return this.parseCsv(text);
    }

    // 4. Serbest Sütunlu Sayı Dizisi
    this.detectedBrand = "Serbest Sütunlu Koordinat Akışı";
    return this.parseGenericText(text);
  }

  /**
   * Saf Sayısal ve Geodezik Örüntü Karar Motoru (Pure Heuristic Pattern Parser)
   * Satırları sayısal aralıklarına (Değer Büyüklüğü), zaman desenlerine ve
   * geodezik niteliklerine göre markadan bağımsız olarak çözümler.
   */
  parseRw5(rw5Content) {
    const lines = rw5Content.split("\n");
    const points = [];
    let curRecord = {};
    let isBaseContext = false;
    let fallbackDate = "";
    let fallbackTime = "";

    // 1. RW5 / Saha Başlığından Projeksiyon ve DOM Keşfi (Header Projection Scanner)
    let headerDom = null;
    for (let i = 0; i < Math.min(lines.length, 50); i++) {
      const l = lines[i];
      const matchTm = l.match(/(?:3-derece\s+TM|TM\s+3°?|CM\s*|DOM\s*|Zone\s*)(\d{2})/i) || l.match(/Transverse\s+Mercator.*?(\d{2})/i);
      if (matchTm) {
        const domVal = parseInt(matchTm[1], 10);
        if ([27, 30, 33, 36, 39, 42, 45].includes(domVal)) {
          headerDom = domVal;
          this.centralMeridian = domVal;
          break;
        }
      }
    }

    // GPS Hafta & Zamanından Otonom UTC Çözümleyici
    const parseGpsTime = (week, towSec) => {
      const gpsEpoch = Date.UTC(1980, 0, 6, 0, 0, 0);
      const msInWeek = 7 * 24 * 3600 * 1000;
      const leapMs = 18000;
      return new Date(gpsEpoch + (week * msInWeek) + Math.round(towSec * 1000) - leapMs);
    };

    // Noktayı Otonom Doğrulayıp Kaydetme
    const commitPoint = () => {
      if (isBaseContext) {
        curRecord = {};
        return;
      }

      // En az bir nokta adı ve koordinat/enlem bilgisi mevcut mu?
      if (curRecord.pn && (curRecord.lat !== undefined || (curRecord.n !== undefined && curRecord.e !== undefined))) {
        // Otomatik DOM Keşfi (Eğer başlıkta yoksa, ilk noktanın boylamından tespit et)
        if (!headerDom && points.length === 0 && this.geodesy && curRecord.lon !== undefined) {
          this.centralMeridian = this.geodesy.getAutoCentralMeridian3Deg(curRecord.lon);
        }

        let easting = curRecord.e || 0;
        let northing = curRecord.n || 0;

        // Eğer ham veride gerçek uydu koordinatları (lat/lon) varsa
        if (this.geodesy && curRecord.lat !== undefined && curRecord.lon !== undefined) {
          if (curRecord.e && curRecord.n && Math.abs(curRecord.e) > 10000 && Math.abs(curRecord.n) > 10000) {
            easting = curRecord.e;
            northing = curRecord.n;
          } else {
            const tm = this.geodesy.forwardTM(curRecord.lat, curRecord.lon, this.centralMeridian, 1.0, false);
            easting = tm.easting;
            northing = tm.northing;
          }
        } else if (this.geodesy && (curRecord.lat === undefined || curRecord.lon === undefined) && curRecord.e && curRecord.n) {
          // Değer Büyüklüğüne Göre Northing (7 Basamak) ve Easting (6 Basamak) Otomatik Doğrulama
          if (easting > 1000000 && northing < 1000000 && northing > 0) {
            const tmp = easting;
            easting = northing;
            northing = tmp;
          }
          // Eğer sadece N, E varsa, ters projeksiyonla lat, lon hesapla
          const geo = this.geodesy.inverseTM(easting, northing, this.centralMeridian, 1.0, false);
          curRecord.lat = geo.lat;
          curRecord.lon = geo.lon;
        }

        curRecord.e = easting;
        curRecord.n = northing;
        curRecord.h = curRecord.elRaw !== undefined ? curRecord.elRaw : (curRecord.h !== undefined ? curRecord.h : 1000.0);
        curRecord.orthoH = curRecord.h - this.geoidN;
        curRecord.latDec = curRecord.lat || 0;
        curRecord.lonDec = curRecord.lon || 0;
        curRecord.latDms = curRecord.lat ? (this.geodesy ? this.geodesy.toDms(curRecord.lat, true) : `${curRecord.lat.toFixed(7)}° N`) : "--";
        curRecord.lonDms = curRecord.lon ? (this.geodesy ? this.geodesy.toDms(curRecord.lon, false) : `${curRecord.lon.toFixed(7)}° E`) : "--";

        // Zaman Damgası
        if (!curRecord.timestamp) {
          const dStr = curRecord.dt || fallbackDate;
          const tStr = curRecord.tm || fallbackTime;
          if (dStr && tStr) {
            const [mo, da, yr] = dStr.split("-").map(Number);
            const [hh, mi, ss] = tStr.split(":").map(Number);
            curRecord.timestamp = new Date(yr || 2026, (mo || 1) - 1, da || 1, hh || 0, mi || 0, ss || 0);
          } else {
            curRecord.timestamp = new Date();
          }
        }

        if (!curRecord.dt) curRecord.dt = curRecord.timestamp.toLocaleDateString("tr-TR");
        if (!curRecord.tm) curRecord.tm = curRecord.timestamp.toLocaleTimeString("tr-TR");

        // Sayısal Hassasiyet ve Kalite Parametreleri
        curRecord.hsdvVal = curRecord.hsdv ? parseFloat(curRecord.hsdv) : (curRecord.hsdvVal || 0.007);
        curRecord.vsdvVal = curRecord.vsdv ? parseFloat(curRecord.vsdv) : (curRecord.vsdvVal || 0.009);
        curRecord.sats = curRecord.sats ? parseInt(curRecord.sats, 10) : (curRecord.sats || 32);
        curRecord.pdop = curRecord.pdop ? parseFloat(curRecord.pdop).toFixed(2) : (curRecord.pdop || "1.01");
        curRecord.status = curRecord.status ? curRecord.status.toUpperCase() : "FIXED";
        curRecord.hr = curRecord.hr ? curRecord.hr : "1.800";
        curRecord.epochs = curRecord.epochs || 5;
        curRecord.hz = 1;
        curRecord.method = "RTCM";
        curRecord.network = "VRS";
        curRecord.measure = "MEAN";
        curRecord.code = curRecord.code || "";

        points.push(curRecord);
      }
      curRecord = {};
    };

    // Carlson RW5 DD.MMSSssss -> Ondalık Derece (Decimal Degrees) Çözümleyici
    const dmsToDecimal = (val) => {
      if (val === undefined || val === null || isNaN(val)) return 0;
      const isNeg = val < 0;
      const absVal = Math.abs(val);
      const deg = Math.floor(absVal);
      const minSec = (absVal - deg) * 100;
      const min = Math.floor(minSec + 1e-9);
      const sec = (minSec - min) * 100;
      // Eğer dakika veya saniye 60 veya daha büyükse, bu değer zaten saf ondalık derecedir
      if (min >= 60 || sec >= 60) {
        return val;
      }
      const decimal = deg + min / 60 + sec / 3600;
      return isNeg ? -decimal : decimal;
    };

    // Saf Değer ve Tip Ayrıştırıcı (Marka Metinlerinden Tamamen Bağımsız)
    const extractValueByPattern = (token) => {
      const s = token.trim();
      if (!s) return;

      // 1. Kot / Yükseklik Kalıpları
      if (/^(EL|ELEV|HT|HEIGHT|Z)[\s:]/i.test(s) || (/^EL[\d.-]/i.test(s) && !/^ELIP/i.test(s))) {
        const v = parseFloat(s.replace(/^[A-Za-z\s:]+/, "").trim());
        if (!isNaN(v)) { curRecord.h = v; curRecord.elRaw = v; }
      }
      // 2. Coğrafi Enlem Kalıpları (Carlson RW5 formatında LA: DD.MMSSssss)
      else if (/^(LA|LAT|LATITUDE)[\s:]?/i.test(s)) {
        const v = parseFloat(s.replace(/^[A-Za-z\s:]+/, "").trim());
        if (!isNaN(v)) {
          curRecord.latRaw = v;
          curRecord.lat = dmsToDecimal(v);
        }
      }
      // 3. Coğrafi Boylam Kalıpları (Carlson RW5 formatında LN: DD.MMSSssss)
      else if (/^(LN|LON|LONG|LONGITUDE)[\s:]?/i.test(s)) {
        const v = parseFloat(s.replace(/^[A-Za-z\s:]+/, "").trim());
        if (!isNaN(v)) {
          curRecord.lonRaw = v;
          curRecord.lon = dmsToDecimal(v);
        }
      }
      // 4. Projeksiyon Kuzey / Northing Kalıpları
      else if (/^(N|NORTH|NOR)[\s:]/i.test(s) || (/^N[\d.-]/i.test(s) && !/^NO/i.test(s))) {
        const v = parseFloat(s.replace(/^[A-Za-z\s:]+/, "").trim());
        if (!isNaN(v)) curRecord.n = v;
      }
      // 5. Projeksiyon Doğu / Easting Kalıpları
      else if (/^(E|EAST|EAS)[\s:]/i.test(s) || (/^E[\d.-]/i.test(s) && !/^(EL|EP|ET)/i.test(s))) {
        const v = parseFloat(s.replace(/^[A-Za-z\s:]+/, "").trim());
        if (!isNaN(v)) curRecord.e = v;
      }
    };

    for (let rawLine of lines) {
      const line = rawLine.trim();
      if (!line) continue;

      // A. OTONOM BAZ İSTASYONU TESPİTİ (Sadece geodezik baz belirteçleri)
      if (line.startsWith("BP,") || line.startsWith("--BP,") || line.includes("SRBASE") || line.includes("Base Configuration") || line.includes("OCCUPY")) {
        commitPoint();
        isBaseContext = true;
        continue;
      }

      // B. OTONOM NOKTA BAŞLANGICI (Herhangi bir nokta başlatan kayıt: GPS, EP, SP, AP, POS, PNT vb.)
      if (line.startsWith("GPS,") || line.startsWith("--GPS,") || line.startsWith("EP,") || line.startsWith("SP,") || line.startsWith("AP,") || line.startsWith("POS,") || line.startsWith("PNT,")) {
        commitPoint();
        isBaseContext = false;
        const parts = line.split(",");
        if (parts.length >= 2) {
          curRecord.pn = parts[1].replace(/^(PN|EP|SP|AP|POS|PNT):?/i, "").trim();
          for (let seg of parts.slice(2)) {
            extractValueByPattern(seg);
          }
        }
      }
      // C. KOORDİNAT VERİ SATIRLARI (GS, --GS vb.)
      else if (line.startsWith("GS,") || line.startsWith("--GS,")) {
        if (isBaseContext) continue;
        const parts = line.split(",");
        if (parts.length >= 2) {
          const possiblePn = parts[1].replace(/^(PN|POS):?/i, "").trim();
          if (curRecord.pn && curRecord.pn !== possiblePn && (curRecord.n !== undefined || curRecord.lat !== undefined)) {
            commitPoint();
          }
          if (!curRecord.pn) curRecord.pn = possiblePn;
          for (let seg of parts.slice(2)) {
            extractValueByPattern(seg);
          }
        }
      }
      // D. GPS ZAMAN VE HAFTA DESENİ
      else if (line.includes("SW") && line.includes("ST") && (line.startsWith("--GT") || line.startsWith("GT"))) {
        const parts = line.split(",");
        let swVal = null;
        let stVal = null;
        for (let p of parts) {
          p = p.trim();
          if (p.startsWith("SW")) swVal = parseInt(p.substring(2), 10);
          else if (p.startsWith("ST")) stVal = parseFloat(p.substring(2)) / (p.length > 8 ? 1000.0 : 1.0);
        }
        if (swVal !== null && stVal !== null) {
          const dtObj = parseGpsTime(swVal, stVal);
          if (!isNaN(dtObj.getTime())) {
            curRecord.timestamp = dtObj;
            curRecord.dt = `${String(dtObj.getUTCMonth() + 1).padStart(2, "0")}-${String(dtObj.getUTCDate()).padStart(2, "0")}-${dtObj.getUTCFullYear()}`;
            curRecord.tm = `${String(dtObj.getUTCHours()).padStart(2, "0")}:${String(dtObj.getUTCMinutes()).padStart(2, "0")}:${String(dtObj.getUTCSeconds()).padStart(2, "0")}`;
          }
        }
      }
      // E. TARİH VE SAAT DESENLERİ
      else if (line.startsWith("JB,") || line.startsWith("JOB,")) {
        const parts = line.split(",");
        for (let p of parts) {
          p = p.trim();
          if (p.startsWith("DT")) fallbackDate = p.substring(2).trim();
          else if (p.startsWith("TM")) fallbackTime = p.substring(2).trim();
        }
      } else if (line.startsWith("--DT") || line.startsWith("--Date:") || line.startsWith("DT,")) {
        const d = line.replace(/^(--DT|--Date:|DT,):?/i, "").trim();
        if (!isBaseContext) curRecord.dt = d;
        if (!fallbackDate) fallbackDate = d;
      } else if (line.startsWith("--TM") || line.startsWith("--Time:") || line.startsWith("TM,")) {
        const t = line.replace(/^(--TM|--Time:|TM,):?/i, "").trim();
        if (!isBaseContext) curRecord.tm = t;
        if (!fallbackTime) fallbackTime = t;
      }
      // F. JALON VE ANTEN YÜKSEKLİK DESENLERİ
      else if (line.includes("HR:") || line.startsWith("LS,HR") || line.includes("Jalon") || line.includes("Antenna")) {
        const m = line.match(/(?:HR|HT|Jalon Y\w+kseklik):\s*([\d.]+)/i) || line.match(/LS,HR\s*([\d.]+)/i);
        if (m) curRecord.hr = m[1];
      }
      // G. KALİTE VE RMS DEĞERLERİ
      else if (line.includes("HSDV") || line.includes("RMS") || line.includes("STATUS:") || line.includes("SATS:")) {
        const tokens = line.replace(/^--/, "").split(",");
        for (let t of tokens) {
          if (t.includes(":")) {
            const [k, v] = t.split(":");
            curRecord[k.trim().toLowerCase()] = v.trim();
          }
        }
      }
      // H. SAYISAL İSTATİSTİK VE ORTALAMA DEĞERLER
      else if (line.includes("Avg:")) {
        const mNor = line.match(/(?:Nor|North|Yukarı)\s*Avg:\s*([\d.]+)/i);
        if (mNor) curRecord.n = parseFloat(mNor[1]);
        const mEas = line.match(/(?:Eas|East|Sağa)\s*Avg:\s*([\d.]+)/i);
        if (mEas) curRecord.e = parseFloat(mEas[1]);
        const mElv = line.match(/(?:Elv|Elev|Kot|Height)\s*Avg:\s*([\d.]+)/i);
        if (mElv) {
          curRecord.h = parseFloat(mElv[1]);
          curRecord.elRaw = parseFloat(mElv[1]);
        }
        const mHsdv = line.match(/(?:HSDV|HRMS)\s*Avg:\s*([\d.]+)/i);
        if (mHsdv) curRecord.hsdvVal = parseFloat(mHsdv[1]);
        const mVsdv = line.match(/(?:VSDV|VRMS)\s*Avg:\s*([\d.]+)/i);
        if (mVsdv) curRecord.vsdvVal = parseFloat(mVsdv[1]);
        const mPdop = line.match(/PDOP\s*Avg:\s*([\d.]+)/i);
        if (mPdop) curRecord.pdop = parseFloat(mPdop[1]).toFixed(2);
        const mSats = line.match(/(?:Satellites|Uydu)\s*Avg:\s*(\d+)/i);
        if (mSats) curRecord.sats = parseInt(mSats[1], 10);
        const mFixed = line.match(/Fixed\s*Readings:\s*(\d+)\s+of\s+(\d+)/i);
        if (mFixed) {
          curRecord.epochs = parseInt(mFixed[2], 10);
          curRecord.status = parseInt(mFixed[1], 10) > 0 ? "FIXED" : "FLOAT";
        }
      }
    }

    commitPoint();

    this.rawPoints = points;
    return points;
  }

  /**
   * FieldGenius / Carlson RAW Formatını Ayrıştırır
   */
  parseRawFieldGenius(rawContent) {
    return this.parseRw5(rawContent);
  }

  /**
   * CHCNAV LandStar veya Standart CSV Tablo Formatını Ayrıştırır
   */
  parseCsv(csvContent) {
    const lines = csvContent.split("\n");
    const points = [];

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line || (i === 0 && (line.includes("Point") || line.includes("Nokta")))) {
        continue;
      }

      const cols = line.split(/[,;\t]/).map(c => c.trim());
      if (cols.length >= 4) {
        const pName = cols[0];
        const coord1 = parseFloat(cols[1]);
        const coord2 = parseFloat(cols[2]);
        const coordH = parseFloat(cols[3]);

        if (!isNaN(coord1) && !isNaN(coord2)) {
          const dateStr = cols[4] || "2026-03-13";
          const timeStr = cols[5] || "12:00:00";
          const sats = parseInt(cols[6], 10) || 30;
          const pdop = parseFloat(cols[7])?.toFixed(2) || "1.05";
          const hsdv = parseFloat(cols[8]) || 0.007;

          let ts = new Date();
          if (dateStr.includes("-") || dateStr.includes("/") || dateStr.includes(".")) {
            ts = new Date(dateStr + (timeStr ? ` ${timeStr}` : ""));
          }

          // Sağa Değer (Y) ve Yukarı Değer (X) Ayrımı (X > Y)
          const easting = coord1 > coord2 ? coord2 : coord1;
          const northing = coord1 > coord2 ? coord1 : coord2;
          const hVal = isNaN(coordH) ? 1000.0 : coordH;

          let lat = 39.0;
          let lon = 35.0;
          if (this.geodesy) {
            const geo = this.geodesy.inverseTM(easting, northing, this.centralMeridian, 1.0, false);
            lat = geo.lat;
            lon = geo.lon;
          }

          points.push({
            pn: pName,
            e: easting,
            n: northing,
            h: hVal,
            orthoH: hVal - this.geoidN,
            dt: dateStr,
            tm: timeStr,
            timestamp: isNaN(ts.getTime()) ? new Date() : ts,
            hsdvVal: hsdv,
            vsdvVal: hsdv * 1.4,
            sats: sats,
            pdop: pdop,
            status: "FIXED",
            hr: "1.800",
            epochs: 5,
            hz: 1,
            method: "RTCM",
            network: "VRS",
            measure: "MEAN",
            code: "",
            lat: lat,
            lon: lon,
            latDec: lat,
            lonDec: lon,
            latDms: this.geodesy ? this.geodesy.toDms(lat, true) : `${lat.toFixed(7)}° N`,
            lonDms: this.geodesy ? this.geodesy.toDms(lon, false) : `${lon.toFixed(7)}° E`
          });
        }
      }
    }

    this.rawPoints = points;
    return points;
  }

  /**
   * Boşlukla Ayrılmış Genel Koordinat Metinlerini (Nokta No, Y, X, Z) Ayrıştırır
   */
  parseGenericText(textContent) {
    const lines = textContent.split("\n");
    const points = [];

    for (let rawLine of lines) {
      const line = rawLine.trim();
      if (!line || line.startsWith("//") || line.startsWith("#")) continue;

      const tokens = line.split(/\s+/);
      if (tokens.length >= 4) {
        const pName = tokens[0];
        const easting = parseFloat(tokens[1]);
        const northing = parseFloat(tokens[2]);
        const hVal = parseFloat(tokens[3]);

        if (!isNaN(easting) && !isNaN(northing)) {
          const validH = isNaN(hVal) ? 1000.0 : hVal;
          let lat = 39.0;
          let lon = 35.0;
          if (this.geodesy) {
            const geo = this.geodesy.inverseTM(easting, northing, this.centralMeridian, 1.0, false);
            lat = geo.lat;
            lon = geo.lon;
          }

          points.push({
            pn: pName,
            e: easting,
            n: northing,
            h: validH,
            orthoH: validH - this.geoidN,
            dt: "2026-03-13",
            tm: "12:00:00",
            timestamp: new Date(),
            hsdvVal: 0.007,
            vsdvVal: 0.010,
            sats: 28,
            pdop: "1.05",
            status: "FIXED",
            hr: "1.800",
            epochs: 5,
            hz: 1,
            method: "RTCM",
            network: "VRS",
            measure: "MEAN",
            code: "",
            lat: lat,
            lon: lon,
            latDec: lat,
            lonDec: lon,
            latDms: this.geodesy ? this.geodesy.toDms(lat, true) : `${lat.toFixed(7)}° N`,
            lonDms: this.geodesy ? this.geodesy.toDms(lon, false) : `${lon.toFixed(7)}° E`
          });
        }
      }
    }

    this.rawPoints = points;
    return points;
  }

  /**
   * Trimble Access (.JXL) XML Formatını Ayrıştırır
   */
  parseTrimbleJxl(jxlContent) {
    const points = [];
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(jxlContent, "text/xml");
    const records = xmlDoc.getElementsByTagName("PointRecord");

    for (let rec of records) {
      const pName = rec.getElementsByTagName("Name")[0]?.textContent || "";
      const gridNodes = rec.getElementsByTagName("Grid");

      let northing = 0;
      let easting = 0;
      let elev = 0;

      if (gridNodes.length > 0) {
        northing = parseFloat(gridNodes[0].getElementsByTagName("North")[0]?.textContent || 0);
        easting = parseFloat(gridNodes[0].getElementsByTagName("East")[0]?.textContent || 0);
        elev = parseFloat(gridNodes[0].getElementsByTagName("Elevation")[0]?.textContent || 0);
      }

      if (pName && (northing || easting)) {
        let lat = 39.0;
        let lon = 35.0;
        if (this.geodesy) {
          const geo = this.geodesy.inverseTM(easting, northing, this.centralMeridian, 1.0, false);
          lat = geo.lat;
          lon = geo.lon;
        }

        points.push({
          pn: pName,
          n: northing,
          e: easting,
          h: elev,
          orthoH: elev - this.geoidN,
          dt: "2026-03-13",
          tm: "12:00:00",
          timestamp: new Date(),
          hsdvVal: 0.006,
          vsdvVal: 0.009,
          sats: 30,
          pdop: "1.02",
          status: "FIXED",
          hr: "1.800",
          epochs: 5,
          hz: 1,
          method: "RTCM",
          network: "VRS",
          measure: "MEAN",
          code: "",
          lat: lat,
          lon: lon,
          latDec: lat,
          lonDec: lon,
          latDms: this.geodesy ? this.geodesy.toDms(lat, true) : `${lat.toFixed(7)}° N`,
          lonDms: this.geodesy ? this.geodesy.toDms(lon, false) : `${lon.toFixed(7)}° E`
        });
      }
    }

    this.rawPoints = points;
    return points;
  }

  /**
   * Saniye Cinsinden Zaman Farkını Doğal Türkçe Formatına Dönüştürür (örn: "22 sn", "14 dk 30 sn", "1 sa 15 dk")
   */
  formatHumanTimeDiff(totalSeconds) {
    const s = Math.max(0, Math.round(totalSeconds));
    if (s < 60) return `${s} sn`;
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    if (mins < 60) return secs > 0 ? `${mins} dk ${secs} sn` : `${mins} dk`;
    const hours = Math.floor(mins / 60);
    const remMins = mins % 60;
    return remMins > 0 ? `${hours} sa ${remMins} dk` : `${hours} sa`;
  }

  /**
   * BÖHHBÜY / Kadastro Standartlarında Çift Okuma Kontrolü & Fark Analizi Yapar
   */
  analyzeDoubleReadings(maxDistCm = 7.0, minTimeDiffMin = 60, matchRadiusM = 1.0) {
    const points = this.rawPoints;
    const matchedList = [];
    const usedIndices = new Set();

    for (let i = 0; i < points.length; i++) {
      if (usedIndices.has(i)) continue;
      const p1 = points[i];
      let bestMatch = null;
      let minDistance = 999999;

      for (let j = 0; j < points.length; j++) {
        if (i === j || usedIndices.has(j)) continue;
        const p2 = points[j];
        const dy = p2.e - p1.e;
        const dx = p2.n - p1.n;
        const dist2d = Math.hypot(dy, dx);

        if (dist2d <= matchRadiusM && dist2d < minDistance) {
          minDistance = dist2d;
          bestMatch = { j: j, p2: p2, dist2d: dist2d };
        }
      }

      if (bestMatch) {
        const { j: matchIdx, p2, dist2d } = bestMatch;
        usedIndices.add(i);
        usedIndices.add(matchIdx);

        const dyCm = (p2.e - p1.e) * 100.0;
        const dxCm = (p2.n - p1.n) * 100.0;
        const dhCm = (p2.h - p1.h) * 100.0;
        const ds2dCm = dist2d * 100.0;
        const ds3dCm = Math.hypot(dist2d, p2.h - p1.h) * 100.0;

        let timeDiffSec = 0;
        if (p1.timestamp && p2.timestamp) {
          timeDiffSec = Math.abs(p2.timestamp - p1.timestamp) / 1000.0;
        }
        const timeDiffMin = timeDiffSec / 60.0;

        const isDistPassed = ds2dCm <= maxDistCm;
        const isTimePassed = timeDiffMin >= minTimeDiffMin;

        const avgEasting = (p1.e + p2.e) / 2.0;
        const avgNorthing = (p1.n + p2.n) / 2.0;
        const avgHeight = (p1.h + p2.h) / 2.0;

        matchedList.push({
          p1: p1,
          p2: p2,
          pointName: p1.pn === p2.pn ? p1.pn : `${p1.pn} / ${p2.pn}`,
          dy: dyCm.toFixed(1),
          dx: dxCm.toFixed(1),
          dh: dhCm.toFixed(1),
          ds2d: ds2dCm.toFixed(1),
          ds3d: ds3dCm.toFixed(1),
          timeDiffSec: Math.round(timeDiffSec),
          timeDiffMin: timeDiffMin.toFixed(1),
          timeDiffStr: this.formatHumanTimeDiff(timeDiffSec),
          timeDiffHours: (timeDiffMin / 60.0).toFixed(2),
          isDistPassed: isDistPassed,
          isTimePassed: isTimePassed,
          avgE: avgEasting.toFixed(3),
          avgN: avgNorthing.toFixed(3),
          avgH: avgHeight.toFixed(3)
        });
      }
    }

    const unmatchedList = [];
    for (let i = 0; i < points.length; i++) {
      if (!usedIndices.has(i)) {
        unmatchedList.push(points[i]);
      }
    }

    this.matchedPairs = matchedList;
    this.unmatchedPoints = unmatchedList;

    return {
      matched: matchedList,
      unmatched: unmatchedList,
      matchedPairs: matchedList,
      unmatchedPoints: unmatchedList
    };
  }

  /**
   * Formatlanmış Metin Çıktısı Üretir
   */
  exportFormattedCoordinateList(formatType = "Pt,E,N,h") {
    let out = "";
    for (let p of this.rawPoints) {
      const eStr = p.e.toFixed(3);
      const nStr = p.n.toFixed(3);
      const hStr = p.h.toFixed(3);

      if (formatType === "Pt,E,N,h") {
        out += `${p.pn.padEnd(10, " ")} ${eStr.padStart(12, " ")} ${nStr.padStart(12, " ")} ${hStr.padStart(10, " ")}\n`;
      } else if (formatType === "Pt,N,E,h") {
        out += `${p.pn.padEnd(10, " ")} ${nStr.padStart(12, " ")} ${eStr.padStart(12, " ")} ${hStr.padStart(10, " ")}\n`;
      } else if (formatType === "E,N,h,Pt") {
        out += `${eStr.padStart(12, " ")} ${nStr.padStart(12, " ")} ${hStr.padStart(10, " ")}   ${p.pn}\n`;
      } else if (formatType === "CSV_Y_X_H") {
        out += `${p.pn},${eStr},${nStr},${hStr}\n`;
      }
    }
    return out;
  }

  /**
   * HGM TG-20 Türkiye Hibrit Jeoidi İndirgemesi Uygular (H = h - N)
   */
  applyTg20Reduction(tg20Engine, fallbackGeodesyEngine = null, customEngine = null, applyState = true) {
    this.isTg20Applied = applyState;

    if (!applyState || !tg20Engine) {
      for (let pair of this.matchedPairs) {
        pair.isTg20Applied = false;
        pair.currentH = pair.avgH;
      }
      for (let pt of this.unmatchedPoints) {
        pt.isTg20Applied = false;
        pt.currentH = pt.h.toFixed(3);
      }
      for (let pt of this.rawPoints) {
        pt.isTg20Applied = false;
        pt.currentH = pt.h.toFixed(3);
      }
      return true;
    }

    const dom = this.centralMeridian || 30;
    const geodesy = this.geodesy || fallbackGeodesyEngine;

    // 1. Çift Okumaları İndirge
    for (let pair of this.matchedPairs) {
      const avgE = parseFloat(pair.avgE);
      const avgN = parseFloat(pair.avgN);
      const avgH = parseFloat(pair.avgH);

      let lat = pair.p1?.lat || pair.p1?.latDec || pair.p2?.lat || pair.p2?.latDec;
      let lon = pair.p1?.lon || pair.p1?.lonDec || pair.p2?.lon || pair.p2?.lonDec;

      if ((!lat || !lon) && geodesy && avgE && avgN) {
        try {
          const geo = geodesy.inverseTM(avgE, avgN, dom);
          lat = geo.lat;
          lon = geo.lon;
        } catch (e) {}
      }

      if (lat && lon) {
        const red = tg20Engine.reduceHeight(lat, lon, avgH);
        if (red.inBounds && red.N !== null) {
          pair.tg20N = red.N.toFixed(3);
          pair.avgOrthoH = red.H.toFixed(3);
          pair.currentH = pair.avgOrthoH;
          pair.isTg20Applied = true;
        } else {
          pair.isTg20Applied = false;
          pair.currentH = pair.avgH;
        }
      } else {
        pair.isTg20Applied = false;
        pair.currentH = pair.avgH;
      }
    }

    // 2. Ham Noktaları İndirge
    for (let pt of this.rawPoints) {
      let lat = pt.lat || pt.latDec;
      let lon = pt.lon || pt.lonDec;

      if ((!lat || !lon) && geodesy && pt.e && pt.n) {
        try {
          const geo = geodesy.inverseTM(pt.e, pt.n, dom);
          lat = geo.lat;
          lon = geo.lon;
          pt.lat = lat;
          pt.lon = lon;
          pt.latDec = lat;
          pt.lonDec = lon;
        } catch (e) {}
      }

      if (lat && lon) {
        const red = tg20Engine.reduceHeight(lat, lon, pt.h);
        if (red.inBounds && red.N !== null) {
          pt.tg20N = red.N.toFixed(3);
          pt.orthoH = red.H;
          pt.currentH = red.H.toFixed(3);
          pt.isTg20Applied = true;
        } else {
          pt.isTg20Applied = false;
          pt.currentH = pt.h.toFixed(3);
        }
      }
    }

    // 3. Tekil Noktaları İndirge
    for (let pt of this.unmatchedPoints) {
      let lat = pt.lat || pt.latDec;
      let lon = pt.lon || pt.lonDec;

      if ((!lat || !lon) && geodesy && pt.e && pt.n) {
        try {
          const geo = geodesy.inverseTM(pt.e, pt.n, dom);
          lat = geo.lat;
          lon = geo.lon;
          pt.lat = lat;
          pt.lon = lon;
          pt.latDec = lat;
          pt.lonDec = lon;
        } catch (e) {}
      }

      if (lat && lon) {
        const red = tg20Engine.reduceHeight(lat, lon, pt.h);
        if (red.inBounds && red.N !== null) {
          pt.tg20N = red.N.toFixed(3);
          pt.orthoH = red.H;
          pt.currentH = red.H.toFixed(3);
          pt.isTg20Applied = true;
        } else {
          pt.isTg20Applied = false;
          pt.currentH = pt.h.toFixed(3);
        }
      }
    }

    return true;
  }

  /**
   * Metin Bazlı TG-20 İndirgeme Raporu Üretir
   */
  exportTg20ReductionReport(projectName = "GNSS_RTK_TG20_Indirgeme") {
    const dateStr = new Date().toLocaleDateString("tr-TR");
    const reportPoints = [];

    for (let pair of this.matchedPairs) {
      if (pair.isTg20Applied && pair.avgOrthoH) {
        reportPoints.push({
          name: pair.pointName,
          lat: pair.p1?.lat || pair.p1?.latDec || pair.p2?.lat || pair.p2?.latDec || "",
          lon: pair.p1?.lon || pair.p1?.lonDec || pair.p2?.lon || pair.p2?.lonDec || "",
          y: pair.avgE,
          x: pair.avgN,
          h: pair.avgH,
          N: pair.tg20N,
          H: pair.avgOrthoH,
          type: "Çift Okuma Ort."
        });
      }
    }

    for (let pt of this.unmatchedPoints) {
      if (pt.isTg20Applied && pt.orthoH !== undefined) {
        reportPoints.push({
          name: pt.pn,
          lat: pt.lat || pt.latDec || "",
          lon: pt.lon || pt.lonDec || "",
          y: pt.e.toFixed(3),
          x: pt.n.toFixed(3),
          h: pt.h.toFixed(3),
          N: pt.tg20N,
          H: pt.orthoH.toFixed(3),
          type: "Tekil Ölçü"
        });
      }
    }

    let rpt = "========================================================================================\n";
    rpt += "    GNSS POS WEB STUDIO - TG-20 JEOİT İNDİRGEME RAPORU (GPSFormat Entegrasyonu)     \n";
    rpt += "========================================================================================\n";
    rpt += `Proje / Dosya       : ${projectName}\n`;
    rpt += "Jeoit Modeli        : Harita Genel Müdürlüğü TG-20 (Türkiye Hibrit Jeoidi 2020)\n";
    rpt += `Projeksiyon         : ITRF-96 TM 3° Dilim ${this.centralMeridian}° E\n`;
    rpt += `Tarih               : ${dateStr}\n`;
    rpt += `Toplam Nokta Sayısı : ${reportPoints.length}\n`;
    rpt += "Temel Bağıntı       : H (Ortometrik) = h (Elipsoit) - N (Jeoit Undülasyonu)\n";
    rpt += "----------------------------------------------------------------------------------------\n";
    rpt += "NOKTA ADI      ENLEM (Lat)  BOYLAM (Lon)  Y (Sağa)       X (Yukarı)     ELİP.(h)   JEOİT(N)  ORT.(H)   TİP\n";
    rpt += "----------------------------------------------------------------------------------------\n";

    for (let p of reportPoints) {
      const pName = String(p.name).padEnd(14, " ");
      const latStr = p.lat ? parseFloat(p.lat).toFixed(6).padStart(11, " ") : "     -     ";
      const lonStr = p.lon ? parseFloat(p.lon).toFixed(6).padStart(12, " ") : "      -      ";
      const yStr = String(p.y).padStart(14, " ");
      const xStr = String(p.x).padStart(14, " ");
      const hStr = String(p.h).padStart(9, " ");
      const nStr = (`+${p.N}`).padStart(9, " ");
      const bigHStr = String(p.H).padStart(9, " ");

      rpt += `${pName} ${latStr} ${lonStr} ${yStr} ${xStr} ${hStr} ${nStr} ${bigHStr}   ${p.type}\n`;
    }

    rpt += "========================================================================================\n";
    rpt += "NOT: Elipsoit Kotları (h) GPS/GNSS ölçümünden, Ortometrik Kotlar (H) TG-20 indirgeme\n";
    rpt += "     sonucu hesaplanmıştır. Bu rapor resmi kadastro işlemlerinde referans olarak kullanılabilir.\n";
    rpt += "========================================================================================\n";

    return rpt;
  }

  /**
   * Yazdırılabilir / PDF Kaydedilebilir A4 TG-20 Raporu HTML Şablonu Üretir
   */
  generatePrintableTg20Report(projectName = "GNSS RTK / CORS ÖLÇÜLERİ TG-20 İNDİRGEME RAPORU", externalTg20 = null, externalGeodesy = null) {
    const curDate = new Date().toLocaleDateString("tr-TR", { day: "2-digit", month: "2-digit", year: "numeric" });
    const curTime = new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });

    const reportRows = [];
    const tg20Engine = externalTg20 || (typeof state !== "undefined" ? state.tg20Engine : null);
    const geodesyEngine = this.geodesy || externalGeodesy || (typeof state !== "undefined" ? state.geodesyEngine : null);
    const dom = this.centralMeridian || 30;

    for (let pair of this.matchedPairs) {
      let lat = pair.p1?.lat || pair.p1?.latDec || pair.p2?.lat || pair.p2?.latDec;
      let lon = pair.p1?.lon || pair.p1?.lonDec || pair.p2?.lon || pair.p2?.lonDec;
      const eVal = parseFloat(pair.avgE);
      const nVal = parseFloat(pair.avgN);
      const hVal = parseFloat(pair.avgH);

      if ((!lat || !lon) && geodesyEngine && eVal && nVal) {
        try {
          const geo = geodesyEngine.inverseTM(eVal, nVal, dom);
          lat = geo.lat;
          lon = geo.lon;
        } catch (e) {}
      }

      let nStr = pair.tg20N;
      let hStr = pair.avgOrthoH;

      if ((!nStr || nStr === "--") && tg20Engine && lat && lon) {
        const red = tg20Engine.reduceHeight(lat, lon, hVal);
        if (red.inBounds && red.N !== null) {
          nStr = red.N.toFixed(3);
          hStr = red.H.toFixed(3);
          pair.tg20N = nStr;
          pair.avgOrthoH = hStr;
        }
      }

      reportRows.push({
        name: pair.pointName,
        lat: lat ? lat.toFixed(6) : "-",
        lon: lon ? lon.toFixed(6) : "-",
        y: pair.avgE,
        x: pair.avgN,
        h: pair.avgH,
        N: nStr ? (nStr.startsWith("+") || nStr.startsWith("-") ? nStr : `+${nStr}`) : "--",
        H: hStr || pair.avgH,
        type: "Çift Okuma Ort."
      });
    }

    for (let pt of this.unmatchedPoints) {
      let lat = pt.lat || pt.latDec;
      let lon = pt.lon || pt.lonDec;

      if ((!lat || !lon) && geodesyEngine && pt.e && pt.n) {
        try {
          const geo = geodesyEngine.inverseTM(pt.e, pt.n, dom);
          lat = geo.lat;
          lon = geo.lon;
        } catch (e) {}
      }

      let nStr = pt.tg20N;
      let hStr = pt.orthoH !== undefined ? pt.orthoH.toFixed(3) : null;

      if ((!nStr || nStr === "--") && tg20Engine && lat && lon) {
        const red = tg20Engine.reduceHeight(lat, lon, pt.h);
        if (red.inBounds && red.N !== null) {
          nStr = red.N.toFixed(3);
          hStr = red.H.toFixed(3);
          pt.tg20N = nStr;
          pt.orthoH = red.H;
        }
      }

      reportRows.push({
        name: pt.pn,
        lat: lat ? lat.toFixed(6) : "-",
        lon: lon ? lon.toFixed(6) : "-",
        y: pt.e.toFixed(3),
        x: pt.n.toFixed(3),
        h: pt.h.toFixed(3),
        N: nStr ? (nStr.startsWith("+") || nStr.startsWith("-") ? nStr : `+${nStr}`) : "--",
        H: hStr || pt.h.toFixed(3),
        type: "Tekil Ölçü"
      });
    }

    const nNumList = reportRows.map(r => parseFloat(r.N)).filter(v => !isNaN(v));
    const avgUndulation = nNumList.length > 0 ? (nNumList.reduce((a, b) => a + b, 0) / nNumList.length) : 0;

    let html = `
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>${projectName} - GNSS Pos Web Studio</title>
  <style>
    @page { size: A4 portrait; margin: 12mm 15mm 15mm 15mm; }
    * { box-sizing: border-box; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
    body { font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif; font-size: 10.5px; color: #1e293b; background: #ffffff; margin: 0; padding: 0; line-height: 1.45; }
    .report-container { width: 100%; max-width: 210mm; margin: 0 auto; }
    .header-banner { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #0f766e; padding-bottom: 10px; margin-bottom: 12px; }
    .brand-title { font-size: 15px; font-weight: 800; color: #0f766e; letter-spacing: 0.5px; text-transform: uppercase; }
    .brand-sub { font-size: 10px; color: #64748b; font-weight: 600; }
    .report-title-box { text-align: center; background: #f0fdfa; border: 1px solid #ccfbf1; padding: 10px 14px; border-radius: 6px; margin-bottom: 14px; }
    .report-title-box h1 { font-size: 13.5px; font-weight: 800; color: #115e59; margin: 0 0 3px 0; text-transform: uppercase; }
    .report-title-box p { font-size: 10.5px; color: #0f766e; margin: 0; font-weight: 500; }
    .meta-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px 14px; margin-bottom: 12px; }
    .meta-item { display: flex; justify-content: space-between; }
    .meta-label { color: #64748b; font-weight: 600; }
    .meta-value { color: #0f172a; font-weight: 700; font-family: 'Consolas', monospace; }
    .formula-card { background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%); border: 1px solid #cbd5e1; border-left: 4px solid #0d9488; padding: 8px 14px; border-radius: 4px; margin-bottom: 14px; display: flex; justify-content: space-between; align-items: center; }
    .formula-math { font-size: 11.5px; font-weight: 700; color: #0f766e; }
    .formula-stats { font-size: 10.5px; color: #475569; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 14px; font-size: 9.5px; }
    th { background-color: #0f766e; color: #ffffff; font-weight: 700; text-transform: uppercase; font-size: 8.5px; padding: 6px 3px; border: 1px solid #0d9488; text-align: center; }
    td { border: 1px solid #cbd5e1; padding: 5px 3px; text-align: center; color: #1e293b; }
    tbody tr:nth-child(even) { background-color: #f8fafc; }
    .col-name { font-weight: 700; color: #0f172a; text-align: left; padding-left: 6px; }
    .col-mono { font-family: 'Consolas', monospace; font-size: 9px; }
    .col-geoid { font-family: 'Consolas', monospace; font-weight: 800; color: #b45309; background: #fef3c7; }
    .col-ortho { font-family: 'Consolas', monospace; font-weight: 800; color: #065f46; background: #d1fae5; }
    .badge-pair { background: #dbeafe; color: #1e40af; font-weight: 700; padding: 2px 4px; border-radius: 3px; font-size: 8px; }
    .badge-single { background: #fef3c7; color: #92400e; font-weight: 700; padding: 2px 4px; border-radius: 3px; font-size: 8px; }
    .disclaimer-card { background: #fffbeb; border: 1px solid #fde68a; border-left: 4px solid #d97706; border-radius: 4px; padding: 10px 12px; margin-top: 14px; font-size: 9px; color: #92400e; line-height: 1.5; }
    .disclaimer-title { font-weight: 800; text-transform: uppercase; margin-bottom: 4px; color: #b45309; }
    .footer-bar { margin-top: 14px; padding-top: 8px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; font-size: 8.5px; color: #94a3b8; }
    .report-meta-right { text-align: right; font-size: 9.5px; color: #64748b; }
    .th-num { width: 3%; }
    .th-name { width: 14%; text-align: left; padding-left: 6px; }
    .th-coord { width: 13%; }
    .th-elev { width: 11%; }
    .th-status { width: 10%; }
    .col-dim { color: #64748b; }
    .empty-table-cell { text-align: center; color: #d97706; padding: 12px; font-weight: 600; }
    .print-btn-float { position: fixed; top: 14px; right: 14px; background: #0f766e; color: #ffffff; border: none; border-radius: 6px; padding: 10px 18px; font-size: 13px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(15, 118, 110, 0.35); z-index: 9999; }
    @media print { .print-btn-float { display: none !important; } }
  </style>
</head>
<body>
  <button class="print-btn-float" onclick="window.print()">🖨️ Yazdır / PDF Kaydet</button>

  <div class="report-container">
    <div class="header-banner">
      <div>
        <div class="brand-title">HARİTA TOOLS — JEODEZİ & GNSS STÜDYOSU</div>
        <div class="brand-sub">Profesyonel Jeodezi, Fotogrametri & GNSS Hesaplama Platformu | Geografik Harita ve Coğrafi Bilgi Teknolojileri</div>
      </div>
      <div class="report-meta-right">
        <div><strong>TUSAGA-Aktif TG-20 Raporu</strong></div>
        <div>Tarih / Saat: <strong>${curDate} ${curTime}</strong></div>
      </div>
    </div>

    <div class="report-title-box">
      <h1>TG-20 TÜRKİYE HİBRİT JEOİDİ ORTOMETRİK KOT İNDİRGEME RAPORU</h1>
      <p>TUSAGA-Aktif (CORS-TR) Ölçümleri Helmert Ortometrik Nivelman Kotu (TUDKA-99) Çetelesi (BÖHHBÜY Standartları)</p>
    </div>

    <div class="meta-grid">
      <div class="meta-item"><span class="meta-label">Proje / Dosya:</span><span class="meta-value">${projectName}</span></div>
      <div class="meta-item"><span class="meta-label">Hesaplama Tarihi:</span><span class="meta-value">${curDate} - ${curTime}</span></div>
      <div class="meta-item"><span class="meta-label">Projeksiyon:</span><span class="meta-value">ITRF-96 TM 3° Dilim ${this.centralMeridian}° E</span></div>
      <div class="meta-item"><span class="meta-label">Kullanılan Jeoit Modeli:</span><span class="meta-value">HGM TG-20 (Türkiye Hibrit Jeoidi 2020)</span></div>
      <div class="meta-item"><span class="meta-label">Toplam Nokta:</span><span class="meta-value">${reportRows.length} Nokta (${this.matchedPairs.length} Çift Okuma, ${this.unmatchedPoints.length} Tekil)</span></div>
      <div class="meta-item"><span class="meta-label">Düşey Referans Sistemi:</span><span class="meta-value">TUDKA-99 (Türkiye Ulusal Düşey Kontrol Ağı)</span></div>
    </div>

    <div class="formula-card">
      <div class="formula-math"><strong>Temel Formül:</strong>&nbsp;&nbsp; H<sub>ortometrik</sub> = h<sub>elipsoit</sub> − N<sub>TG-20</sub></div>
      <div class="formula-stats"><span>Bölgesel Ortalama Jeoit Undülasyonu: <strong>${avgUndulation > 0 ? "+" : ""}${avgUndulation.toFixed(3)} m</strong></span></div>
    </div>

    <table>
      <thead>
        <tr>
          <th class="th-num">#</th>
          <th class="th-name">Nokta No / Adı</th>
          <th class="th-coord">WGS-84 Enlem (ϕ)</th>
          <th class="th-coord">WGS-84 Boylam (λ)</th>
          <th class="th-elev">Y (Sağa - m)</th>
          <th class="th-elev">X (Yukarı - m)</th>
          <th class="th-elev">Elipsoit Kotu (h / m)</th>
          <th class="th-elev">TG-20 Undülasyon (N / m)</th>
          <th class="th-elev">Ortometrik Kot (H / m)</th>
          <th class="th-status">Ölçüm Tipi</th>
        </tr>
      </thead>
      <tbody>
`;

    if (reportRows.length === 0) {
      html += '<tr><td colspan="10" class="empty-table-cell">İndirgenecek koordinat verisi bulunamadı.</td></tr>';
    } else {
      reportRows.forEach((r, idx) => {
        const badgeCls = r.type.includes("Çift") ? "badge-pair" : "badge-single";
        html += `
          <tr>
            <td class="col-mono col-dim">${idx + 1}</td>
            <td class="col-name">${r.name}</td>
            <td class="col-mono">${r.lat}°</td>
            <td class="col-mono">${r.lon}°</td>
            <td class="col-mono">${r.y}</td>
            <td class="col-mono">${r.x}</td>
            <td class="col-mono">${r.h} m</td>
            <td class="col-geoid">${r.N} m</td>
            <td class="col-ortho">${r.H} m</td>
            <td><span class="${badgeCls}">${r.type}</span></td>
          </tr>
        `;
      });
    }

    html += `
      </tbody>
    </table>

    <div class="disclaimer-card">
      <div class="disclaimer-title">⚠️ Yasal Bilgilendirme ve Sorumluluk Reddi Beyanı</div>
      <div>
        Bu hesaplama raporu, Harita Genel Müdürlüğü (HGM) tarafından yayımlanan resmi TG-20 Türkiye Hibrit Jeoidi 2020 modeli grid düğüm noktaları ve çift doğrusal (bilinear) enterpolasyon algoritması kullanılarak <strong>Harita Tools</strong> yazılımı tarafından teknik kontrol ve veri işleme amacıyla üretilmiştir. 
        İşbu raporda yer alan ortometrik kot indirgemeleri (<em>H = h − N</em>) teknik destek niteliğinde olup, Tapu ve Kadastro Genel Müdürlüğü (TKGM) veya Harita Genel Müdürlüğü (HGM) tarafından doğrudan tanzim edilmiş resmi bir idari onay belgesi yerine geçmez.
      </div>
    </div>

    <div class="footer-bar">
      <div>Harita Tools © 2026 | Jeodezi & GNSS Stüdyosu — Geografik Harita ve Coğrafi Bilgi Teknolojileri</div>
      <div>Referans: HGM TG-20 (TUDKA-99 Helmert Ortometrik Yükseklik)</div>
      <div>Sayfa 1 / 1</div>
    </div>
  </div>
</body>
</html>`;

    return html;
  }

  /**
   * AutoCAD .DXF Çizim Metni Üretir (Noktalar, İsimler, Kotlar, Hata Vektörleri Katmanları)
   */
  exportDxfText() {
    let dxf = "0\nSECTION\n2\nHEADER\n0\nENDSEC\n0\nSECTION\n2\nTABLES\n0\nTABLE\n2\nLAYER\n70\n5\n";
    dxf += "0\nLAYER\n2\nNOKTALAR\n70\n0\n62\n7\n6\nCONTINUOUS\n0\n";
    dxf += "LAYER\n2\nNOKTA_ADLARI\n70\n0\n62\n3\n6\nCONTINUOUS\n0\n";
    dxf += "LAYER\n2\nKOTLAR\n70\n0\n62\n4\n6\nCONTINUOUS\n0\n";
    dxf += "LAYER\n2\nTEKIL_NOKTALAR\n70\n0\n62\n1\n6\nCONTINUOUS\n0\n";
    dxf += "LAYER\n2\nHATA_VEKTORLERI\n70\n0\n62\n1\n6\nCONTINUOUS\n0\n";
    dxf += "ENDTAB\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n";

    for (let pair of this.matchedPairs) {
      const eVal = parseFloat(pair.avgE);
      const nVal = parseFloat(pair.avgN);
      const hVal = this.isTg20Applied && pair.avgOrthoH ? parseFloat(pair.avgOrthoH) : parseFloat(pair.avgH);

      dxf += `0\nPOINT\n8\nNOKTALAR\n10\n${eVal}\n20\n${nVal}\n30\n${hVal}\n`;
      dxf += `0\nTEXT\n8\nNOKTA_ADLARI\n10\n${eVal + 0.5}\n20\n${nVal + 0.5}\n30\n${hVal}\n40\n1.2\n1\n${pair.pointName}\n`;
      dxf += `0\nTEXT\n8\nKOTLAR\n10\n${eVal + 0.5}\n20\n${nVal - 1.2}\n30\n${hVal}\n40\n1.0\n1\n${hVal.toFixed(2)}\n`;
      dxf += `0\nLINE\n8\nHATA_VEKTORLERI\n10\n${pair.p1.e}\n20\n${pair.p1.n}\n30\n${pair.p1.h}\n11\n${pair.p2.e}\n21\n${pair.p2.n}\n31\n${pair.p2.h}\n`;
    }

    for (let pt of this.unmatchedPoints) {
      const eVal = pt.e;
      const nVal = pt.n;
      const hVal = this.isTg20Applied && pt.orthoH !== undefined ? pt.orthoH : pt.h;

      dxf += `0\nPOINT\n8\nTEKIL_NOKTALAR\n10\n${eVal}\n20\n${nVal}\n30\n${hVal}\n`;
      dxf += `0\nTEXT\n8\nNOKTA_ADLARI\n10\n${eVal + 0.5}\n20\n${nVal + 0.5}\n30\n${hVal}\n40\n1.2\n1\n${pt.pn}\n`;
      dxf += `0\nTEXT\n8\nKOTLAR\n10\n${eVal + 0.5}\n20\n${nVal - 1.2}\n30\n${hVal}\n40\n1.0\n1\n${hVal.toFixed(2)}\n`;
    }

    dxf += "0\nENDSEC\n0\nEOF\n";
    return dxf;
  }

  /**
   * Netcad .KOS Formatında Nokta Listesi Üretir
   */
  exportKosText() {
    let kos = "; NETCAD KOS FORMATI - GNSS KADASTRO CETELERI\n";
    for (let pair of this.matchedPairs) {
      const hVal = this.isTg20Applied && pair.avgOrthoH ? pair.avgOrthoH : pair.avgH;
      kos += `NOKTA ${pair.pointName} Y=${pair.avgE} X=${pair.avgN} Z=${hVal} dS=${pair.ds2d}cm\n`;
    }
    return kos;
  }

  /**
   * Netcad .NCN Formatında Nokta Listesi Üretir
   */
  exportNcnText() {
    let ncn = "";
    for (let pair of this.matchedPairs) {
      const hVal = this.isTg20Applied && pair.avgOrthoH ? pair.avgOrthoH : pair.avgH;
      ncn += `${pair.pointName.padEnd(14, " ")} ${pair.avgE.padStart(12, " ")} ${pair.avgN.padStart(12, " ")} ${hVal.padStart(10, " ")}\n`;
    }
    for (let pt of this.unmatchedPoints) {
      const hVal = this.isTg20Applied && pt.orthoH !== undefined ? pt.orthoH.toFixed(3) : pt.h.toFixed(3);
      ncn += `${pt.pn.padEnd(14, " ")} ${pt.e.toFixed(3).padStart(12, " ")} ${pt.n.toFixed(3).padStart(12, " ")} ${hVal.padStart(10, " ")}\n`;
    }
    return ncn;
  }

  /**
   * Google Earth .KML Formatında Nokta ve Detay Bilgilerini Üretir
   */
  exportKmlText() {
    let kml = `<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
<Document>
<name>Kadastro GNSS Olculeri</name>
`;

    for (let pair of this.matchedPairs) {
      let lat = pair.p1?.lat ?? pair.p1?.latDec;
      let lon = pair.p1?.lon ?? pair.p1?.lonDec;
      if ((lat === undefined || lon === undefined) && this.geodesy && pair.avgE && pair.avgN) {
        try {
          const geo = this.geodesy.inverseTM(parseFloat(pair.avgE), parseFloat(pair.avgN), this.centralMeridian, 1.0, false);
          lat = geo.lat;
          lon = geo.lon;
        } catch (e) {}
      }
      lat = lat !== undefined ? lat : 39.0;
      lon = lon !== undefined ? lon : 35.0;
      const hVal = this.isTg20Applied && pair.avgOrthoH ? pair.avgOrthoH : pair.avgH;
      const timeDisplay = pair.timeDiffStr || `${pair.timeDiffMin} dk`;

      kml += `
  <Placemark>
    <name>${pair.pointName}</name>
    <description><![CDATA[
      <b>Nokta:</b> ${pair.pointName}<br>
      <b>Fark (dS):</b> ${pair.ds2d} cm (${pair.isDistPassed ? "UYGUN" : "LIMIT DISI"})<br>
      <b>Zaman Farkı:</b> ${timeDisplay} (${pair.isTimePassed ? "≥60 dk UYGUN" : "<60 dk YETERSIZ"})<br>
      <b>Ortalama Y:</b> ${pair.avgE}<br>
      <b>Ortalama X:</b> ${pair.avgN}<br>
      <b>Kot (H):</b> ${hVal} ${this.isTg20Applied ? "(TG-20 Ortometrik)" : "(Elipsoit)"}<br>
      <b>Enlem (Lat):</b> ${lat.toFixed(8)}°<br>
      <b>Boylam (Lon):</b> ${lon.toFixed(8)}°
    ]]></description>
    <Point>
      <coordinates>${lon},${lat},${hVal}</coordinates>
    </Point>
  </Placemark>
`;
    }

    for (let pt of this.unmatchedPoints) {
      let lat = pt.lat ?? pt.latDec;
      let lon = pt.lon ?? pt.lonDec;
      if ((lat === undefined || lon === undefined) && this.geodesy && pt.e && pt.n) {
        try {
          const geo = this.geodesy.inverseTM(pt.e, pt.n, this.centralMeridian, 1.0, false);
          lat = geo.lat;
          lon = geo.lon;
        } catch (e) {}
      }
      lat = lat !== undefined ? lat : 39.0;
      lon = lon !== undefined ? lon : 35.0;
      const hVal = this.isTg20Applied && pt.orthoH !== undefined ? pt.orthoH.toFixed(3) : pt.h.toFixed(3);

      kml += `
  <Placemark>
    <name>${pt.pn} (Tekil)</name>
    <description><![CDATA[
      <b>Nokta:</b> ${pt.pn} (Tekil Ölçü)<br>
      <b>Y:</b> ${pt.e.toFixed(3)}<br>
      <b>X:</b> ${pt.n.toFixed(3)}<br>
      <b>Kot (H):</b> ${hVal} ${this.isTg20Applied ? "(TG-20 Ortometrik)" : "(Elipsoit)"}<br>
      <b>Enlem (Lat):</b> ${lat.toFixed(8)}°<br>
      <b>Boylam (Lon):</b> ${lon.toFixed(8)}°
    ]]></description>
    <Point>
      <coordinates>${lon},${lat},${hVal}</coordinates>
    </Point>
  </Placemark>
`;
    }

    kml += "</Document>\n</kml>";
    return kml;
  }

  /**
   * Resmi Kadastro Çift Okuma Kontrol Çetelesini CSV Formatında İhraç Eder
   */
  exportCadastreCsv() {
    let csv = this.isTg20Applied
      ? "Nokta_No,1_Tarih,1_Saat,2_Tarih,2_Saat,Zaman_Farki_Dk,Zaman_Farki_Saat,dY_cm,dX_cm,dH_cm,dS_cm,Hata_Durumu,Zaman_Durumu,Ortalama_Y,Ortalama_X,Elipsoit_H,TG20_Undulasyon_N,Ortometrik_H,Olcu_Tipi\n"
      : "Nokta_No,1_Tarih,1_Saat,2_Tarih,2_Saat,Zaman_Farki_Dk,Zaman_Farki_Saat,dY_cm,dX_cm,dH_cm,dS_cm,Hata_Durumu,Zaman_Durumu,Ortalama_Y,Ortalama_X,Ortalama_H,Olcu_Tipi\n";

    for (let pair of this.matchedPairs) {
      if (this.isTg20Applied) {
        csv += `${pair.pointName},${pair.p1.dt},${pair.p1.tm},${pair.p2.dt},${pair.p2.tm},${pair.timeDiffMin},${pair.timeDiffHours},${pair.dy},${pair.dx},${pair.dh},${pair.ds2d},${pair.isDistPassed ? "UYGUN" : "LIMIT_ASILDI"},${pair.isTimePassed ? "UYGUN" : "YETERSIZ"},${pair.avgE},${pair.avgN},${pair.avgH},${pair.tg20N || ""},${pair.avgOrthoH || pair.avgH},Cift_Okuma\n`;
      } else {
        csv += `${pair.pointName},${pair.p1.dt},${pair.p1.tm},${pair.p2.dt},${pair.p2.tm},${pair.timeDiffMin},${pair.timeDiffHours},${pair.dy},${pair.dx},${pair.dh},${pair.ds2d},${pair.isDistPassed ? "UYGUN" : "LIMIT_ASILDI"},${pair.isTimePassed ? "UYGUN" : "YETERSIZ"},${pair.avgE},${pair.avgN},${pair.avgH},Cift_Okuma\n`;
      }
    }

    for (let pt of this.unmatchedPoints) {
      if (this.isTg20Applied) {
        csv += `${pt.pn},${pt.dt || ""},${pt.tm || ""},--,--,--,--,--,--,--,--,--,--,${pt.e.toFixed(3)},${pt.n.toFixed(3)},${pt.h.toFixed(3)},${pt.tg20N || ""},${pt.orthoH !== undefined ? pt.orthoH.toFixed(3) : pt.h.toFixed(3)},Tekil_Olcu\n`;
      } else {
        csv += `${pt.pn},${pt.dt || ""},${pt.tm || ""},--,--,--,--,--,--,--,--,--,--,${pt.e.toFixed(3)},${pt.n.toFixed(3)},${pt.h.toFixed(3)},Tekil_Olcu\n`;
      }
    }

    return csv;
  }

  /**
   * Yazdırılabilir Resmi Kadastro Çift Okuma Çetelesi HTML Çıktısı Üretir
   */
  generatePrintableCadastreReport(title = "KADASTRO RTK/CORS ÖLÇÜ KONTROL ÇETELESİ") {
    const curDate = new Date().toLocaleDateString("tr-TR");

    let html = `
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>${title}</title>
  <style>
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 11px; margin: 15mm; color: #000; }
    h2, h3 { text-align: center; margin: 2px 0; }
    .header-box { border: 1px solid #333; padding: 8px; margin-bottom: 12px; display: grid; grid-template-columns: 1fr 1fr; font-size: 11px; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 10px; }
    th, td { border: 1px solid #444; padding: 4px 6px; text-align: center; }
    th { background-color: #f2f2f2; font-weight: bold; }
    .passed { color: #059669; font-weight: bold; }
    .warning { color: #d97706; font-weight: bold; }
    .failed { color: #dc2626; font-weight: bold; }
    .footer { margin-top: 30px; display: flex; justify-content: space-between; text-align: center; }
    .sign-box { width: 200px; padding-top: 40px; border-top: 1px solid #333; }
    @media print { body { margin: 0; } button { display: none; } }
  </style>
</head>
<body>
  <h2>T.C. TAPU VE KADASTRO GENEL MÜDÜRLÜĞÜ</h2>
  <h3>TUSAGA-AKTİF (CORS-TR) ÇİFT OKUMA VE KONTROL ÇETELESİ</h3>
  <br>
  <div class="header-box">
    <div><strong>İş / Dosya:</strong> ${title}</div>
    <div><strong>Tarih:</strong> ${curDate}</div>
    <div><strong>Projeksiyon:</strong> ITRF-96 TM 3° Dilim ${this.centralMeridian}° E</div>
    <div><strong>Hata Limiti (dS):</strong> ≤ 7.0 cm | <strong>Min. Zaman:</strong> ≥ 60 Dk</div>
  </div>

  <h4>1. ÇİFT OKUMA VE FARK KONTROL TABLOSU</h4>
  <table>
    <thead>
      <tr>
        <th rowspan="2">Nokta No</th>
        <th colspan="2">1. Ölçü (Zaman)</th>
        <th colspan="2">2. Ölçü (Zaman)</th>
        <th rowspan="2">Zaman Farkı</th>
        <th colspan="3">Farklar (cm)</th>
        <th rowspan="2">dS (2B) (cm)</th>
        <th rowspan="2">Kontrol (≤7cm)</th>
        <th colspan="3">Ortalama Koordinatlar (m)</th>
      </tr>
      <tr>
        <th>Tarih</th>
        <th>Saat</th>
        <th>Tarih</th>
        <th>Saat</th>
        <th>dY</th>
        <th>dX</th>
        <th>dH</th>
        <th>Y (Sağa)</th>
        <th>X (Yukarı)</th>
        <th>H (Kot) ${this.isTg20Applied ? "(TG-20)" : ""}</th>
      </tr>
    </thead>
    <tbody>
`;

    if (this.matchedPairs.length === 0) {
      html += '<tr><td colspan="14" class="empty-table-cell">Bu veri setinde çift okuma (eşleşen) nokta bulunmamaktadır. Tüm ölçüler tekil olarak Tablo 2\'de listelenmiştir.</td></tr>';
    } else {
      for (let pair of this.matchedPairs) {
        const distClass = pair.isDistPassed ? "passed" : "failed";
        const distLabel = pair.isDistPassed ? "UYGUN" : "LİMİT DIŞI";
        const timeClass = pair.isTimePassed ? "passed" : "warning";
        const hVal = this.isTg20Applied && pair.avgOrthoH ? pair.avgOrthoH : pair.avgH;

        html += `
          <tr>
            <td><strong>${pair.pointName}</strong></td>
            <td>${pair.p1.dt || "-"}</td>
            <td>${pair.p1.tm || "-"}</td>
            <td>${pair.p2.dt || "-"}</td>
            <td>${pair.p2.tm || "-"}</td>
            <td class="${timeClass}">${pair.timeDiffStr || `${pair.timeDiffMin} dk`}</td>
            <td>${pair.dy}</td>
            <td>${pair.dx}</td>
            <td>${pair.dh}</td>
            <td class="font-bold">${pair.ds2d}</td>
            <td class="${distClass}">${distLabel}</td>
            <td>${pair.avgE}</td>
            <td>${pair.avgN}</td>
            <td>${hVal}</td>
          </tr>
        `;
      }
    }

    html += `
    </tbody>
  </table>
`;

    if (this.unmatchedPoints && this.unmatchedPoints.length > 0) {
      html += `
  <h4>2. İKİNCİ OKUMASI BULUNMAYAN (TEKİL) NOKTALAR TABLOSU</h4>
  <table>
    <thead>
      <tr>
        <th>#</th>
        <th>Nokta Adı</th>
        <th>Tarih</th>
        <th>Saat</th>
        <th>Y (Sağa - m)</th>
        <th>X (Yukarı - m)</th>
        <th>${this.isTg20Applied ? "Ortometrik H (TG-20)" : "Elipsoit Kotu (h)"}</th>
        <th>hRMS (mm)</th>
        <th>PDOP</th>
        <th>Uydu</th>
        <th>Durum</th>
      </tr>
    </thead>
    <tbody>
`;

      this.unmatchedPoints.forEach((pt, idx) => {
        const hVal = this.isTg20Applied && pt.orthoH !== undefined ? pt.orthoH.toFixed(3) : pt.h.toFixed(3);
        html += `
          <tr>
            <td>${idx + 1}</td>
            <td><strong>${pt.pn}</strong></td>
            <td>${pt.dt || "-"}</td>
            <td>${pt.tm || "-"}</td>
            <td>${pt.e.toFixed(3)}</td>
            <td>${pt.n.toFixed(3)}</td>
            <td class="font-bold">${hVal}</td>
            <td>${(pt.hsdvVal * 1000).toFixed(1)}</td>
            <td>${pt.pdop}</td>
            <td>${pt.sats}</td>
            <td><span class="badge-single-warn">Tek Ölçü (2. Okuma Yok)</span></td>
          </tr>
        `;
      });

      html += `
    </tbody>
  </table>
`;
    }

    html += `
  <div class="footer">
    <div class="sign-box">Ölçümü Yapan<br>Harita Mühendisi / Teknikeri</div>
    <div class="sign-box">Kontrol Eden<br>Kontrol Mühendisi</div>
    <div class="sign-box">Onaylayan<br>Kadastro Müdürü / Yetkili</div>
  </div>
</body>
</html>
`;

    return html;
  }

  /**
   * Verilen Metin veya Dosya Adından Formatı Otomatik Algılar
   */
  autoDetectFormat(content, fileName = "") {
    const text = (content || "").trim();
    const ext = (fileName || "").split(".").pop().toLowerCase();
    const preview = text.substring(0, 500);

    if (ext === "rw5" || preview.includes("GPS,PN") || preview.includes("JB,NM") || preview.includes("--SurvCE") || preview.includes("--SurvStar")) {
      return { format: "rw5", name: "RW5 Ham Ölçü Dosyası (.rw5)", icon: "fa-satellite-dish" };
    }
    if (ext === "gsi" || preview.includes("WI11") || preview.includes("*11") || /^\*?11\d{4}\+/m.test(preview)) {
      return { format: "gsi", name: "Leica GSI Formatı", icon: "fa-crosshairs" };
    }
    if (ext === "xml" || preview.includes("<LandXML") || preview.includes("<CgPoints>")) {
      return { format: "landxml", name: "LandXML Formatı", icon: "fa-file-code" };
    }
    if (ext === "jxl" || preview.includes("<JOBFile") || preview.includes("<FieldBook")) {
      return { format: "trimble", name: "Trimble Access JXL", icon: "fa-location-arrow" };
    }
    if (ext === "kml" || preview.includes("<kml") || preview.includes("<Placemark>")) {
      return { format: "kml", name: "Google Earth KML", icon: "fa-earth-americas" };
    }
    if (ext === "kmz") {
      return { format: "kmz", name: "Google Earth KMZ", icon: "fa-earth-americas" };
    }
    if (ext === "geojson" || (preview.includes('"type"') && preview.includes("FeatureCollection"))) {
      return { format: "geojson", name: "GeoJSON Standart Formatı", icon: "fa-code" };
    }
    if (ext === "dxf" || preview.includes("ENTITIES") || preview.includes("HEADER") || preview.includes("SECTION")) {
      return { format: "dxf", name: "AutoCAD / Netcad DXF", icon: "fa-vector-square" };
    }
    if (ext === "ncn" || /^[A-Za-z0-9_-]+\s+\d{5,7}\.\d+\s+\d{6,8}\.\d+/m.test(preview)) {
      return { format: "ncn", name: "Netcad NCN Formatı", icon: "fa-map-pin" };
    }
    if (ext === "csv" || preview.includes(",") || preview.includes(";")) {
      return { format: "csv", name: "Standart CSV Tablo Formatı", icon: "fa-file-csv" };
    }

    return { format: "generic", name: "Metin / Sütunlu Koordinat Verisi", icon: "fa-file-lines" };
  }

  /**
   * DXF Çizim Dosyalarını GeoJSON Formatına Dönüştürür (Noktalar, Çizgiler, Poligonlar)
   */
  parseDxfToGeoJson(dxfString, overrideDom = null) {
    const lines = dxfString.split(/\r?\n/);
    const features = [];

    let inEntities = false;
    let lineIdx = 0;
    const rawEntities = [];

    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;

    while (lineIdx < lines.length) {
      const code = lines[lineIdx]?.trim();
      const val = lines[lineIdx + 1]?.trim();
      lineIdx += 2;

      if (code === "0" && val === "SECTION") {
        const nextCode = lines[lineIdx]?.trim();
        const nextVal = lines[lineIdx + 1]?.trim();
        if (nextCode === "2" && nextVal === "ENTITIES") {
          inEntities = true;
          lineIdx += 2;
        }
      } else if (code === "0" && val === "ENDSEC") {
        inEntities = false;
      }

      if (!inEntities) continue;

      if (code === "0" && val === "POINT") {
        let x = null, y = null, z = 0;
        let layer = "Default";

        while (lineIdx < lines.length && lines[lineIdx]?.trim() !== "0") {
          const c = lines[lineIdx]?.trim();
          const v = lines[lineIdx + 1]?.trim();
          if (c === "10") x = parseFloat(v);
          else if (c === "20") y = parseFloat(v);
          else if (c === "30") z = parseFloat(v);
          else if (c === "8") layer = v;
          lineIdx += 2;
        }

        if (x !== null && y !== null && !isNaN(x) && !isNaN(y)) {
          rawEntities.push({ type: "Point", coords: [x, y, z], layer: layer });
          minX = Math.min(minX, x); maxX = Math.max(maxX, x);
          minY = Math.min(minY, y); maxY = Math.max(maxY, y);
        }
      } else if (code === "0" && val === "LINE") {
        let x1 = null, y1 = null, x2 = null, y2 = null;
        let layer = "Default";

        while (lineIdx < lines.length && lines[lineIdx]?.trim() !== "0") {
          const c = lines[lineIdx]?.trim();
          const v = lines[lineIdx + 1]?.trim();
          if (c === "10") x1 = parseFloat(v);
          else if (c === "20") y1 = parseFloat(v);
          else if (c === "11") x2 = parseFloat(v);
          else if (c === "21") y2 = parseFloat(v);
          else if (c === "8") layer = v;
          lineIdx += 2;
        }

        if (x1 !== null && y1 !== null && x2 !== null && y2 !== null) {
          rawEntities.push({ type: "LineString", coords: [[x1, y1], [x2, y2]], layer: layer });
          minX = Math.min(minX, x1, x2); maxX = Math.max(maxX, x1, x2);
          minY = Math.min(minY, y1, y2); maxY = Math.max(maxY, y1, y2);
        }
      } else if (code === "0" && val === "LWPOLYLINE") {
        const polyCoords = [];
        let isClosed = false;
        let layer = "Default";
        let tempX = null;

        while (lineIdx < lines.length && lines[lineIdx]?.trim() !== "0") {
          const c = lines[lineIdx]?.trim();
          const v = lines[lineIdx + 1]?.trim();
          if (c === "70") isClosed = (parseInt(v, 10) & 1) === 1;
          else if (c === "8") layer = v;
          else if (c === "10") tempX = parseFloat(v);
          else if (c === "20" && tempX !== null) {
            const tempY = parseFloat(v);
            polyCoords.push([tempX, tempY]);
            minX = Math.min(minX, tempX); maxX = Math.max(maxX, tempX);
            minY = Math.min(minY, tempY); maxY = Math.max(maxY, tempY);
            tempX = null;
          }
          lineIdx += 2;
        }

        if (polyCoords.length >= 2) {
          if (isClosed && polyCoords.length >= 3) {
            if (polyCoords[0][0] !== polyCoords[polyCoords.length - 1][0] || polyCoords[0][1] !== polyCoords[polyCoords.length - 1][1]) {
              polyCoords.push([polyCoords[0][0], polyCoords[0][1]]);
            }
            rawEntities.push({ type: "Polygon", coords: [polyCoords], layer: layer });
          } else {
            rawEntities.push({ type: "LineString", coords: polyCoords, layer: layer });
          }
        }
      } else if (code === "0" && val === "POLYLINE") {
        const polyCoords = [];
        let layer = "Default";
        let isClosed = false;

        while (lineIdx < lines.length && lines[lineIdx]?.trim() !== "0") {
          const c = lines[lineIdx]?.trim();
          const v = lines[lineIdx + 1]?.trim();
          if (c === "70") isClosed = (parseInt(v, 10) & 1) === 1;
          else if (c === "8") layer = v;
          lineIdx += 2;
        }

        while (lineIdx < lines.length) {
          const c = lines[lineIdx]?.trim();
          const v = lines[lineIdx + 1]?.trim();
          if (c === "0" && v === "SEQEND") {
            lineIdx += 2;
            break;
          }
          if (c === "0" && v === "VERTEX") {
            lineIdx += 2;
            let vx = null, vy = null;
            while (lineIdx < lines.length && lines[lineIdx]?.trim() !== "0") {
              const vc = lines[lineIdx]?.trim();
              const vv = lines[lineIdx + 1]?.trim();
              if (vc === "10") vx = parseFloat(vv);
              else if (vc === "20") vy = parseFloat(vv);
              lineIdx += 2;
            }
            if (vx !== null && vy !== null) {
              polyCoords.push([vx, vy]);
              minX = Math.min(minX, vx); maxX = Math.max(maxX, vx);
              minY = Math.min(minY, vy); maxY = Math.max(maxY, vy);
            }
          } else {
            lineIdx += 2;
          }
        }

        if (polyCoords.length >= 2) {
          if (isClosed && polyCoords.length >= 3) {
            polyCoords.push([polyCoords[0][0], polyCoords[0][1]]);
            rawEntities.push({ type: "Polygon", coords: [polyCoords], layer: layer });
          } else {
            rawEntities.push({ type: "LineString", coords: polyCoords, layer: layer });
          }
        }
      }
    }

    if (rawEntities.length === 0) {
      return { type: "FeatureCollection", features: [] };
    }

    const midX = (minX + maxX) / 2.0;
    const midY = (minY + maxY) / 2.0;

    let isProjected = false;
    let isSwapped = false;
    let detectedDom = overrideDom || 30;

    if (midX > 100000 || midY > 100000) {
      isProjected = true;
      if (midX > 1000000 && midY < 1000000) {
        isSwapped = true;
      }
      if (!overrideDom && this.geodesy) {
        const estCoord = isSwapped ? midY : midX;
        detectedDom = this.geodesy.getAutoCentralMeridian3Deg(estCoord > 1000000 ? estCoord / 100000.0 : 33);
        if (detectedDom < 27 || detectedDom > 45) detectedDom = 30;
      }
    }

    const transformCoord = (coord) => {
      let raw1 = coord[0];
      let raw2 = coord[1];

      if (!isProjected) {
        if (raw1 > 24 && raw1 < 45 && raw2 > 35 && raw2 < 43) return [raw1, raw2];
        else if (raw2 > 24 && raw2 < 45 && raw1 > 35 && raw1 < 43) return [raw2, raw1];
        return [raw1, raw2];
      }

      let easting = isSwapped ? raw2 : raw1;
      let northing = isSwapped ? raw1 : raw2;
      if (easting > 1000000) easting = easting % 1000000;

      if (this.geodesy) {
        const geo = this.geodesy.tmToGeographic(easting, northing, detectedDom, "ITRF96");
        return [geo.lon, geo.lat];
      }
      return [easting, northing];
    };

    for (let ent of rawEntities) {
      if (ent.type === "Point") {
        features.push({
          type: "Feature",
          properties: { layer: ent.layer, name: `DXF Nokta (${ent.layer})` },
          geometry: { type: "Point", coordinates: transformCoord(ent.coords) }
        });
      } else if (ent.type === "LineString") {
        features.push({
          type: "Feature",
          properties: { layer: ent.layer, name: `DXF Çizgi (${ent.layer})` },
          geometry: { type: "LineString", coordinates: ent.coords.map(transformCoord) }
        });
      } else if (ent.type === "Polygon") {
        features.push({
          type: "Feature",
          properties: { layer: ent.layer, name: `DXF Poligon (${ent.layer})` },
          geometry: { type: "Polygon", coordinates: ent.coords.map(ring => ring.map(transformCoord)) }
        });
      }
    }

    return {
      type: "FeatureCollection",
      features: features,
      metadata: {
        isProjected: isProjected,
        detectedDom: detectedDom,
        featureCount: features.length
      }
    };
  }
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = GnssFormatEngine;
}