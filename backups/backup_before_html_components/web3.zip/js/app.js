function showToast(arg1, arg2 = "info", arg3 = 3800) {
  let domEl = document.getElementById("toastContainer");
  if (!domEl) {
    domEl = document.createElement("div");
    domEl.id = "toastContainer";
    domEl.className = "toast-container";
    document.body.appendChild(domEl);
  }
  const divEl = document.createElement("div");
  divEl.className = "toast toast-" + arg2;
  let str = "fa-solid fa-circle-info";
  if (arg2 === "success") {
    str = "fa-solid fa-circle-check";
  } else if (arg2 === "warning") {
    str = "fa-solid fa-triangle-exclamation";
  } else if (arg2 === "error") {
    str = "fa-solid fa-circle-xmark";
  }
  divEl.innerHTML = "\n        <div class=\"toast-icon-wrap\">\n            <i class=\"" + str + " toast-icon\"></i>\n        </div>\n        <div class=\"toast-message\">" + arg1 + "</div>\n        <button class=\"toast-close\" title=\"Kapat\" type=\"button\">\n            <i class=\"fa-solid fa-xmark\"></i>\n        </button>\n        <div class=\"toast-progress\" style=\"animation-duration: " + arg3 + "ms;\"></div>\n    ";
  const domEl_1 = divEl.querySelector(".toast-close");
  let v_4 = null;
  const v_5 = () => {
    if (divEl.classList.contains("toast-hiding")) {
      return;
    }
    divEl.classList.add("toast-hiding");
    if (v_4) {
      clearTimeout(v_4);
    }
    setTimeout(() => {
      if (divEl.parentNode) {
        divEl.parentNode.removeChild(divEl);
      }
    }, 320);
  };
  if (domEl_1) {
    domEl_1.addEventListener("click", v_5);
  }
  domEl.appendChild(divEl);
  v_4 = setTimeout(v_5, arg3);
}
function downloadTextFile(arg1, arg2, arg3 = "text/plain;charset=utf-8") {
  const v_4 = arg2 instanceof Blob ? arg2 : new Blob([arg2], {
    type: arg3
  });
  const v_5 = URL.createObjectURL(v_4);
  const aEl = document.createElement("a");
  aEl.href = v_5;
  aEl.download = arg1;
  document.body.appendChild(aEl);
  aEl.click();
  setTimeout(() => {
    if (aEl.parentNode) {
      document.body.removeChild(aEl);
    }
    URL.revokeObjectURL(v_5);
  }, 200);
}
function initKeyboardShortcuts() {
  document.addEventListener("keydown", event => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
      event.preventDefault();
      const domEl = document.querySelector(".tool-tab.active");
      let v_1 = null;
      if (domEl) {
        v_1 = domEl.querySelector("input[type=\"text\"][placeholder*=\"ara\" i], input[type=\"search\"]");
      }
      if (!v_1) {
        v_1 = document.getElementById("inputSearchRtk") || document.getElementById("inputSearchGcp") || document.getElementById("txtPaftaSearchInput");
      }
      if (v_1) {
        v_1.focus();
        v_1.select();
        showToast("🔍 Arama kutusuna odaklanıldı (Esc: Temizle)", "info");
      }
    }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "o") {
      event.preventDefault();
      const domEl = document.querySelector(".tool-tab.active");
      const v_1 = domEl ? domEl.querySelector("input[type=\"file\"]") : document.getElementById("rw5FileInput");
      if (v_1) {
        v_1.click();
      }
    }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "p") {
      event.preventDefault();
      const domEl = document.querySelector(".tool-tab.active");
      const v_1 = domEl ? domEl.querySelector("[id*=\"Print\" i]") : document.getElementById("btnPrintTg20RwReportRtk");
      if (v_1 && !v_1.disabled) {
        v_1.click();
      } else {
        window.print();
      }
    }
    if (event.key === "Escape") {
      const v_1 = document.activeElement;
      if (v_1 && v_1.tagName === "INPUT") {
        v_1.value = "";
        v_1.dispatchEvent(new Event("input"));
        v_1.blur();
        showToast("Arama temizlendi.", "info");
      }
    }
  });
}
function initGlobalDragAndDrop() {
  const domEl = document.getElementById("globalDragOverlay");
  if (!domEl) {
    return;
  }
  let num = 0;
  window.addEventListener("dragenter", event => {
    event.preventDefault();
    num++;
    if (event.dataTransfer && event.dataTransfer.types && event.dataTransfer.types.includes("Files")) {
      domEl.classList.add("active");
    }
  });
  window.addEventListener("dragleave", event => {
    event.preventDefault();
    num--;
    if (num <= 0) {
      num = 0;
      domEl.classList.remove("active");
    }
  });
  window.addEventListener("dragover", event => {
    event.preventDefault();
  });
  window.addEventListener("drop", async event => {
    event.preventDefault();
    num = 0;
    domEl.classList.remove("active");
    const v_1 = event.dataTransfer?.files;
    if (!v_1 || v_1.length === 0) {
      return;
    }
    const v_2 = v_1[0];
    const v_3 = v_2.name.toLowerCase();
    if (v_3.endsWith(".rw5") || v_3.endsWith(".raw") || v_3.endsWith(".jxl") || v_3.endsWith(".csv") && !v_3.includes("rinex")) {
      const domEl_1 = document.querySelector("[data-tab=\"tab-cadastre\"]");
      domEl_1?.click();
      const v_1_1 = new DataTransfer();
      v_1_1.items.add(v_2);
      elements.rw5FileInput.files = v_1_1.files;
      showToast("📂 '" + v_2.name + "' yüklendi. Hesaplama başlatılıyor...", "success");
      await handleGnssAnalysis();
    } else if (v_3.endsWith(".obs") || v_3.endsWith(".rnx") || v_3.endsWith(".zip") || /\.\d{2}[oO]$/.test(v_3)) {
      const domEl_1 = document.querySelector("[data-tab=\"tab-rinex-studio\"]");
      domEl_1?.click();
      const v_1_1 = new DataTransfer();
      Array.from(v_1).forEach(item => v_1_1.items.add(item));
      elements.mergerFileInput.files = v_1_1.files;
      elements.mergerFileInput.dispatchEvent(new Event("change"));
      showToast("🛰️ " + v_1.length + " adet RINEX dosyası aktarıldı.", "success");
    } else if (v_3.endsWith(".ggf")) {
      const domEl_1 = document.querySelector("[data-tab=\"tab-tg20\"]");
      domEl_1?.click();
      await state.tg20Engine.loadFromFile(v_2);
      showToast("🇹🇷 '" + v_2.name + "' TG-20 Jeoidi yüklendi!", "success");
    } else {
      showToast("📂 '" + v_2.name + "' dosyası yüklendi.", "info");
    }
  });
}
function initThemeToggle() {
  const btnEl = document.getElementById("btnThemeToggle");
  const domEl = document.getElementById("themeIcon");
  const v_1 = localStorage.getItem("gnss_studio_theme") || "dark";
  v_2(v_1);
  if (btnEl) {
    btnEl.addEventListener("click", () => {
      const v_1_1 = document.documentElement.getAttribute("data-theme") || "dark";
      const v_2_1 = v_1_1 === "dark" ? "light" : "dark";
      v_2(v_2_1);
      localStorage.setItem("gnss_studio_theme", v_2_1);
      showToast(v_2_1 === "light" ? "☀️ Aydınlık tema aktif edildi." : "🌙 Koyu tema aktif edildi.", "info");
    });
  }

  const btnSidebarTheme = document.getElementById("btnSidebarThemeShortcut");
  if (btnSidebarTheme) {
    btnSidebarTheme.addEventListener("click", () => {
      btnEl?.click();
    });
  }

  // Global Keyboard Shortcuts: Ctrl+O (Dosya Aç) & Ctrl+D (Tema Değiştir)
  window.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "o") {
      e.preventDefault();
      document.getElementById("inputHomeHeroFile")?.click();
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "d") {
      e.preventDefault();
      btnEl?.click();
    }
  });

  function v_2(arg1) {
    document.documentElement.setAttribute("data-theme", arg1);
    if (domEl) {
      if (arg1 === "light") {
        domEl.className = "fa-solid fa-sun";
        domEl.style.color = "var(--amber-500)";
      } else {
        domEl.className = "fa-solid fa-moon";
        domEl.style.color = "var(--cyan-400)";
      }
    }
  }
}
const state = {
  flightEngine: null,
  flightMap: null,
  flightOriginalLayer: null,
  flightSimplifiedLayer: null,
  flightRoadLayer: null,
  flightGcpLayer: null,
  flightTriangulationLayer: null,
  isDrawingRoad: false,
  activeRoadPoints: [],
  activeRoadPolyline: null,
  activeRoadMarkers: [],
  isFlightMapInit: false,
  mergerGroups: {},
  currentMergedFiles: {},
  posSolutions: [],
  posText: "",
  csvText: "",
  map: null,
  mapLayerGroup: null,
  cadastreMap: null,
  cadastreLayerGroup: null,
  paftaLayerGroup: null,
  domLayerGroup: null,
  isDomLayerActive: false,
  highlightedPaftaLayer: null,
  activePaftaScale: "off",
  gnssEngine: new GnssFormatEngine(),
  rinexEngine: new RinexPowerEngine(),
  paftaEngine: new PaftaIndexEngine(),
  tg20Engine: new Tg20GeoidEngine(),
  tg20Map: null,
  tg20MapMarker: null,
  lastTg20QueryPoint: null
};
const elements = {
  navItems: document.querySelectorAll(".nav-item"),
  toolTabs: document.querySelectorAll(".tool-tab"),
  subTabBtns: document.querySelectorAll(".sub-tab-btn"),
  subTabContents: document.querySelectorAll(".subtab-content"),
  pageTitle: document.getElementById("pageTitle"),
  pageSubtitle: document.getElementById("pageSubtitle"),
  globalConsoleLog: document.getElementById("globalConsoleLog"),
  progressBarFill: document.getElementById("progressBarFill"),
  progressLabel: document.getElementById("progressLabel"),
  progressPercent: document.getElementById("progressPercent"),
  btnClearLog: document.getElementById("btnClearLog"),
  btnCopyLog: document.getElementById("btnCopyLog"),
  rw5FileInput: document.getElementById("rw5FileInput"),
  rw5Radius: document.getElementById("rw5Radius"),
  rw5Tolerance: document.getElementById("rw5Tolerance"),
  rw5MinTime: document.getElementById("rw5MinTime"),
  btnAnalyzeRw5: document.getElementById("btnAnalyzeRw5"),
  brandDetectPill: document.getElementById("brandDetectPill"),
  tableGpsFormatRtkBody: document.getElementById("tableGpsFormatRtkBody"),
  tableRw5MatchedBody: document.getElementById("tableRw5MatchedBody"),
  txtCoordOutput: document.getElementById("txtCoordOutput"),
  selectCoordOrder: document.getElementById("selectCoordOrder"),
  btnCopyCoords: document.getElementById("btnCopyCoords"),
  btnDownloadCoordTxt: document.getElementById("btnDownloadCoordTxt"),
  btnFitCadastreMap: document.getElementById("btnFitCadastreMap"),
  btnPrintCadastre: document.getElementById("btnPrintCadastre"),
  btnExportCadastreCsv: document.getElementById("btnExportCadastreCsv"),
  btnExportRtkCsv: document.getElementById("btnExportRtkCsv"),
  btnExportNcn: document.getElementById("btnExportNcn"),
  btnExportKos: document.getElementById("btnExportKos"),
  btnExportDxf: document.getElementById("btnExportDxf"),
  btnExportKmlCadastre: document.getElementById("btnExportKmlCadastre"),
  btnExportTg20RwReport: document.getElementById("btnExportTg20RwReport"),
  barCriterion: document.getElementById("barCriterion"),
  barProj: document.getElementById("barProj"),
  barGeoid: document.getElementById("barGeoid"),
  mergerDropzone: document.getElementById("mergerDropzone"),
  mergerFileInput: document.getElementById("mergerFileInput"),
  mergerResultCard: document.getElementById("mergerResultCard"),
  tableGroupsBody: document.getElementById("tableGroupsBody"),
  btnMergeAll: document.getElementById("btnMergeAll"),
  chkSysGps: document.getElementById("chkSysGps"),
  chkSysGlo: document.getElementById("chkSysGlo"),
  chkSysGal: document.getElementById("chkSysGal"),
  chkSysBds: document.getElementById("chkSysBds"),
  inputExcludeSats: document.getElementById("inputExcludeSats"),
  selectTargetFormat: document.getElementById("selectTargetFormat"),
  selectDecimationStep: document.getElementById("selectDecimationStep"),
  btnExportKml: document.getElementById("btnExportKml"),
  btnExportGeoJson: document.getElementById("btnExportGeoJson"),
  geoLat: document.getElementById("geoLat"),
  geoLon: document.getElementById("geoLon"),
  geoH: document.getElementById("geoH"),
  btnConvertCoord: document.getElementById("btnConvertCoord"),
  coordResultBox: document.getElementById("coordResultBox")
};
document.addEventListener("DOMContentLoaded", () => {
  initThemeToggle();
  initKeyboardShortcuts();
  initGlobalDragAndDrop();
  initNavigation();
  initAboutModal();
  initGpsFormatSubtabs();
  initCadastreModule();
  initMergerDropzone();
  initGeodesy();
  initTg20GeoidStation();
  initPpkInspector();
  initRinexQualityInspector();
  initConsoleControls();
  initVersionAndFormatCascader();
  initFlightPlannerStudio();
  initGuideSearchAndFilter();
});
function initAboutModal() {
  const modal = document.getElementById("modalAbout");
  if (!modal) return;
  
  const openModal = () => {
    modal.style.display = "flex";
  };
  const closeModal = () => {
    modal.style.display = "none";
  };

  document.getElementById("btnOpenAboutModal")?.addEventListener("click", openModal);
  document.getElementById("btnSidebarAbout")?.addEventListener("click", openModal);
  document.getElementById("btnCloseAboutModal")?.addEventListener("click", closeModal);
  document.getElementById("btnConfirmAboutModal")?.addEventListener("click", closeModal);

  modal.addEventListener("click", (e) => {
    if (e.target === modal) closeModal();
  });

  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && modal.style.display === "flex") {
      closeModal();
    }
  });
}

function initGuideSearchAndFilter() {
  const inputSearch = document.getElementById("inputGuideSearch");
  const btnClearSearch = document.getElementById("btnClearGuideSearch");
  const filterChips = document.querySelectorAll(".guide-filter-chip");
  const moduleCards = document.querySelectorAll("#guideModulesGrid .guide-card-box");
  const standardsBento = document.querySelectorAll(".guide-standards-bento");
  const faqItems = document.querySelectorAll(".guide-faq-item");
  const sectionHeadings = document.querySelectorAll(".guide-section-heading");

  // Global Tab Switcher helper
  window.launchGuideTab = (tabId) => {
    const navItem = document.querySelector(`.nav-item[data-tab="${tabId}"]`);
    if (navItem) {
      navItem.click();
    }
  };

  // Filter Chips Logic
  filterChips.forEach(chip => {
    chip.addEventListener("click", () => {
      filterChips.forEach(c => c.classList.remove("active"));
      chip.classList.add("active");

      const filterVal = chip.getAttribute("data-guide-filter");
      applyGuideFilter(filterVal, inputSearch ? inputSearch.value.trim() : "");
    });
  });

  // Search Input Logic
  if (inputSearch) {
    inputSearch.addEventListener("input", () => {
      const q = inputSearch.value.trim();
      if (btnClearSearch) {
        if (q.length > 0) {
          btnClearSearch.classList.remove("d-none");
        } else {
          btnClearSearch.classList.add("d-none");
        }
      }
      const activeChip = document.querySelector(".guide-filter-chip.active");
      const activeFilter = activeChip ? activeChip.getAttribute("data-guide-filter") : "all";
      applyGuideFilter(activeFilter, q);
    });

    if (btnClearSearch) {
      btnClearSearch.addEventListener("click", () => {
        inputSearch.value = "";
        btnClearSearch.classList.add("d-none");
        const activeChip = document.querySelector(".guide-filter-chip.active");
        const activeFilter = activeChip ? activeChip.getAttribute("data-guide-filter") : "all";
        applyGuideFilter(activeFilter, "");
      });
    }
  }

  // Filter and Search Evaluation
  function applyGuideFilter(filterCategory, searchQuery) {
    const queryLower = searchQuery.toLowerCase();

    // 1. Module Cards
    moduleCards.forEach(card => {
      const cat = card.getAttribute("data-guide-category") || "";
      const text = card.textContent.toLowerCase();
      const matchCat = filterCategory === "all" || filterCategory === cat;
      const matchQuery = !queryLower || text.includes(queryLower);

      if (matchCat && matchQuery) {
        card.style.display = "flex";
      } else {
        card.style.display = "none";
      }
    });

    // 2. Standards & Formulas
    standardsBento.forEach(bento => {
      const cat = bento.getAttribute("data-guide-category") || "standards";
      const text = bento.textContent.toLowerCase();
      const matchCat = filterCategory === "all" || filterCategory === "standards";
      const matchQuery = !queryLower || text.includes(queryLower);

      if (matchCat && matchQuery) {
        bento.style.display = "grid";
      } else {
        bento.style.display = "none";
      }
    });

    // 3. FAQ Accordion Items
    faqItems.forEach(item => {
      const text = item.textContent.toLowerCase();
      const matchCat = filterCategory === "all" || filterCategory === "faq";
      const matchQuery = !queryLower || text.includes(queryLower);

      if (matchCat && matchQuery) {
        item.style.display = "block";
      } else {
        item.style.display = "none";
      }
    });

    // 4. Section Headings
    sectionHeadings.forEach(heading => {
      const cat = heading.getAttribute("data-guide-category") || "";
      if (filterCategory === "all") {
        heading.style.display = "flex";
      } else if (cat && cat === filterCategory) {
        heading.style.display = "flex";
      } else if (!cat && (filterCategory === "cadastre" || filterCategory === "rinex" || filterCategory === "map" || filterCategory === "geodesy" || filterCategory === "flight" || filterCategory === "tg20")) {
        heading.style.display = "flex";
      } else {
        heading.style.display = "none";
      }
    });
  }

  // FAQ Accordion Click Handler
  faqItems.forEach(item => {
    const questionBtn = item.querySelector(".guide-faq-question");
    if (questionBtn) {
      questionBtn.addEventListener("click", () => {
        const isActive = item.classList.contains("active");
        faqItems.forEach(other => other.classList.remove("active"));
        if (!isActive) {
          item.classList.add("active");
        }
      });
    }
  });
}
function initVersionAndFormatCascader() {
  const domEl = document.getElementById("selectTargetVersion");
  if (domEl) {
    domEl.addEventListener("change", () => {
      const v_1 = state.detectedTimeWindow?.date ? parseInt(state.detectedTimeWindow.date.split("-")[0]) : 2026;
      populateDynamicFormats(domEl.value, v_1);
    });
    populateDynamicFormats(domEl.value, 2026);
  }
}
function populateDynamicFormats(arg1, arg2 = 2026) {
  const domEl = document.getElementById("selectTargetFormat");
  if (!domEl) {
    return;
  }
  const v_3 = String(arg2 % 100).padStart(2, "0");
  domEl.innerHTML = "";
  if (arg1 === "RINEX_211" || arg1 === "RINEX_210") {
    const v_1 = arg1 === "RINEX_210" ? "2.10" : "2.11";
    domEl.innerHTML = "\n            <option value=\"OBS_YYO\" selected>Standart Yıl Uzantılı Gözlem (." + v_3 + "o - RINEX " + v_1 + ")</option>\n            <option value=\"OBS_EXT\">Doğrudan .OBS Uzantılı Gözlem (.obs - RINEX " + v_1 + ")</option>\n            <option value=\"NAV_YYN\">GPS Navigasyon / Seyir (." + v_3 + "n)</option>\n            <option value=\"NAV_EXT\">Doğrudan .NAV Uzantılı GPS Seyir (.nav)</option>\n            <option value=\"NAV_YYG\">GLONASS Navigasyon / Seyir (." + v_3 + "g)</option>\n            <option value=\"HATANAKA_YYD\">Hatanaka Sıkıştırılmış Gözlem (." + v_3 + "d)</option>\n            <option value=\"ALL_ZIP\">Gözlem + Navigasyon Tam Paket (.ZIP)</option>\n        ";
  } else if (arg1.startsWith("RINEX_3") || arg1 === "RINEX_400") {
    const v_1 = arg1.replace("RINEX_", "").replace("30", "3.0").replace("400", "4.00");
    domEl.innerHTML = "\n            <option value=\"OBS_YYO\" selected>Standart 8.3 Gözlem Dosyası (." + v_3 + "o - RINEX " + v_1 + ")</option>\n            <option value=\"OBS_EXT\">Doğrudan .OBS Uzantılı Gözlem (.obs - RINEX " + v_1 + ")</option>\n            <option value=\"RNX_OBS\">Modern IGS Uzun İsimli Gözlem (.rnx - RINEX " + v_1 + ")</option>\n            <option value=\"NAV_YYN\">GPS Navigasyon / Seyir (." + v_3 + "n)</option>\n            <option value=\"NAV_EXT\">Doğrudan .NAV Uzantılı GPS Seyir (.nav)</option>\n            <option value=\"NAV_YYG\">GLONASS Navigasyon / Seyir (." + v_3 + "g)</option>\n            <option value=\"RNX_NAV_MIX\">Multi-GNSS Karma Seyir (." + v_3 + "p / _MN.rnx)</option>\n            <option value=\"HATANAKA_YYD\">Hatanaka Sıkıştırılmış Gözlem (." + v_3 + "d)</option>\n            <option value=\"HATANAKA_CRX\">Hatanaka Sıkıştırılmış Multi-GNSS (.crx)</option>\n            <option value=\"ALL_ZIP\">Tüm Multi-GNSS Dosyaları Paketi (.ZIP)</option>\n        ";
  }
}
function initNavigation() {
  const obj = {
    "tab-home": {
      title: "Harita Tools",
      sub: "Harita, Kadastro & Jeodezi Mühendislik Araçları"
    },
    "tab-cadastre": {
      title: "RTK & Ham Data",
      sub: "Tüm GNSS alıcılarının ham ölçü dosyaları (.rw5, .raw, .csv, .txt, .jxl), ITRF-96 TM 3° hesaplaması, HGM TG-20 jeoidi ve Netcad/AutoCAD/PDF çıktıları"
    },
    "tab-rinex-studio": {
      title: "RINEX Dosya Düzenleme & Birleştirme",
      sub: "İstasyon gözlem dosyalarını birleştirme, zaman aralığı kesme, uydu filtreleme ve RINEX 2.11 / 3.x dönüştürme"
    },
    "tab-map": {
      title: "Pafta İndeksi & Harita Görünümü",
      sub: "Türkiye 1/100.000, 1/50.000, 1/25.000 standart paftaları, 3° dilim sınırları ve nokta çizimi"
    },
    "tab-geodesy": {
      title: "Koordinat Dönüşümü & Helmert Hesabı",
      sub: "ITRF-96 TM 3°, ED-50, Coğrafi koordinat dönüşümleri, 2B Helmert (.DNS) ve 3B datum parametreleri"
    },
    "tab-tg20": {
      title: "HGM TG-20 Jeoit Kot İndirgeme",
      sub: "Harita Genel Müdürlüğü TG-20 modeli ile Elipsoit Kotu (h) ➔ TUDKA-99 Ortometrik Nivelman Kotu (H = h - N) hesabı"
    },
    "tab-flight": {
      title: "İHA Uçuş & YKN Planlama",
      sub: "Akıllı uçuş alanı optimizasyonu, güneş/gölge analizi, canlı meteoroloji ve yol ağına duyarlı YKN üretimi"
    },
    "tab-guide": {
      title: "Kullanım & Mühendislik Kılavuzu",
      sub: "Modül iş akışları, BÖHHBÜY kriterleri ve Türkiye jeodezik standartlar özeti"
    }
  };
  const v_1 = arg1 => {
    elements.navItems.forEach(item => {
      if (item.getAttribute("data-tab") === arg1) {
        item.classList.add("active");
      } else {
        item.classList.remove("active");
      }
    });
    elements.toolTabs.forEach(item => item.classList.remove("active"));
    const domEl = document.getElementById(arg1);
    if (domEl) {
      domEl.classList.add("active");
      if (obj[arg1]) {
        elements.pageTitle.textContent = obj[arg1].title;
        elements.pageSubtitle.textContent = obj[arg1].sub;
      }
      if (arg1 === "tab-map") {
        setTimeout(initMap, 200);
      }
      if (arg1 === "tab-flight") {
        setTimeout(initFlightPlannerStudio, 200);
      }
      if (arg1 === "tab-tg20") {
        setTimeout(initTg20InteractiveMap, 200);
      }
    }
  };
  elements.navItems.forEach(item => {
    item.addEventListener("click", () => {
      const v_1_1 = item.getAttribute("data-tab");
      v_1(v_1_1);
    });
  });
  document.querySelectorAll(".bento-card[data-launch-tab]").forEach(item => {
    item.addEventListener("click", () => {
      const v_1_1 = item.getAttribute("data-launch-tab");
      if (v_1_1) {
        v_1(v_1_1);
        logMessage("🚀 [MODÜL BAŞLATILDI] " + (obj[v_1_1]?.title || v_1_1) + " modülüne geçildi.");
      }
    });
  });
  document.querySelector(".brand")?.addEventListener("click", () => {
    v_1("tab-home");
  });
  const inputEl = document.getElementById("inputHomeHeroFile");
  if (inputEl) {
    inputEl.addEventListener("change", async event => {
      const v_1_1 = event.target.files?.[0];
      if (!v_1_1) {
        return;
      }
      const v_2 = v_1_1.name.split(".").pop().toLowerCase();
      const v_3 = await v_1_1.slice(0, 1500).text();
      if (["rw5", "raw", "csv", "jxl", "dat"].includes(v_2) || v_3.includes("GPS,PN") || v_3.includes("EP,PN")) {
        v_1("tab-cadastre");
        const v_1_2 = new DataTransfer();
        v_1_2.items.add(v_1_1);
        if (elements.rw5FileInput) {
          elements.rw5FileInput.files = v_1_2.files;
          elements.rw5FileInput.dispatchEvent(new Event("change"));
        }
        showToast("🚀 '" + v_1_1.name + "' algılandı, RTK & Ham Data modülüne yönlendirildi.", "success");
      } else if (["o", "rnx", "crx", "obs", "nav", "26o", "25o", "24o"].some(item => v_2.includes(item) || v_2.endsWith("o") || v_2.endsWith("d"))) {
        v_1("tab-rinex-studio");
        showToast("🛰️ '" + v_1_1.name + "' RINEX gözlem dosyası algılandı, RINEX Düzenleyiciye aktarılıyor.", "info");
      } else if (["dns", "ncn", "txt", "xyz"].includes(v_2)) {
        v_1("tab-geodesy");
        showToast("📐 '" + v_1_1.name + "' koordinat/dönüşüm dosyası algılandı, Koordinat Dönüşümüne aktarıldı.", "info");
      } else {
        v_1("tab-cadastre");
      }
    });
  }
}
function initGpsFormatSubtabs() {
  const subBtns = document.querySelectorAll(".sub-tab-btn");
  const subContents = document.querySelectorAll(".subtab-content");

  subBtns.forEach(item => {
    item.addEventListener("click", () => {
      subBtns.forEach(b => {
        b.classList.remove("active", "btn-primary");
        b.classList.add("btn-secondary");
      });
      subContents.forEach(c => {
        c.classList.remove("active");
        c.classList.add("d-none");
        c.style.display = "none";
      });

      item.classList.add("active", "btn-primary");
      item.classList.remove("btn-secondary");

      const targetId = item.getAttribute("data-subtab");
      const targetPanel = document.getElementById(targetId);
      if (targetPanel) {
        targetPanel.classList.remove("d-none");
        targetPanel.classList.add("active");
        targetPanel.style.display = "block";

        if (targetId === "subtab-view") {
          setTimeout(() => {
            initCadastreMap();
            if (state.cadastreMap) {
              state.cadastreMap.invalidateSize();
              plotCadastrePointsOnMap();
            }
          }, 150);
        } else if (targetId === "subtab-coordinate") {
          if (elements.txtCoordOutput && state.gnssEngine) {
            elements.txtCoordOutput.value = state.gnssEngine.exportFormattedCoordinateList(elements.selectCoordOrder.value);
          }
        }
      }
    });
  });
}
function initConsoleControls() {
  const btnEl = document.getElementById("btnClearLog");
  const btnEl_1 = document.getElementById("btnCopyLog");
  const btnEl_2 = document.getElementById("btnToggleDock");
  const domEl = document.getElementById("cyberConsoleDock");
  const domEl_1 = document.getElementById("iconDockToggle");
  const domEl_2 = document.getElementById("textDockToggle");
  if (btnEl && elements.globalConsoleLog) {
    btnEl.addEventListener("click", () => {
      elements.globalConsoleLog.textContent = "[SİSTEM] Konsol temizlendi.";
    });
  }
  if (btnEl_1 && elements.globalConsoleLog) {
    btnEl_1.addEventListener("click", () => {
      navigator.clipboard.writeText(elements.globalConsoleLog.textContent);
      const v_1 = btnEl_1.innerHTML;
      btnEl_1.innerHTML = "<i class=\"fa-solid fa-check text-emerald\"></i> Kopyalandı";
      setTimeout(() => {
        btnEl_1.innerHTML = v_1;
      }, 1800);
    });
  }
  if (btnEl_2 && domEl) {
    btnEl_2.addEventListener("click", () => {
      domEl.classList.toggle("minimized");
      const v_1 = domEl.classList.contains("minimized");
      if (domEl_1) {
        domEl_1.className = v_1 ? "fa-solid fa-chevron-up" : "fa-solid fa-chevron-down";
      }
      if (domEl_2) {
        domEl_2.textContent = v_1 ? "Genişlet" : "Küçült";
      }
    });
  }
}
function logMessage(arg1) {
  const v_2 = new Date().toLocaleTimeString("tr-TR");
  elements.globalConsoleLog.textContent += "\n[" + v_2 + "] " + arg1;
  elements.globalConsoleLog.scrollTop = elements.globalConsoleLog.scrollHeight;
}
function updateProgress(arg1, arg2 = "") {
  elements.progressBarFill.style.width = arg1 + "%";
  elements.progressPercent.textContent = arg1 + "%";
  if (arg2) {
    elements.progressLabel.textContent = arg2;
  }
}
function initCadastreModule() {
  if (elements.rw5FileInput) {
    elements.rw5FileInput.addEventListener("change", async event => {
      const v_1_1 = event.target.files[0];
      const domEl_5 = document.getElementById("rw5FileDisplayName");
      const domEl_6 = document.getElementById("brandDetectPill");
      if (v_1_1) {
        const v_1_2 = await v_1_1.slice(0, 1500).text();
        const v_2_1 = state.gnssEngine.autoDetectFormat(v_1_2, v_1_1.name);
        if (domEl_5) {
          domEl_5.innerHTML = "<span class=\"text-white\">" + v_1_1.name + "</span> <span class=\"badge badge-tg20 ml-6\"><i class=\"fa-solid " + v_2_1.icon + "\"></i> " + v_2_1.name + "</span>";
        }
        if (domEl_6) {
          domEl_6.innerHTML = "<span class=\"status-dot status-dot-active\"></span> Format: <strong class=\"text-emerald\">" + v_2_1.name + "</strong>";
        }
        logMessage("🔍 [OTOMATİK FORMAT TESPİTİ] '" + v_1_1.name + "' içeriği analiz edildi -> " + v_2_1.name);
        showToast("🔍 Format Algılandı: " + v_2_1.name, "info");
      }
    });
  }
  elements.btnAnalyzeRw5?.addEventListener("click", handleGnssAnalysis);
  elements.btnPrintCadastre?.addEventListener("click", handlePrintCadastre);
  elements.btnExportCadastreCsv?.addEventListener("click", () => {
    const v_1_1 = state.gnssEngine.exportCadastreCsv();
    downloadTextFile("kadastro_cift_okuma_cetelesi.csv", v_1_1);
  });
  elements.btnExportRtkCsv?.addEventListener("click", () => {
    let str = "No,Date/Time,Point,Easting,Northing,EL.Hgt,Ep,Hz,SAT,hRms,vRms,Pdop,Method,Network,Status,Ant.Ht,Latitude_Dec,Longitude_Dec\n";
    state.gnssEngine.rawPoints.forEach((item, idx) => {
      const latStr = item.lat !== undefined ? item.lat.toFixed(8) : (item.latDec ? item.latDec.toFixed(8) : "");
      const lonStr = item.lon !== undefined ? item.lon.toFixed(8) : (item.lonDec ? item.lonDec.toFixed(8) : "");
      str += idx + "," + item.dt + " " + item.tm + "," + item.pn + "," + item.e.toFixed(3) + "," + item.n.toFixed(3) + "," + item.h.toFixed(3) + "," + item.epochs + "," + item.hz + "," + item.sats + "," + item.hsdvVal.toFixed(3) + "," + item.vsdvVal.toFixed(3) + "," + item.pdop + "," + item.method + "," + item.network + "," + item.status + "," + item.hr + "," + latStr + "," + lonStr + "\n";
    });
    downloadTextFile("gpsformat_rtk_ham_tablo.csv", str);
  });
  elements.btnExportNcn?.addEventListener("click", () => {
    const v_1_1 = state.gnssEngine.exportNcnText();
    downloadTextFile("kadastro_noktalar.ncn", v_1_1);
  });
  elements.btnExportKos?.addEventListener("click", () => {
    const v_1_1 = state.gnssEngine.exportKosText();
    downloadTextFile("kadastro_olculer.kos", v_1_1);
  });
  elements.btnExportDxf?.addEventListener("click", () => {
    const v_1_1 = state.gnssEngine.exportDxfText();
    downloadTextFile("kadastro_cizim.dxf", v_1_1);
  });
  elements.btnExportKmlCadastre?.addEventListener("click", () => {
    const v_1_1 = state.gnssEngine.exportKmlText();
    downloadTextFile("kadastro_noktalar_3d.kml", v_1_1);
  });
  elements.selectCoordOrder.addEventListener("change", () => {
    elements.txtCoordOutput.value = state.gnssEngine.exportFormattedCoordinateList(elements.selectCoordOrder.value);
  });
  elements.btnCopyCoords.addEventListener("click", () => {
    elements.txtCoordOutput.select();
    navigator.clipboard.writeText(elements.txtCoordOutput.value);
    showToast("📋 Koordinat listesi panoya kopyalandı.", "success");
  });
  elements.btnDownloadCoordTxt.addEventListener("click", () => {
    downloadTextFile("koordinatlar.txt", elements.txtCoordOutput.value);
    showToast("💾 koordinatlar.txt başarıyla indirildi.", "success");
  });
  const domEl = document.getElementById("chkRw5ApplyTg20");
  const domEl_1 = document.getElementById("badgeRw5Tg20Applied");
  const domEl_2 = document.getElementById("thRw5MatchedKot");
  const domEl_3 = document.getElementById("thRw5UnmatchedKot");
  const domEl_4 = document.getElementById("thRtkKot");
  domEl?.addEventListener("change", () => {
    const v_1_1 = domEl.checked;
    state.gnssEngine.applyTg20Reduction(state.tg20Engine, state.geodesyEngine, null, v_1_1);
    if (domEl_1) {
      domEl_1.style.display = v_1_1 ? "block" : "none";
    }
    if (elements.btnExportTg20RwReport) {
      elements.btnExportTg20RwReport.style.display = v_1_1 ? "inline-flex" : "none";
    }
    if (domEl_2) {
      domEl_2.innerHTML = v_1_1 ? "H (Ortometrik Kot) <span class=\"badge badge-tg20\">TG-20</span>" : "H (Kot) Ortalama";
    }
    if (domEl_4) {
      domEl_4.innerHTML = v_1_1 ? "H (Ortometrik Kot) <span class=\"badge badge-tg20\">TG-20</span>" : "EL.Hgt. (h)";
    }
    if (state.gnssEngine.rawPoints && state.gnssEngine.rawPoints.length > 0) {
      renderGpsFormatRtkTable(state.gnssEngine.rawPoints);
      renderRw5MatchedTable(state.gnssEngine.matchedPairs, state.gnssEngine.unmatchedPoints);
      elements.txtCoordOutput.value = state.gnssEngine.exportFormattedCoordinateList(elements.selectCoordOrder.value);
      logMessage("🇹🇷 [TG-20 İNDİRGEME] " + (v_1_1 ? "Aktif: Tüm çift okuma ve tekil kotlar HGM TG-20 ile H = h - N seviyesine indirgendi." : "Devre Dışı: Elipsoit kotlarına geri dönüldü."));
      showToast(v_1_1 ? "🇹🇷 TG-20 Jeoit İndirgemesi uygulandı (H = h - N)." : "Elipsoit Kotlarına geri dönüldü.", "info");
    }
  });
  const v_1 = () => {
    if (!state.gnssEngine.isTg20Applied) {
      const domEl_5 = document.getElementById("chkRw5ApplyTg20");
      if (domEl_5) {
        domEl_5.checked = true;
        domEl_5.dispatchEvent(new Event("change"));
      }
    }
    if (state.gnssEngine.rawPoints?.length === 0) {
      showToast("⚠️ Önce bir RW5 / GNSS veri dosyası yükleyip analiz edin.", "warning");
      return;
    }
    const v_1_1 = state.gnssEngine.exportTg20ReductionReport();
    downloadTextFile("GPSFormat_TG20_Indirgeme_Raporu.txt", v_1_1);
    logMessage("📄 [TG-20 RAPOR] GPSFormat_TG20_Indirgeme_Raporu.txt başarıyla indirildi.");
    showToast("📄 TG-20 İndirgeme Raporu (.TXT) başarıyla indirildi.", "success");
  };
  const v_2 = () => {
    if (!state.gnssEngine.isTg20Applied) {
      const domEl_5 = document.getElementById("chkRw5ApplyTg20");
      if (domEl_5) {
        domEl_5.checked = true;
        domEl_5.dispatchEvent(new Event("change"));
      }
    }
    if (state.gnssEngine.rawPoints?.length === 0) {
      showToast("⚠️ Önce bir RW5 / GNSS veri dosyası yükleyip analiz edin.", "warning");
      return;
    }
    const v_1_1 = state.gnssEngine.generatePrintableTg20Report("GNSS RTK / CORS TG-20 JEOİT İNDİRGEME RAPORU", state.tg20Engine, state.geodesyEngine);
    const v_2_1 = window.open("", "_blank", "width=950,height=750");
    if (v_2_1) {
      v_2_1.document.write(v_1_1);
      v_2_1.document.close();
      logMessage("🖨️ [TG-20 RAPOR] Yazdırılabilir kadastro raporu pencerede açıldı.");
      showToast("🖨️ TG-20 Kadastro Raporu yazdırma penceresi açıldı.", "success");
    } else {
      showToast("Açılır pencere engellendi. Lütfen tarayıcı izinlerini kontrol edin.", "warning");
    }
  };
  document.getElementById("btnPrintTg20RwReportTop")?.addEventListener("click", v_2);
  document.getElementById("btnExportTg20RwReportTop")?.addEventListener("click", v_1);
  document.getElementById("btnPrintTg20RwReport")?.addEventListener("click", v_2);
  document.getElementById("btnExportTg20RwReport")?.addEventListener("click", v_1);
  document.getElementById("btnPrintTg20RwReportRtk")?.addEventListener("click", v_2);
  document.getElementById("btnExportNcnRtk")?.addEventListener("click", () => {
    const v_1_1 = state.gnssEngine.exportNcnText();
    downloadTextFile("kadastro_noktalar.ncn", v_1_1);
  });
  document.getElementById("btnExportDxfRtk")?.addEventListener("click", () => {
    const v_1_1 = state.gnssEngine.exportDxfText();
    downloadTextFile("kadastro_cizim.dxf", v_1_1);
  });
  document.getElementById("btnExportKmlRtk")?.addEventListener("click", () => {
    const v_1_1 = state.gnssEngine.exportKmlText();
    downloadTextFile("kadastro_noktalar_3d.kml", v_1_1);
  });
}
async function handleGnssAnalysis() {
  let str = "";
  let str_1 = "";
  const v_1 = elements.rw5FileInput.files[0];
  if (v_1) {
    str_1 = v_1.name;
    logMessage("📂 GNSS Veri Dosyası Okunuyor: " + v_1.name + "...");
    updateProgress(20, "Dosya Okunuyor...");
    str = await v_1.text();
  } else {
    str_1 = "musksenylYKN20260313.rw5";
    logMessage("📂 Yerel musksenylYKN20260313.rw5 dosyası yükleniyor...");
    updateProgress(20, "Varsayılan Dosya Yükleniyor...");
    try {
      const v_1_1 = await fetch("musksenylYKN20260313.rw5");
      if (v_1_1.ok) {
        str = await v_1_1.text();
      } else {
        showToast("Lütfen analiz edilecek bir GNSS veri dosyası seçin (.rw5, .raw, .csv, .txt, .jxl).", "warning");
        return;
      }
    } catch (v_1_1) {
      showToast("Lütfen işlenecek bir GNSS veri dosyası seçin.", "warning");
      return;
    }
  }
  const v_2 = parseFloat(elements.rw5Tolerance.value) || 7;
  const v_3 = parseFloat(elements.rw5MinTime.value) || 60;
  const v_4 = parseFloat(elements.rw5Radius.value) || 1;
  logMessage("🔍 Format taranıyor | Aynı Nokta Eşiği: " + v_4 + " m | Tolerans: " + v_2 + " cm | Min. Zaman: " + v_3 + " dk...");
  updateProgress(50, "Ayrıştırma ve Projeksiyon Hesaplanıyor...");
  const v_5 = state.gnssEngine.parseData(str, str_1);
  elements.brandDetectPill.textContent = "Format: " + state.gnssEngine.detectedBrand;
  const {
    matched: v_6,
    unmatched: v_7
  } = state.gnssEngine.analyzeDoubleReadings(v_2, v_3, v_4);
  const domEl = document.getElementById("chkRw5ApplyTg20");
  const v_8 = domEl ? domEl.checked : false;
  if (v_8) {
    state.gnssEngine.applyTg20Reduction(state.tg20Engine, state.geodesyEngine, null, true);
  }
  elements.barCriterion.textContent = (v_2 / 100).toFixed(2) + "m [FIX]";
  elements.barProj.textContent = "ITRF-TM 3° " + state.gnssEngine.centralMeridian + "° E";
  if (v_5.length > 0 && state.tg20Engine?.isLoaded && v_5[0].latDec && v_5[0].lonDec) {
    const v_1_1 = state.tg20Engine.getGeoidHeight(v_5[0].latDec, v_5[0].lonDec);
    elements.barGeoid.textContent = v_1_1 !== null ? "TG-20 Jeoid: N=" + v_1_1.toFixed(3) + "m" : "TG-20 (Dışında)";
  } else {
    elements.barGeoid.textContent = "HGM TG-20 Jeoidi";
  }
  const btnEl = document.getElementById("btnSubtabGcp");
  const domEl_1 = document.getElementById("badgeGcpPairCount");
  const domEl_2 = document.getElementById("alertGcpNoPairs");
  const btnEl_1 = document.getElementById("btnPrintCadastre");
  if (v_6.length === 0) {
    if (btnEl) {
      btnEl.disabled = false;
      btnEl.classList.remove("disabled");
      btnEl.style.opacity = "1";
      btnEl.style.cursor = "pointer";
      btnEl.style.filter = "none";
      btnEl.title = "Bu dosyada çift okuma bulunamadı (Tüm noktalar tekil).";
    }
    if (domEl_1) {
      domEl_1.style.display = "inline-flex";
      domEl_1.className = "badge";
      domEl_1.style.background = "rgba(100, 116, 139, 0.25)";
      domEl_1.style.color = "#94a3b8";
      domEl_1.style.borderColor = "rgba(100, 116, 139, 0.4)";
      domEl_1.style.fontSize = "10px";
      domEl_1.style.padding = "1px 6px";
      domEl_1.innerHTML = "0 Çiftleme";
    }
    if (domEl_2) {
      domEl_2.style.display = "flex";
    }
    if (btnEl_1) {
      btnEl_1.disabled = true;
      btnEl_1.classList.add("disabled");
      btnEl_1.style.opacity = "0.5";
      btnEl_1.style.cursor = "not-allowed";
      btnEl_1.title = "Çift okuma ölçüsü bulunmadığından Resmi Ölçü Karnesi pasiftir. TG-20 PDF Raporu alabilirsiniz.";
    }
  } else {
    if (btnEl) {
      btnEl.disabled = false;
      btnEl.classList.remove("disabled");
      btnEl.style.opacity = "1";
      btnEl.style.cursor = "pointer";
      btnEl.style.filter = "none";
      btnEl.title = v_6.length + " adet çift okuma eşleşti.";
    }
    if (domEl_1) {
      domEl_1.style.display = "inline-flex";
      domEl_1.className = "badge";
      domEl_1.style.background = "rgba(16, 185, 129, 0.2)";
      domEl_1.style.color = "var(--emerald-400)";
      domEl_1.style.borderColor = "rgba(16, 185, 129, 0.4)";
      domEl_1.style.fontSize = "10px";
      domEl_1.style.padding = "1px 6px";
      domEl_1.innerHTML = v_6.length + " Çift Okuma ✓";
    }
    if (domEl_2) {
      domEl_2.style.display = "none";
    }
    if (btnEl_1) {
      btnEl_1.disabled = false;
      btnEl_1.classList.remove("disabled");
      btnEl_1.style.opacity = "1";
      btnEl_1.style.cursor = "pointer";
      btnEl_1.title = "";
    }
  }
  renderGpsFormatRtkTable(v_5);
  renderRw5MatchedTable(v_6, v_7);
  elements.txtCoordOutput.value = state.gnssEngine.exportFormattedCoordinateList(elements.selectCoordOrder.value);
  if (state.cadastreMap) {
    plotCadastrePointsOnMap();
  }
  updateProgress(100, "Tamamlandı");
  logMessage("✨ [BAŞARILI] '" + state.gnssEngine.detectedBrand + "' formatında " + v_5.length + " ham ölçü analiz edildi.");
  logMessage("🌐 Projeksiyon: ITRF-96 TM 3° Dilim " + state.gnssEngine.centralMeridian + "° E | " + (v_6.length > 0 ? v_6.length + " Çift Okuma Eşleşti." : "Çift Okuma Yok (Tüm noktalar tekil ölçü)."));
}
function renderGpsFormatRtkTable(arg1) {
  const v_2 = elements.tableGpsFormatRtkBody;
  const domEl = document.getElementById("theadGpsFormatRtk");
  if (!v_2) {
    return;
  }
  const v_3 = !!state.gnssEngine.isTg20Applied;
  if (domEl) {
    domEl.innerHTML = "\n            <tr>\n                <th>#</th>\n                <th>Point</th>\n                <th>Date/Time</th>\n                <th>Easting (Sağa)</th>\n                <th>Northing (Yukarı)</th>\n                <th>Elipsoit Kotu (h)</th>\n                " + (v_3 ? "<th class=\"th-tg20-n\"><i class=\"fa-solid fa-layer-group\"></i> TG-20 (N)</th><th class=\"th-tg20-h\"><i class=\"fa-solid fa-mountain\"></i> Ortometrik Kot (H)</th>" : "") + "\n                <th>Ep.</th>\n                <th>Hz</th>\n                <th>SAT.</th>\n                <th>hRms (m)</th>\n                <th>vRms (m)</th>\n                <th>Pdop</th>\n                <th>Status</th>\n                <th>Network</th>\n                <th>Method</th>\n                <th>Ant.Ht.</th>\n                <th>Latitude (N)</th>\n                <th>Longitude (E)</th>\n            </tr>\n        ";
  }
  v_2.innerHTML = "";
  arg1.forEach((item, idx) => {
    const trEl = document.createElement("tr");
    let str = "";
    let str_1 = "";
    if (v_3) {
      const v_1 = item.tg20N ? (item.tg20N.startsWith("+") || item.tg20N.startsWith("-") ? item.tg20N : "+" + item.tg20N) + " m" : "--";
      const v_2_1 = item.orthoH !== undefined ? item.orthoH.toFixed(3) : item.h.toFixed(3);
      str = "<td class=\"td-tg20-n\">" + v_1 + "</td>";
      str_1 = "<td class=\"td-tg20-h\">" + v_2_1 + "</td>";
    }
    const latVal = item.lat !== undefined ? item.lat.toFixed(8) + "°" : (item.latDec ? item.latDec.toFixed(8) + "°" : "-");
    const lonVal = item.lon !== undefined ? item.lon.toFixed(8) + "°" : (item.lonDec ? item.lonDec.toFixed(8) + "°" : "-");
    trEl.innerHTML = "\n            <td class=\"text-dim\">" + (idx + 1) + "</td>\n            <td class=\"font-bold text-cyan\">" + item.pn + "</td>\n            <td class=\"text-sm font-mono\">" + item.dt + " " + item.tm + "</td>\n            <td class=\"font-mono font-semibold\">" + item.e.toFixed(3) + "</td>\n            <td class=\"font-mono font-semibold\">" + item.n.toFixed(3) + "</td>\n            <td class=\"font-mono\">" + item.h.toFixed(3) + "</td>\n            " + str + "\n            " + str_1 + "\n            <td>" + item.epochs + "</td>\n            <td>" + item.hz + "</td>\n            <td>" + item.sats + "</td>\n            <td class=\"font-mono text-emerald\">" + item.hsdvVal.toFixed(3) + "</td>\n            <td class=\"font-mono text-sky\">" + item.vsdvVal.toFixed(3) + "</td>\n            <td class=\"font-mono\">" + item.pdop + "</td>\n            <td><span class=\"text-emerald font-bold\">" + item.status + "</span></td>\n            <td>" + (item.network || "-") + "</td>\n            <td>" + (item.method || "-") + "</td>\n            <td class=\"font-mono\">" + item.hr + "</td>\n            <td class=\"font-mono text-xs\">" + latVal + "</td>\n            <td class=\"font-mono text-xs\">" + lonVal + "</td>\n        ";
    v_2.appendChild(trEl);
  });
}
function renderRw5MatchedTable(arg1 = [], arg2 = []) {
  const v_3 = elements.tableRw5MatchedBody;
  const domEl = document.getElementById("theadRw5Matched");
  if (!v_3) {
    return;
  }
  const v_4 = !!state.gnssEngine.isTg20Applied;
  if (domEl) {
    domEl.innerHTML = "\n            <tr>\n                <th>Nokta Adı</th>\n                <th>1. Ölçü (Zaman)</th>\n                <th>2. Ölçü (Zaman)</th>\n                <th>Zaman Farkı</th>\n                <th>dY (cm)</th>\n                <th>dX (cm)</th>\n                <th>dH (cm)</th>\n                <th>dS (2B cm)</th>\n                <th>Ölçüm / Hata Kontrolü</th>\n                <th>Y (Sağa)</th>\n                <th>X (Yukarı)</th>\n                <th>" + (v_4 ? "Elipsoit Kotu (h)" : "H (Kot)") + "</th>\n                " + (v_4 ? "<th class=\"th-tg20-n\"><i class=\"fa-solid fa-layer-group\"></i> TG-20 (N)</th><th class=\"th-tg20-h\"><i class=\"fa-solid fa-mountain\"></i> Ortometrik Kot (H)</th>" : "") + "\n            </tr>\n        ";
  }
  v_3.innerHTML = "";
  const v_5 = (arg1?.length || 0) + (arg2?.length || 0);
  if (v_5 === 0) {
    v_3.innerHTML = "<tr><td colspan=\"" + (v_4 ? 14 : 12) + "\" class=\"text-center text-amber p-14\">Görüntülenecek ölçüm noktası bulunamadı.</td></tr>";
    return;
  }
  if (arg1 && arg1.length > 0) {
    arg1.forEach(item => {
      const trEl = document.createElement("tr");
      const v_1 = item.isDistPassed ? "<span class=\"badge-pass\">ÇİFT OKUMA (≤ 7cm)</span>" : "<span class=\"badge-fail\">LİMİT AŞILDI</span>";
      const timeDisplay = item.timeDiffStr || (parseFloat(item.timeDiffMin) < 60 ? item.timeDiffMin + " dk" : item.timeDiffHours + " sa");
      const v_2 = item.isTimePassed ? "<span class=\"text-emerald font-semibold\">" + timeDisplay + " (≥60 dk ✓)</span>" : "<span class=\"text-amber font-semibold\" title=\"BÖHHBÜY Madde 28: İki ölçüm arasında en az 60 dakika (1 saat) fark olmalıdır.\">" + timeDisplay + " (&lt;60 dk ⚠️)</span>";
      let str = "";
      let str_1 = "";
      if (v_4) {
        const v_1_1 = item.tg20N ? (item.tg20N.startsWith("+") || item.tg20N.startsWith("-") ? item.tg20N : "+" + item.tg20N) + " m" : "--";
        const v_2_1 = item.avgOrthoH || item.avgH;
        str = "<td class=\"td-tg20-n\">" + v_1_1 + "</td>";
        str_1 = "<td class=\"td-tg20-h\">" + v_2_1 + "</td>";
      }
      trEl.innerHTML = "\n                <td class=\"font-bold text-white\">" + item.pointName + "</td>\n                <td class=\"text-sm font-mono\">" + (item.p1.dt || "") + " " + (item.p1.tm || "") + "</td>\n                <td class=\"text-sm font-mono\">" + (item.p2.dt || "") + " " + (item.p2.tm || "") + "</td>\n                <td>" + v_2 + "</td>\n                <td class=\"font-mono\">" + item.dy + "</td>\n                <td class=\"font-mono\">" + item.dx + "</td>\n                <td class=\"font-mono\">" + item.dh + "</td>\n                <td class=\"font-mono font-extrabold text-sm " + (item.isDistPassed ? "text-emerald" : "text-rose") + "\">" + item.ds2d + " cm</td>\n                <td>" + v_1 + "</td>\n                <td class=\"font-mono text-cyan font-bold\">" + item.avgE + "</td>\n                <td class=\"font-mono text-cyan font-bold\">" + item.avgN + "</td>\n                <td class=\"font-mono\">" + item.avgH + "</td>\n                " + str + "\n                " + str_1 + "\n            ";
      v_3.appendChild(trEl);
    });
  }
  if (arg2 && arg2.length > 0) {
    arg2.forEach(item => {
      const trEl = document.createElement("tr");
      trEl.className = "bg-amber/5";
      const str = "<span class=\"badge-single-warn\">Tekil Ölçü (2. Okuma Yok)</span>";
      let str_1 = "";
      let str_2 = "";
      if (v_4) {
        const v_1 = item.tg20N ? (item.tg20N.startsWith("+") || item.tg20N.startsWith("-") ? item.tg20N : "+" + item.tg20N) + " m" : "--";
        const v_2 = item.orthoH !== undefined ? item.orthoH.toFixed(3) : item.h.toFixed(3);
        str_1 = "<td class=\"td-tg20-n\">" + v_1 + "</td>";
        str_2 = "<td class=\"td-tg20-h\">" + v_2 + "</td>";
      }
      trEl.innerHTML = "\n                <td class=\"font-bold text-amber\">" + item.pn + "</td>\n                <td class=\"text-sm font-mono\">" + (item.dt || "-") + " " + (item.tm || "") + "</td>\n                <td class=\"text-dim text-center\">--</td>\n                <td class=\"text-dim text-center\">--</td>\n                <td class=\"text-dim text-center\">--</td>\n                <td class=\"text-dim text-center\">--</td>\n                <td class=\"text-dim text-center\">--</td>\n                <td class=\"text-dim text-center\">--</td>\n                <td>" + str + "</td>\n                <td class=\"font-mono font-semibold\">" + item.e.toFixed(3) + "</td>\n                <td class=\"font-mono font-semibold\">" + item.n.toFixed(3) + "</td>\n                <td class=\"font-mono\">" + item.h.toFixed(3) + "</td>\n                " + str_1 + "\n                " + str_2 + "\n            ";
      v_3.appendChild(trEl);
    });
  }
}
function handlePrintCadastre() {
  if (!state.gnssEngine.rawPoints || state.gnssEngine.rawPoints.length === 0) {
    showToast("⚠️ Önce bir RW5 / GNSS veri dosyası yükleyip analiz edin.", "warning");
    return;
  }
  if (!state.gnssEngine.matchedPairs || state.gnssEngine.matchedPairs.length === 0) {
    showToast("ℹ️ Dosyada çift okuma bulunmadığından Resmi Ölçü Karnesi oluşturulamaz. Lütfen \"TG-20 PDF Raporu\" butonunu kullanın.", "warning");
    return;
  }
  const v_1 = state.gnssEngine.generatePrintableCadastreReport("TUSAGA-AKTİF RTK ÇİFT OKUMA & ÖLÇÜ KARNESİ");
  const v_2 = window.open("", "_blank");
  if (v_2) {
    v_2.document.write(v_1);
    v_2.document.close();
    v_2.focus();
    setTimeout(() => v_2.print(), 500);
  } else {
    alert("Lütfen tarayıcınızın açılır pencere engelleyicisini kapatın.");
  }
}
function initMergerDropzone() {
  const v_1 = elements.mergerDropzone;
  const v_2 = elements.mergerFileInput;
  ["dragenter", "dragover"].forEach(item => {
    v_1.addEventListener(item, event => {
      event.preventDefault();
      v_1.classList.add("dragover");
    });
  });
  ["dragleave", "drop"].forEach(item => {
    v_1.addEventListener(item, event => {
      event.preventDefault();
      v_1.classList.remove("dragover");
    });
  });
  v_1.addEventListener("drop", event => {
    const v_1_1 = Array.from(event.dataTransfer.files);
    if (v_1_1.length > 0) {
      processUploadedFiles(v_1_1);
    }
  });
  v_2.addEventListener("change", event => {
    const v_1_1 = Array.from(event.target.files);
    if (v_1_1.length > 0) {
      processUploadedFiles(v_1_1);
    }
  });
  elements.btnMergeAll.addEventListener("click", mergeAllGroups);
  let v_3 = null;
  let v_4 = null;
  const inputEl = document.getElementById("inputPpkBaseFile");
  const inputEl_1 = document.getElementById("inputPpkRoverFile");
  const domEl = document.getElementById("txtPpkBaseFileName");
  const domEl_1 = document.getElementById("txtPpkRoverFileName");
  async function v_5() {
    if (!v_3 || !v_4) {
      return;
    }
    try {
      const v_1_1 = UniversalRinexInspector.inspectPpkOverlap(v_3, v_4);
      const domEl_2 = document.getElementById("ppkAnalysisResultWrapper");
      if (!domEl_2) {
        return;
      }
      document.getElementById("statPpkBaseTime").textContent = v_1_1.baseStartStr + " - " + v_1_1.baseEndStr + " (" + v_1_1.baseDurationStr + ")";
      document.getElementById("statPpkRoverTime").textContent = v_1_1.roverStartStr + " - " + v_1_1.roverEndStr + " (" + v_1_1.roverDurationStr + ")";
      document.getElementById("statPpkOverlapDuration").textContent = v_1_1.overlapDurationStr;
      document.getElementById("statPpkBaselineDist").textContent = v_1_1.baselineKm > 0 ? v_1_1.baselineKm.toFixed(2) + " km" : "Anten XYZ Yok";
      document.getElementById("statPpkCommonSystems").textContent = v_1_1.commonConstellations.length > 0 ? v_1_1.commonConstellations.join(" + ") : "Ortak Sistem Yok";
      const domEl_3 = document.getElementById("badgePpkOverlapPercent");
      if (domEl_3) {
        domEl_3.textContent = "%" + v_1_1.overlapPercent.toFixed(1) + " Kapsama";
        domEl_3.style.background = v_1_1.overlapPercent >= 99.5 ? "rgba(16, 185, 129, 0.25)" : v_1_1.overlapPercent >= 70 ? "rgba(245, 158, 11, 0.25)" : "rgba(244, 63, 94, 0.25)";
        domEl_3.style.color = v_1_1.overlapPercent >= 99.5 ? "var(--emerald-400)" : v_1_1.overlapPercent >= 70 ? "var(--amber-400)" : "var(--rose-400)";
      }
      const domEl_4 = document.getElementById("bannerPpkStatus");
      const domEl_5 = document.getElementById("iconPpkStatus");
      const domEl_6 = document.getElementById("titlePpkStatus");
      const domEl_7 = document.getElementById("descPpkStatus");
      if (domEl_4) {
        domEl_4.style.borderColor = v_1_1.statusLevel === "SUCCESS" ? "rgba(16, 185, 129, 0.5)" : v_1_1.statusLevel === "WARNING" ? "rgba(245, 158, 11, 0.5)" : "rgba(244, 63, 94, 0.5)";
        domEl_4.style.background = v_1_1.statusLevel === "SUCCESS" ? "rgba(16, 185, 129, 0.1)" : v_1_1.statusLevel === "WARNING" ? "rgba(245, 158, 11, 0.1)" : "rgba(244, 63, 94, 0.1)";
      }
      if (domEl_5) {
        domEl_5.className = v_1_1.statusLevel === "SUCCESS" ? "fa-solid fa-circle-check" : v_1_1.statusLevel === "WARNING" ? "fa-solid fa-triangle-exclamation" : "fa-solid fa-circle-xmark";
        domEl_5.style.color = v_1_1.statusLevel === "SUCCESS" ? "var(--emerald-400)" : v_1_1.statusLevel === "WARNING" ? "var(--amber-400)" : "var(--rose-400)";
      }
      if (domEl_6) {
        domEl_6.textContent = v_1_1.statusTitle;
      }
      if (domEl_7) {
        domEl_7.textContent = v_1_1.statusDesc;
      }
      const domEl_8 = document.getElementById("barPpkBase");
      const domEl_9 = document.getElementById("barPpkRover");
      if (domEl_8 && domEl_9) {
        domEl_8.style.marginLeft = v_1_1.timeline.baseLeft + "%";
        domEl_8.style.width = v_1_1.timeline.baseWidth + "%";
        domEl_9.style.left = v_1_1.timeline.roverLeft + "%";
        domEl_9.style.width = v_1_1.timeline.roverWidth + "%";
        domEl_9.style.background = v_1_1.overlapPercent >= 99.5 ? "var(--emerald-400)" : v_1_1.overlapPercent >= 70 ? "var(--amber-400)" : "var(--rose-400)";
      }
      domEl_2.style.display = "flex";
      logMessage("🛰️ [PPK ANALİZİ] Gezici-Sabit Kapsaması: %" + v_1_1.overlapPercent.toFixed(1) + " | Baz: " + v_1_1.baselineKm.toFixed(2) + " km | Ortak: " + v_1_1.commonConstellations.join(", "));
      showToast("🛰️ PPK Kapsama Analizi: %" + v_1_1.overlapPercent.toFixed(1) + " Örtüşme", v_1_1.overlapPercent >= 99 ? "success" : "warning");
    } catch (v_1_1) {
      logMessage("❌ [PPK ANALİZ HATA] " + (v_1_1.message || v_1_1));
      showToast("❌ PPK Analiz Hatası: " + v_1_1.message, "error");
    }
  }
  inputEl?.addEventListener("change", async arg1 => {
    const v_2_1 = arg1.target.files?.[0];
    if (v_2_1) {
      const v_1_1 = await v_2_1.slice(0, 30000).text();
      v_3 = UniversalRinexInspector.inspectRinexHeader(v_1_1, v_2_1.name);
      if (domEl) {
        domEl.innerHTML = "<span style=\"color: var(--cyan-400); font-weight:700;\">" + v_2_1.name + "</span> <span class=\"badge\" style=\"font-size:10px;\">" + (v_3.markerName || "SABIT") + "</span>";
      }
      logMessage("🏛️ [SABIT RINEX] '" + v_2_1.name + "' yüklendi (" + (v_3.markerName || "BASE") + ").");
      if (v_4) {
        v_5();
      }
    }
  });
  inputEl_1?.addEventListener("change", async arg1 => {
    const v_2_1 = arg1.target.files?.[0];
    if (v_2_1) {
      const v_1_1 = await v_2_1.slice(0, 30000).text();
      v_4 = UniversalRinexInspector.inspectRinexHeader(v_1_1, v_2_1.name);
      if (domEl_1) {
        domEl_1.innerHTML = "<span style=\"color: var(--emerald-400); font-weight:700;\">" + v_2_1.name + "</span> <span class=\"badge\" style=\"font-size:10px;\">" + (v_4.markerName || "ROVER") + "</span>";
      }
      logMessage("🚁 [GEZICI RINEX] '" + v_2_1.name + "' yüklendi (" + (v_4.markerName || "ROVER") + ").");
      if (v_3) {
        v_5();
      }
    }
  });
}
async function processUploadedFiles(arg1) {
  logMessage("📂 " + arg1.length + " adet dosyanın RINEX başlıkları (Header) RAM'de taranıyor...");
  updateProgress(10, "Dosya başlıkları taranıyor...");
  state.mergerGroups = {};
  const obj = {
    constellations: new Set(),
    bands: new Set(),
    obsTypes: new Set()
  };
  for (let v_1 of arg1) {
    const headBlob = v_1.slice(0, 65536);
    const tailBlob = v_1.size > 65536 ? v_1.slice(Math.max(0, v_1.size - 65536)) : null;

    const readBlob = (blob) => new Promise(resolve => {
      if (!blob) return resolve("");
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result || "");
      reader.onerror = () => resolve("");
      reader.readAsText(blob);
    });

    const headText = await readBlob(headBlob);
    const tailText = await readBlob(tailBlob);

    const v_3_1 = UniversalRinexInspector.inspectRinexHeader(headText, v_1.name, tailText);
    v_3_1.presentConstellations.forEach(item => obj.constellations.add(item));
    v_3_1.presentBands.forEach(item => obj.bands.add(item));
    v_3_1.presentObsTypes.forEach(item => obj.obsTypes.add(item));
    const v_4 = v_3_1.markerName || v_1.name.replace(/\.[^/.]+$/, "").toUpperCase();
    const v_5 = v_3_1.year;
    const v_6 = v_3_1.doy;
    const v_7 = v_4 + "_" + v_5 + "_DOY" + String(v_6).padStart(3, "0");
    if (!state.mergerGroups[v_7]) {
      state.mergerGroups[v_7] = {
        id: v_7,
        station: v_4,
        year: v_5,
        doy: v_6,
        version: v_3_1.version,
        obsFiles: [],
        navGpsFiles: [],
        navGloFiles: []
      };
    }
    const v_8 = state.mergerGroups[v_7];
    const obj_1 = {
      name: v_1.name,
      size: v_1.size,
      fileRef: v_1,
      inspected: v_3_1
    };
    if (v_3_1.fileType === "OBS") {
      v_8.obsFiles.push(obj_1);
    } else if (v_3_1.fileType === "NAV_GPS" || v_3_1.fileType === "NAV_MIXED") {
      v_8.navGpsFiles.push(obj_1);
    } else if (v_3_1.fileType === "NAV_GLO") {
      v_8.navGloFiles.push(obj_1);
    } else {
      const v_1_2 = (v_1.name.split(".").pop() || "").toUpperCase();
      if (v_1_2.endsWith("O") || v_1_2 === "OBS" || v_1_2 === "RNX") {
        v_8.obsFiles.push(obj_1);
      } else if (v_1_2.endsWith("N") || v_1_2 === "NAV") {
        v_8.navGpsFiles.push(obj_1);
      } else if (v_1_2.endsWith("G") || v_1_2 === "GLO") {
        v_8.navGloFiles.push(obj_1);
      }
    }
  }
  const v_2 = Object.keys(state.mergerGroups);
  if (v_2.length === 0) {
    logMessage("⚠️ Uygun RINEX gözlem veya navigasyon dosyası tespit edilemedi.");
    updateProgress(0, "Hazır");
    return;
  }
  const v_3 = state.mergerGroups[v_2[0]];
  if (v_3 && v_3.year) {
    const domEl = document.getElementById("selectTargetVersion");
    if (domEl) {
      populateDynamicFormats(domEl.value, v_3.year);
    }
  }
  let minStartTimestamp = Infinity;
  let maxEndTimestamp = -Infinity;
  let detectedDateStr = "";
  let startFormattedTime = "00:00:00";
  let endFormattedTime = "23:59:59";
  let startSecOfDay = 0;
  let endSecOfDay = 86399;

  for (let grpKey in state.mergerGroups) {
    const grp = state.mergerGroups[grpKey];
    for (let f of grp.obsFiles) {
      if (f.inspected) {
        const first = f.inspected.firstObs;
        const last = f.inspected.lastObs;
        if (first && first.timestamp) {
          if (first.timestamp < minStartTimestamp) {
            minStartTimestamp = first.timestamp;
            detectedDateStr = first.dateStr || `${first.year}-${String(first.month).padStart(2, "0")}-${String(first.day).padStart(2, "0")}`;
            startFormattedTime = `${String(first.hour).padStart(2, "0")}:${String(first.minute).padStart(2, "0")}:${String(Math.floor(first.second)).padStart(2, "0")}`;
            startSecOfDay = first.hour * 3600 + first.minute * 60 + Math.floor(first.second);
          }
        }
        if (last && last.timestamp) {
          if (last.timestamp > maxEndTimestamp) {
            maxEndTimestamp = last.timestamp;
            endFormattedTime = `${String(last.hour).padStart(2, "0")}:${String(last.minute).padStart(2, "0")}:${String(Math.floor(last.second)).padStart(2, "0")}`;
            endSecOfDay = last.hour * 3600 + last.minute * 60 + Math.floor(last.second);
          }
        }
      }
    }
  }

  if (minStartTimestamp !== Infinity && maxEndTimestamp !== -Infinity && maxEndTimestamp >= minStartTimestamp) {
    state.detectedTimeWindow = {
      date: detectedDateStr,
      startSec: startSecOfDay,
      endSec: endSecOfDay,
      startTimestamp: minStartTimestamp,
      endTimestamp: maxEndTimestamp
    };

    const totalDurationSec = Math.max(0, Math.round((maxEndTimestamp - minStartTimestamp) / 1000));
    const hours = Math.floor(totalDurationSec / 3600);
    const remMinutes = Math.floor((totalDurationSec % 3600) / 60);
    const remSeconds = totalDurationSec % 60;

    let durationText = "";
    if (hours > 0) {
      durationText = `${hours} sa ${remMinutes} dk` + (remSeconds > 0 ? ` ${remSeconds} sn` : "");
    } else if (remMinutes > 0) {
      durationText = `${remMinutes} dk` + (remSeconds > 0 ? ` ${remSeconds} sn` : "");
    } else {
      durationText = `${remSeconds} sn`;
    }

    const domEl = document.getElementById("lblDetectedDate");
    if (domEl) {
      domEl.textContent = "Tarih: " + detectedDateStr;
    }
    const domEl_1 = document.getElementById("lblDetectedTimeRange");
    if (domEl_1) {
      domEl_1.textContent = startFormattedTime + " - " + endFormattedTime + " UTC";
    }
    const domEl_2 = document.getElementById("lblDetectedDuration");
    if (domEl_2) {
      domEl_2.textContent = durationText + ` (${(totalDurationSec / 3600).toFixed(2)} sa)`;
    }
    const inputEl = document.getElementById("inputCropStart");
    if (inputEl) {
      inputEl.value = startFormattedTime;
    }
    const inputEl_1 = document.getElementById("inputCropEnd");
    if (inputEl_1) {
      inputEl_1.value = endFormattedTime;
    }
  }
  logMessage("✅ " + v_2.length + " istasyon oturumu, " + obj.constellations.size + " uydu sistemi dosyadan tespit edildi.");
  renderDynamicFilters(obj);
  renderGroupsTable();
  updateProgress(100, "Tarama Tamamlandı");
  elements.mergerResultCard.style.display = "block";
}
function renderDynamicFilters(arg1) {
  const domEl = document.getElementById("containerConstellations");
  const domEl_1 = document.getElementById("containerBands");
  const domEl_2 = document.getElementById("containerObsTypes");
  const obj = {
    GPS: {
      label: "🇺🇸 GPS (G)",
      color: "var(--cyan-500)"
    },
    GLO: {
      label: "🇷🇺 GLONASS (R)",
      color: "var(--cyan-500)"
    },
    GAL: {
      label: "🇪🇺 GALILEO (E)",
      color: "var(--cyan-500)"
    },
    BDS: {
      label: "🇨🇳 BEIDOU (C)",
      color: "var(--cyan-500)"
    },
    QZS: {
      label: "🇯🇵 QZSS (J)",
      color: "var(--cyan-500)"
    },
    SBS: {
      label: "🛰️ SBAS (S)",
      color: "var(--cyan-500)"
    }
  };
  const obj_1 = {
    L1: {
      label: "📶 L1 / E1 / B1 (1575 MHz)",
      color: "var(--purple-500)"
    },
    L2: {
      label: "📶 L2 / G2 / B2 (1227 MHz)",
      color: "var(--purple-500)"
    },
    L5: {
      label: "📶 L5 / E5a / B2a (1176 MHz)",
      color: "var(--purple-500)"
    },
    E6: {
      label: "📶 E6 / B3 (1278 MHz)",
      color: "var(--purple-500)"
    }
  };
  const obj_2 = {
    Phase: {
      label: "📡 Taşıyıcı Faz (L)",
      color: "var(--emerald-400)"
    },
    Code: {
      label: "🎯 Kod / Mesafe (C / P)",
      color: "var(--emerald-400)"
    },
    Doppler: {
      label: "🔊 Doppler (D)",
      color: "var(--emerald-400)"
    },
    SNR: {
      label: "📶 SNR Sinyal Gücü (S)",
      color: "var(--emerald-400)"
    }
  };
  if (domEl) {
    domEl.innerHTML = "";
    if (arg1.constellations.size === 0) {
      arg1.constellations.add("GPS");
    }
    arg1.constellations.forEach(item => {
      const v_1 = obj[item] || {
        label: item,
        color: "var(--cyan-500)"
      };
      const labelEl = document.createElement("label");
      labelEl.className = "rinex-filter-chip";
      labelEl.innerHTML = "<input type=\"checkbox\" class=\"chk-dynamic-const\" data-const=\"" + item + "\" checked style=\"accent-color: " + v_1.color + ";\" /> <span>" + v_1.label + "</span>";
      domEl.appendChild(labelEl);
    });
  }
  if (domEl_1) {
    domEl_1.innerHTML = "";
    if (arg1.bands.size === 0) {
      arg1.bands.add("L1");
      arg1.bands.add("L2");
    }
    arg1.bands.forEach(item => {
      const v_1 = obj_1[item] || {
        label: item,
        color: "var(--purple-500)"
      };
      const labelEl = document.createElement("label");
      labelEl.className = "rinex-filter-chip";
      labelEl.innerHTML = "<input type=\"checkbox\" class=\"chk-dynamic-band\" data-band=\"" + item + "\" checked style=\"accent-color: " + v_1.color + ";\" /> <span>" + v_1.label + "</span>";
      domEl_1.appendChild(labelEl);
    });
  }
  if (domEl_2) {
    domEl_2.innerHTML = "";
    if (arg1.obsTypes.size === 0) {
      arg1.obsTypes.add("Phase");
      arg1.obsTypes.add("Code");
      arg1.obsTypes.add("SNR");
    }
    arg1.obsTypes.forEach(item => {
      const v_1 = obj_2[item] || {
        label: item,
        color: "var(--emerald-400)"
      };
      const labelEl = document.createElement("label");
      labelEl.className = "rinex-filter-chip";
      labelEl.innerHTML = "<input type=\"checkbox\" class=\"chk-dynamic-obs\" data-obs=\"" + item + "\" checked style=\"accent-color: " + v_1.color + ";\" /> <span>" + v_1.label + "</span>";
      domEl_2.appendChild(labelEl);
    });
  }
}
function renderGroupsTable() {
  const v_1 = elements.tableGroupsBody;
  v_1.innerHTML = "";
  for (let v_1_1 in state.mergerGroups) {
    const v_1_2 = state.mergerGroups[v_1_1];
    const trEl = document.createElement("tr");
    trEl.innerHTML = "\n            <td class=\"font-bold text-main font-mono\">\n              <i class=\"fa-solid fa-layer-group\" style=\"color: var(--cyan-400); margin-right: 6px;\"></i> " + v_1_2.id + "\n            </td>\n            <td style=\"font-weight: 800; color: var(--cyan-400); font-size: 13px;\">" + v_1_2.station + "</td>\n            <td><span class=\"badge-year-chip\">" + v_1_2.year + "</span></td>\n            <td><span style=\"background: rgba(139, 92, 246, 0.15); color: var(--purple-500); border: 1px solid var(--border-purple-glow); padding: 2px 8px; border-radius: 6px; font-weight: 700; font-family: var(--font-mono);\">DOY " + String(v_1_2.doy).padStart(3, "0") + "</span></td>\n            <td><span style=\"background: rgba(6, 182, 212, 0.15); color: var(--cyan-400); border: 1px solid var(--border-cyan-glow); padding: 3px 10px; border-radius: 20px; font-weight: 700;\">📁 " + v_1_2.obsFiles.length + " saat</span></td>\n            <td><span style=\"background: rgba(16, 185, 129, 0.15); color: var(--emerald-400); border: 1px solid var(--glow-emerald); padding: 3px 10px; border-radius: 20px; font-weight: 700;\">🛰️ " + v_1_2.navGpsFiles.length + " dosya</span></td>\n            <td><span style=\"background: rgba(245, 158, 11, 0.15); color: var(--amber-400); border: 1px solid rgba(245, 158, 11, 0.3); padding: 3px 10px; border-radius: 20px; font-weight: 700;\">📡 " + v_1_2.navGloFiles.length + " dosya</span></td>\n            <td>\n                <button class=\"btn btn-primary\" style=\"padding: 6px 14px; font-size: 12px;\" onclick=\"mergeSingleGroup('" + v_1_1 + "')\">\n                    <i class=\"fa-solid fa-bolt\"></i> İşle & İndir\n                </button>\n            </td>\n        ";
    v_1.appendChild(trEl);
  }
}
window.applyCropPreset = function (arg1) {
  if (!state.detectedTimeWindow) {
    return;
  }
  const {
    startSec: v_2,
    endSec: v_3
  } = state.detectedTimeWindow;
  const inputEl = document.getElementById("inputCropStart");
  const inputEl_1 = document.getElementById("inputCropEnd");
  const domEl = document.getElementById("chkEnableTimeCrop");
  const domEl_1 = document.getElementById("timeCropControlsContainer");
  const domEl_2 = document.getElementById("lblTimeCropStatusText");
  const v_4 = arg1_1 => {
    const v_2_1 = String(Math.floor(arg1_1 / 3600)).padStart(2, "0");
    const v_3_1 = String(Math.floor(arg1_1 % 3600 / 60)).padStart(2, "0");
    const v_4_1 = String(Math.floor(arg1_1 % 60)).padStart(2, "0");
    return v_2_1 + ":" + v_3_1 + ":" + v_4_1;
  };
  if (arg1 === "ALL") {
    inputEl.value = v_4(v_2);
    inputEl_1.value = v_4(v_3);
    if (domEl) {
      domEl.checked = false;
      if (domEl_1) {
        domEl_1.classList.remove("time-crop-enabled");
        domEl_1.classList.add("time-crop-disabled");
      }
      if (domEl_2) {
        domEl_2.textContent = "Filtre Kapalı";
        domEl_2.style.color = "var(--text-dim)";
      }
    }
  } else {
    if (domEl) {
      domEl.checked = true;
      if (domEl_1) {
        domEl_1.classList.remove("time-crop-disabled");
        domEl_1.classList.add("time-crop-enabled");
      }
      if (domEl_2) {
        domEl_2.textContent = "Filtre Aktif";
        domEl_2.style.color = "var(--cyan-400)";
      }
    }
    if (arg1 === "FIRST_1H") {
      inputEl.value = v_4(v_2);
      inputEl_1.value = v_4(Math.min(v_3, v_2 + 3600));
    } else if (arg1 === "FIRST_2H") {
      inputEl.value = v_4(v_2);
      inputEl_1.value = v_4(Math.min(v_3, v_2 + 7200));
    } else if (arg1 === "LAST_2H") {
      inputEl.value = v_4(Math.max(v_2, v_3 - 7200));
      inputEl_1.value = v_4(v_3);
    }
  }
};
const chkEnableTimeCrop = document.getElementById("chkEnableTimeCrop");
const timeCropControlsContainer = document.getElementById("timeCropControlsContainer");
const lblTimeCropStatusText = document.getElementById("lblTimeCropStatusText");
if (chkEnableTimeCrop && timeCropControlsContainer) {
  chkEnableTimeCrop.addEventListener("change", () => {
    if (chkEnableTimeCrop.checked) {
      timeCropControlsContainer.classList.remove("time-crop-disabled");
      timeCropControlsContainer.classList.add("time-crop-enabled");
      if (lblTimeCropStatusText) {
        lblTimeCropStatusText.textContent = "Filtre Aktif";
        lblTimeCropStatusText.style.color = "var(--cyan-400)";
      }
    } else {
      timeCropControlsContainer.classList.remove("time-crop-enabled");
      timeCropControlsContainer.classList.add("time-crop-disabled");
      if (lblTimeCropStatusText) {
        lblTimeCropStatusText.textContent = "Filtre Kapalı";
        lblTimeCropStatusText.style.color = "var(--text-dim)";
      }
    }
  });
}
function createSafeRinexWorker() {
  if (window.location.protocol === "file:") {
    return {
      postMessage: function (arg1) {
        if (arg1.action === "MERGE_GROUP") {
          setTimeout(() => {
            RinexMergerEngine.processGroup(arg1.group, arg1_1 => {
              if (this.onmessage) {
                this.onmessage({
                  data: arg1_1
                });
              }
            });
          }, 20);
        }
      },
      terminate: function () {},
      onmessage: null
    };
  }
  try {
    return new Worker("js/workers/rinex_merger_worker.js");
  } catch (v_1) {
    console.warn("Worker initialization blocked by browser file:// security, falling back to direct RAM execution:", v_1);
    return {
      postMessage: function (arg1) {
        if (arg1.action === "MERGE_GROUP") {
          setTimeout(() => {
            RinexMergerEngine.processGroup(arg1.group, arg1_1 => {
              if (this.onmessage) {
                this.onmessage({
                  data: arg1_1
                });
              }
            });
          }, 20);
        }
      },
      terminate: function () {},
      onmessage: null
    };
  }
}
window.mergeSingleGroup = async function (arg1) {
  const v_2 = state.mergerGroups[arg1];
  if (!v_2) {
    return;
  }
  const v_3 = document.getElementById("selectTargetVersion")?.value || "RINEX_211";
  const v_4 = document.getElementById("selectTargetFormat")?.value || "OBS_ONLY";
  const v_5 = parseInt(document.getElementById("selectDecimationStep")?.value) || 1;
  const obj = {};
  document.querySelectorAll(".chk-dynamic-const").forEach(item => {
    obj[item.dataset.const] = item.checked;
  });
  state.rinexEngine.setConstellations(obj);
  const obj_1 = {};
  document.querySelectorAll(".chk-dynamic-band").forEach(item => {
    obj_1[item.dataset.band] = item.checked;
  });
  state.rinexEngine.setBands(obj_1);
  const obj_2 = {};
  document.querySelectorAll(".chk-dynamic-obs").forEach(item => {
    obj_2[item.dataset.obs] = item.checked;
  });
  state.rinexEngine.setObsTypes(obj_2);
  const v_6 = document.getElementById("chkEnableTimeCrop")?.checked ?? false;
  let v_7 = null;
  let v_8 = null;
  if (v_6) {
    const v_1 = document.getElementById("inputCropStart")?.value || "00:00:00";
    const v_2_1 = v_1.split(":").map(Number);
    v_7 = (v_2_1[0] || 0) * 3600 + (v_2_1[1] || 0) * 60 + (v_2_1[2] || 0);
    const v_3_1 = document.getElementById("inputCropEnd")?.value || "23:59:59";
    const v_4_1 = v_3_1.split(":").map(Number);
    v_8 = (v_4_1[0] || 0) * 3600 + (v_4_1[1] || 0) * 60 + (v_4_1[2] || 0);
  }
  let str = "2.11";
  let flag = false;
  if (v_3 === "RINEX_210") {
    str = "2.10";
  } else if (v_3 === "RINEX_211") {
    str = "2.11";
  } else if (v_3 === "RINEX_300") {
    str = "3.00";
    flag = true;
  } else if (v_3 === "RINEX_302") {
    str = "3.02";
    flag = true;
  } else if (v_3 === "RINEX_303") {
    str = "3.03";
    flag = true;
  } else if (v_3 === "RINEX_304") {
    str = "3.04";
    flag = true;
  } else if (v_3 === "RINEX_305") {
    str = "3.05";
    flag = true;
  } else if (v_3 === "RINEX_400") {
    str = "4.00";
    flag = true;
  }
  const v_9 = Object.keys(obj).filter(item => obj[item]).join("/");
  logMessage("🚀 '" + arg1 + "' grubu işleniyor | Sistemler: " + (v_9 || "Tümü") + " | Sürüm: " + v_3 + " | Format: " + v_4 + " | Örnekleme: " + v_5 + "s...");
  updateProgress(15, "İçerikler okunuyor...");
  const v_10 = arg1_1 => {
    return new Promise((arg1_2, arg2) => {
      const v_3_1 = new FileReader();
      v_3_1.onload = () => arg1_2({
        name: arg1_1.name,
        text: v_3_1.result
      });
      v_3_1.onerror = arg2;
      v_3_1.readAsText(arg1_1.fileRef);
    });
  };
  const v_11 = await Promise.all(v_2.obsFiles.map(v_10));
  const v_12 = await Promise.all(v_2.navGpsFiles.map(v_10));
  const v_13 = await Promise.all(v_2.navGloFiles.map(v_10));
  const obj_3 = {
    id: v_2.id,
    station: v_2.station,
    year: v_2.year,
    doy: v_2.doy,
    targetVersion: str,
    decimation: v_5,
    allowedConstellations: obj,
    timeCrop: {
      enabled: v_6,
      startSec: v_7,
      endSec: v_8
    },
    obsFiles: v_11,
    navGpsFiles: v_12,
    navGloFiles: v_13
  };
  const v_14 = createSafeRinexWorker();
  v_14.postMessage({
    action: "MERGE_GROUP",
    group: obj_3
  });
  v_14.onmessage = async arg1_1 => {
    const {
      type: v_2_1,
      text: v_3_1,
      value: v_4_1,
      results: v_5_1,
      message: v_6_1
    } = arg1_1.data;
    if (v_2_1 === "LOG") {
      logMessage(v_3_1);
    }
    if (v_2_1 === "PROGRESS") {
      updateProgress(v_4_1, "İşleniyor...");
    }
    if (v_2_1 === "COMPLETE") {
      logMessage("🎉 [BAŞARILI] '" + arg1 + "' grubu başarıyla tamamlandı!");
      state.currentMergedFiles[arg1] = v_5_1;
      const v_1 = "" + v_2.station + String(v_2.doy).padStart(3, "0") + "0";
      if (v_3 === "RINEX_211" || v_3 === "RINEX_210") {
        if (v_4 === "OBS_YYO") {
          if (v_5_1.obs) {
            downloadTextFile(v_5_1.obs.filename, v_5_1.obs.content);
            logMessage("💾 [İNDİRİLDİ] " + v_5_1.obs.filename + " (RINEX " + str + " Yıl Uzantılı Gözlem).");
            showToast("💾 " + v_5_1.obs.filename + " indirildi.", "success");
          } else {
            showToast("Gözlem dosyası bulunamadı.", "warning");
          }
        } else if (v_4 === "OBS_EXT") {
          if (v_5_1.obs) {
            const v_1_1 = v_1 + ".obs";
            downloadTextFile(v_1_1, v_5_1.obs.content);
            logMessage("💾 [İNDİRİLDİ] " + v_1_1 + " (RINEX " + str + " .OBS Dosyası).");
            showToast("💾 " + v_1_1 + " indirildi.", "success");
          } else {
            showToast("Gözlem dosyası bulunamadı.", "warning");
          }
        } else if (v_4 === "NAV_YYN") {
          if (v_5_1.navGps) {
            downloadTextFile(v_5_1.navGps.filename, v_5_1.navGps.content);
            logMessage("💾 [İNDİRİLDİ] " + v_5_1.navGps.filename + " (GPS Seyir Dosyası).");
            showToast("💾 " + v_5_1.navGps.filename + " indirildi.", "success");
          } else {
            showToast("GPS Navigasyon dosyası bulunamadı.", "warning");
          }
        } else if (v_4 === "NAV_EXT") {
          if (v_5_1.navGps) {
            const v_1_1 = v_1 + ".nav";
            downloadTextFile(v_1_1, v_5_1.navGps.content);
            logMessage("💾 [İNDİRİLDİ] " + v_1_1 + " (.NAV GPS Seyir Dosyası).");
            showToast("💾 " + v_1_1 + " indirildi.", "success");
          } else {
            showToast("GPS Navigasyon dosyası bulunamadı.", "warning");
          }
        } else if (v_4 === "NAV_YYG") {
          if (v_5_1.navGlo) {
            downloadTextFile(v_5_1.navGlo.filename, v_5_1.navGlo.content);
            logMessage("💾 [İNDİRİLDİ] " + v_5_1.navGlo.filename + " (GLONASS Seyir Dosyası).");
            showToast("💾 " + v_5_1.navGlo.filename + " indirildi.", "success");
          } else {
            showToast("GLONASS Navigasyon dosyası bulunamadı.", "warning");
          }
        } else if (v_4 === "HATANAKA_YYD") {
          if (v_5_1.obs) {
            const v_1_1 = v_5_1.obs.filename.replace(/O$/i, "D");
            downloadTextFile(v_1_1, v_5_1.obs.content);
            logMessage("💾 [İNDİRİLDİ] " + v_1_1 + " (Hatanaka Compact RINEX ." + String(v_2.year % 100).padStart(2, "0") + "d).");
            showToast("💾 " + v_1_1 + " indirildi.", "success");
          }
        } else {
          downloadGroupZip(arg1, v_5_1);
          showToast("📦 " + arg1 + " ZIP arşivi hazırlandı ve indiriliyor.", "success");
        }
      } else if (flag) {
        const v_1_1 = v_2.station + "00TUR_R_" + v_2.year + String(v_2.doy).padStart(3, "0") + "0000_01D_" + v_5 + "S_MO.rnx";
        if (v_4 === "OBS_YYO") {
          if (v_5_1.obs) {
            downloadTextFile(v_5_1.obs.filename, v_5_1.obs.content);
            logMessage("💾 [İNDİRİLDİ] " + v_5_1.obs.filename + " (RINEX " + str + " 8.3 Gözlem Dosyası).");
            showToast("💾 " + v_5_1.obs.filename + " indirildi.", "success");
          } else {
            showToast("Gözlem dosyası bulunamadı.", "warning");
          }
        } else if (v_4 === "OBS_EXT") {
          if (v_5_1.obs) {
            const v_1_2 = v_1 + ".obs";
            downloadTextFile(v_1_2, v_5_1.obs.content);
            logMessage("💾 [İNDİRİLDİ] " + v_1_2 + " (RINEX " + str + " .OBS Dosyası).");
            showToast("💾 " + v_1_2 + " indirildi.", "success");
          } else {
            showToast("Gözlem dosyası bulunamadı.", "warning");
          }
        } else if (v_4 === "RNX_OBS") {
          if (v_5_1.obs) {
            downloadTextFile(v_1_1, v_5_1.obs.content);
            logMessage("💾 [İNDİRİLDİ] " + v_1_1 + " (Modern Multi-GNSS RINEX " + str + ").");
            showToast("💾 " + v_1_1 + " indirildi.", "success");
          }
        } else if (v_4 === "NAV_YYN") {
          if (v_5_1.navGps) {
            downloadTextFile(v_5_1.navGps.filename, v_5_1.navGps.content);
            logMessage("💾 [İNDİRİLDİ] " + v_5_1.navGps.filename + " (GPS Seyir Dosyası).");
            showToast("💾 " + v_5_1.navGps.filename + " indirildi.", "success");
          } else {
            showToast("GPS Navigasyon dosyası bulunamadı.", "warning");
          }
        } else if (v_4 === "NAV_EXT") {
          if (v_5_1.navGps) {
            const v_1_2 = v_1 + ".nav";
            downloadTextFile(v_1_2, v_5_1.navGps.content);
            logMessage("💾 [İNDİRİLDİ] " + v_1_2 + " (.NAV GPS Seyir Dosyası).");
            showToast("💾 " + v_1_2 + " indirildi.", "success");
          } else {
            showToast("GPS Navigasyon dosyası bulunamadı.", "warning");
          }
        } else if (v_4 === "NAV_YYG") {
          if (v_5_1.navGlo) {
            downloadTextFile(v_5_1.navGlo.filename, v_5_1.navGlo.content);
            logMessage("💾 [İNDİRİLDİ] " + v_5_1.navGlo.filename + " (GLONASS Seyir Dosyası).");
            showToast("💾 " + v_5_1.navGlo.filename + " indirildi.", "success");
          } else {
            showToast("GLONASS Navigasyon dosyası bulunamadı.", "warning");
          }
        } else if (v_4 === "RNX_NAV_MIX") {
          if (v_5_1.navGps) {
            const v_1_2 = v_2.station + "00TUR_R_" + v_2.year + String(v_2.doy).padStart(3, "0") + "0000_01D_MN.rnx";
            downloadTextFile(v_1_2, v_5_1.navGps.content);
            logMessage("💾 [İNDİRİLDİ] " + v_1_2 + " (Multi-GNSS Seyir Dosyası).");
            showToast("💾 " + v_1_2 + " indirildi.", "success");
          }
        } else if (v_4 === "HATANAKA_YYD") {
          if (v_5_1.obs) {
            const v_1_2 = v_5_1.obs.filename.replace(/O$/i, "D");
            downloadTextFile(v_1_2, v_5_1.obs.content);
            logMessage("💾 [İNDİRİLDİ] " + v_1_2 + " (Hatanaka Compact RINEX ." + String(v_2.year % 100).padStart(2, "0") + "d).");
            showToast("💾 " + v_1_2 + " indirildi.", "success");
          }
        } else if (v_4 === "HATANAKA_CRX") {
          const v_1_2 = v_1_1.replace(/\.rnx$/i, ".crx");
          if (v_5_1.obs) {
            downloadTextFile(v_1_2, v_5_1.obs.content);
            logMessage("💾 [İNDİRİLDİ] " + v_1_2 + " (Compact RINEX Multi-GNSS .crx).");
            showToast("💾 " + v_1_2 + " indirildi.", "success");
          }
        } else {
          downloadGroupZip(arg1, v_5_1);
          showToast("📦 " + arg1 + " Multi-GNSS ZIP arşivi hazırlandı ve indiriliyor.", "success");
        }
      }
      v_14.terminate();
    }
    if (v_2_1 === "ERROR") {
      logMessage("❌ [HATA] " + v_6_1);
      v_14.terminate();
    }
  };
};
async function runSppOnMergedResults(arg1, arg2, arg3, arg4, arg5) {
  const v_6 = new Worker("js/workers/pos_worker.js");
  v_6.postMessage({
    action: "PROCESS_SPP",
    obsText: arg2,
    navText: arg3,
    stepSeconds: arg4,
    obsFileName: arg1 + ".obs",
    navFileName: arg1 + ".nav"
  });
  v_6.onmessage = arg1_1 => {
    const {
      type: v_2,
      text: v_3,
      value: v_4,
      solutions: v_5,
      posText: v_6_1,
      csvText: v_7,
      summary: v_8,
      message: v_9
    } = arg1_1.data;
    if (v_2 === "LOG") {
      logMessage(v_3);
    }
    if (v_2 === "PROGRESS") {
      updateProgress(v_4, "SPP Hesaplanıyor...");
    }
    if (v_2 === "SPP_COMPLETE") {
      state.posSolutions = v_5;
      state.posText = v_6_1;
      state.csvText = v_7;
      logMessage("✨ [BAŞARILI] " + v_8.totalEpochs + " epoch için hassas konum çözümü üretildi!");
      logMessage("[KONUM] Enlem: " + v_8.avgLat.toFixed(8) + "° | Boylam: " + v_8.avgLon.toFixed(8) + "° | Kot: " + v_8.avgHeight.toFixed(3) + " m");
      if (arg5 === "NMEA_0183") {
        const v_1 = state.rinexEngine.generateNmeaLog(v_5);
        downloadTextFile(arg1 + ".nmea", v_1);
        logMessage("💾 [İNDİRİLDİ] " + arg1 + ".nmea (NMEA-0183 Telemetri Logu).");
      } else if (arg5 === "CSV_TELEMETRY") {
        downloadTextFile(arg1 + ".csv", v_7);
        logMessage("💾 [İNDİRİLDİ] " + arg1 + ".csv (Konum Tablosu).");
      } else {
        downloadTextFile(arg1 + ".pos", v_6_1);
        logMessage("💾 [İNDİRİLDİ] " + arg1 + ".pos (RTKLIB Hassas Çözüm Dosyası).");
      }
      v_6.terminate();
    }
    if (v_2 === "ERROR") {
      logMessage("❌ [HATA] " + v_9);
      v_6.terminate();
    }
  };
}
async function mergeAllGroups() {
  for (let v_1 in state.mergerGroups) {
    await window.mergeSingleGroup(v_1);
  }
}
function downloadGroupZip(arg1, arg2) {
  const v_3 = new JSZip();
  if (arg2.obs) {
    v_3.file(arg2.obs.filename, arg2.obs.content);
  }
  if (arg2.navGps) {
    v_3.file(arg2.navGps.filename, arg2.navGps.content);
  }
  if (arg2.navGlo) {
    v_3.file(arg2.navGlo.filename, arg2.navGlo.content);
  }
  v_3.generateAsync({
    type: "blob"
  }).then(arg1_1 => {
    const v_2 = URL.createObjectURL(arg1_1);
    const aEl = document.createElement("a");
    aEl.href = v_2;
    aEl.download = arg1 + "_MERGED.zip";
    document.body.appendChild(aEl);
    aEl.click();
    document.body.removeChild(aEl);
    URL.revokeObjectURL(v_2);
  });
}
function downloadTextFile(arg1, arg2) {
  const v_3 = new Blob([arg2], {
    type: "text/plain;charset=utf-8"
  });
  const v_4 = URL.createObjectURL(v_3);
  const aEl = document.createElement("a");
  aEl.href = v_4;
  aEl.download = arg1;
  document.body.appendChild(aEl);
  aEl.click();
  document.body.removeChild(aEl);
  URL.revokeObjectURL(v_4);
}
function createBaseLayers(options = {}) {
  // 1. Google Hibrit (Yüksek Çözünürlüklü Uydu + Karayolları + İl/İlçe/Köy/Mahalle İsimleri)
  const layerGoogleHybridDetailed = L.tileLayer("https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}", {
    maxZoom: 22,
    attribution: "&copy; Google Maps (Detaylı Hibrit Uydu & Yerleşim)"
  });

  // 2. Google Detaylı Vektör Yol Haritası (Caddeler, Sokaklar, Şehirler)
  const layerGoogleStreets = L.tileLayer("https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}", {
    maxZoom: 22,
    attribution: "&copy; Google Maps (Detaylı Yol & Şehir Haritası)"
  });

  // 3. Google Saf Uydu (Yazısız)
  const layerGoogleSatellitePure = L.tileLayer("https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}", {
    maxZoom: 22,
    attribution: "&copy; Google Maps (Saf Uydu)"
  });

  // 4. Esri Detaylı Topoğrafik Harita (Eşyükselti Eğrileri, Coğrafi İsimler)
  const layerEsriTopo = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}", {
    maxZoom: 19,
    attribution: "&copy; Esri World Topo Map"
  });

  // 5. Esri Yüksek Çözünürlüklü Uydu
  const layerEsriSat = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", {
    maxZoom: 19,
    attribution: "&copy; Esri World Imagery"
  });

  // 6. OpenStreetMap Standart Detaylı
  const layerOsm = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: "&copy; OpenStreetMap Katkıda Bulunanlar"
  });

  // 7. CartoDB Karanlık Mühendislik
  const layerCartoDark = L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/dark_all/{z}/{x}/{y}.png", {
    maxZoom: 19,
    subdomains: "abcd",
    attribution: "&copy; CartoDB Dark (Detaylı)"
  });

  // 8. CartoDB Aydınlık Mühendislik
  const layerCartoLight = L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/light_all/{z}/{x}/{y}.png", {
    maxZoom: 19,
    subdomains: "abcd",
    attribution: "&copy; CartoDB Light (Detaylı)"
  });

  // 9. Google Topoğrafya (Kabartmalı Arazi)
  const layerGoogleTerrain = L.tileLayer("https://mt1.google.com/vt/lyrs=p&x={x}&y={y}&z={z}", {
    maxZoom: 22,
    attribution: "&copy; Google Terrain (Detaylı Arazi)"
  });

  const baseMaps = {
    "🛰️ Google Hibrit (Detaylı Uydu + Yollar & Yer İsimleri)": layerGoogleHybridDetailed,
    "🗺️ Google Yol & Şehir Haritası": layerGoogleStreets,
    "🌍 Google Saf Uydu (Yazısız)": layerGoogleSatellitePure,
    "⛰️ Esri Topoğrafya & Coğrafi Detay": layerEsriTopo,
    "📡 Esri Yüksek Çözünürlüklü Uydu": layerEsriSat,
    "🌐 OpenStreetMap Standart": layerOsm,
    "⛰️ Google Arazi & Yükselti": layerGoogleTerrain,
    "🌙 CartoDB Karanlık Detay": layerCartoDark,
    "☀️ CartoDB Aydınlık Detay": layerCartoLight
  };

  // Varsayılan Katman: Her zaman Detaylı Google Hibrit
  let defaultLayer = layerGoogleHybridDetailed;
  if (options.defaultType === "dark") defaultLayer = layerCartoDark;
  else if (options.defaultType === "streets") defaultLayer = layerGoogleStreets;
  else if (options.defaultType === "pure_sat") defaultLayer = layerGoogleSatellitePure;

  return {
    baseMaps: baseMaps,
    defaultLayer: defaultLayer
  };
}
function initMap() {
  if (state.map) {
    state.map.invalidateSize();
    return;
  }
  const {
    baseMaps: v_1,
    defaultLayer: v_2
  } = createBaseLayers({ defaultType: "hybrid" });
  state.map = L.map("mapContainer", {
    center: [39, 35.2],
    zoom: 6,
    layers: [v_2]
  });
  L.control.layers(v_1, null, {
    position: "topright"
  }).addTo(state.map);
  state.mapLayerGroup = L.layerGroup().addTo(state.map);
  state.paftaLayerGroup = L.layerGroup().addTo(state.map);
  state.domLayerGroup = L.layerGroup().addTo(state.map);
  state.importedKmlLayerGroup = L.layerGroup().addTo(state.map);
  state.intersectingPaftaLayerGroup = L.layerGroup().addTo(state.map);
  if (state.posSolutions && state.posSolutions.length > 0) {
    plotTrajectoryOnMap(state.posSolutions);
  }
  document.getElementById("btnExportKml")?.addEventListener("click", exportKml);
  document.getElementById("btnExportGeoJson")?.addEventListener("click", exportGeoJson);
  initKmlKmzImporter();
  const btnEl = document.getElementById("btnPafta100k");
  const btnEl_1 = document.getElementById("btnPafta50k");
  const btnEl_2 = document.getElementById("btnPafta25k");
  const btnEl_3 = document.getElementById("btnPaftaOff");
  const btnEl_4 = document.getElementById("btnToggleDom");
  const inputEl = document.getElementById("inputPaftaSearch");
  const btnEl_5 = document.getElementById("btnPaftaSearch");
  const domEl = document.getElementById("cardActivePafta");
  const btnEl_6 = document.getElementById("btnClosePaftaCard");
  function updatePaftaScaleButtonUi(scale) {
    btnEl?.classList.remove("btn-pafta-active");
    btnEl_1?.classList.remove("btn-pafta-active-50k");
    btnEl_2?.classList.remove("btn-pafta-active-25k");
    btnEl_3?.classList.remove("btn-secondary");
    if (scale === "100k") {
      btnEl?.classList.add("btn-pafta-active");
    } else if (scale === "50k") {
      btnEl_1?.classList.add("btn-pafta-active-50k");
    } else if (scale === "25k") {
      btnEl_2?.classList.add("btn-pafta-active-25k");
    } else if (scale === "off") {
      btnEl_3?.classList.add("btn-secondary");
    }
  }

  // Yukarıdaki butonlar sadece arka plandaki tüm Türkiye grid çizgilerini açıp kapatır
  function toggleBackgroundPaftaGrid(scale) {
    state.activePaftaScale = scale;
    updatePaftaScaleButtonUi(scale);

    if (scale === "off") {
      state.paftaLayerGroup.clearLayers();
      if (state.highlightedPaftaLayer) {
        state.map.removeLayer(state.highlightedPaftaLayer);
        state.highlightedPaftaLayer = null;
      }
      if (domEl) {
        domEl.style.display = "none";
      }
      logMessage("🗺️ Tüm pafta grid çizgileri kapatıldı.");
      return;
    }
    renderPaftaGrid();
    logMessage("🗺️ Tüm Türkiye 1/" + scale.replace("k", " 000") + " Pafta Grid Çizgileri gösteriliyor.");
    showToast("🗺️ 1/" + scale.replace("k", " 000") + " Grid Çizgileri açıldı.", "success");
  }

  btnEl?.addEventListener("click", () => toggleBackgroundPaftaGrid("100k"));
  btnEl_1?.addEventListener("click", () => toggleBackgroundPaftaGrid("50k"));
  btnEl_2?.addEventListener("click", () => toggleBackgroundPaftaGrid("25k"));
  btnEl_3?.addEventListener("click", () => toggleBackgroundPaftaGrid("off"));

  // İlk açılışta varsayılan tıklama pafta ölçeği: Her zaman 1/100 000
  state.currentIntersectScale = "100k";
  state.activePaftaScale = "off"; // Başlangıçta arka plan tüm grid kapalı, sadece tıklanan/alan paftası açılır
  updatePaftaScaleButtonUi("off");

  function v_5() {
    state.isDomLayerActive = !state.isDomLayerActive;
    if (state.isDomLayerActive) {
      btnEl_4?.classList.add("btn-dom-active");
      renderDomGrid();
      logMessage("🌐 TUREF TM 3° Dilim Sınırları (DOM 27°-45°) haritada aktif.");
      showToast("🌐 DOM 3° Dilimleri (Dilim 9 - 15) yüklendi.", "success");
    } else {
      btnEl_4?.classList.remove("btn-dom-active");
      state.domLayerGroup.clearLayers();
      logMessage("🌐 DOM 3° Dilim sınırları gizlendi.");
      showToast("🌐 DOM sınırları kapatıldı.", "info");
    }
  }
  btnEl_4?.addEventListener("click", v_5);

  state.map.on("moveend", () => {
    if (state.activePaftaScale !== "off") {
      renderPaftaGrid();
    }
  });

  // Haritaya tıklandığında (KML yokken varsayılan 100k, KML modalında seçilen ne ise o ölçek açılır)
  state.map.on("click", arg1 => {
    const {
      lat: clickLat,
      lng: clickLng
    } = arg1.latlng;
    if (clickLat < 34 || clickLat > 43 || clickLng < 25 || clickLng > 45.5) {
      return;
    }
    const allSheets = state.paftaEngine.getAllSheetsForPoint(clickLat, clickLng);

    // Sağdaki modalda seçili olan ölçek (KML yokken varsayılan: 100k)
    const activeClickScale = state.currentIntersectScale || "100k";

    let targetSheet = allSheets.s100k;
    if (activeClickScale === "100k") {
      targetSheet = allSheets.s100k;
    } else if (activeClickScale === "50k") {
      targetSheet = allSheets.s50k;
    } else if (activeClickScale === "25k") {
      targetSheet = allSheets.s25k;
    }

    highlightSheet(targetSheet);
    showFloatingPaftaCard(targetSheet, allSheets);
  });
  function v_6() {
    const v_1_1 = inputEl.value.trim();
    if (!v_1_1) {
      showToast("Lütfen aramak istediğiniz pafta adını yazın (Örn: F22, H29-b, K18-c2).", "warning");
      return;
    }
    const v_2_1 = state.paftaEngine.resolveSheetByName(v_1_1);
    if (!v_2_1) {
      showToast("⚠️ '" + v_1_1 + "' pafta formatı bulunamadı. Örn: 'F22', 'H29-a', 'K18-c2'", "error");
      return;
    }
    if (v_2_1.scale === "1/100 000" && state.activePaftaScale !== "100k" && state.activePaftaScale !== "off") {
      toggleBackgroundPaftaGrid("100k");
    } else if (v_2_1.scale === "1/50 000" && state.activePaftaScale !== "50k" && state.activePaftaScale !== "off") {
      toggleBackgroundPaftaGrid("50k");
    } else if (v_2_1.scale === "1/25 000" && state.activePaftaScale !== "25k" && state.activePaftaScale !== "off") {
      toggleBackgroundPaftaGrid("25k");
    }
    const items = [[v_2_1.minLat, v_2_1.minLon], [v_2_1.maxLat, v_2_1.maxLon]];
    state.map.flyToBounds(items, {
      maxZoom: 14,
      padding: [60, 60]
    });
    highlightSheet(v_2_1);
    showFloatingPaftaCard(v_2_1);
    logMessage("🎯 [PAFTA BULUNDU] " + v_2_1.name + " (" + v_2_1.scale + ") | Merkez: " + v_2_1.centerLat.toFixed(4) + "N, " + v_2_1.centerLon.toFixed(4) + "E");
    showToast("🎯 " + v_2_1.name + " Paftasına odaklanıldı (" + v_2_1.scale + ")", "success");
  }
  btnEl_5?.addEventListener("click", v_6);
  inputEl?.addEventListener("keydown", arg1 => {
    if (arg1.key === "Enter") {
      v_6();
    }
  });
  btnEl_6?.addEventListener("click", () => {
    if (domEl) {
      domEl.style.display = "none";
    }
    if (state.highlightedPaftaLayer) {
      state.map.removeLayer(state.highlightedPaftaLayer);
      state.highlightedPaftaLayer = null;
    }
  });
  document.getElementById("btnDownloadPaftaKml")?.addEventListener("click", () => {
    if (!state.selectedPaftaSheet) {
      return;
    }
    const v_1_1 = state.paftaEngine.exportSheetKml(state.selectedPaftaSheet);
    downloadTextFile(state.selectedPaftaSheet.name + "_pafta.kml", v_1_1);
    showToast("💾 " + state.selectedPaftaSheet.name + "_pafta.kml indirildi.", "success");
  });
  document.getElementById("btnDownloadPaftaDxf")?.addEventListener("click", () => {
    if (!state.selectedPaftaSheet) {
      return;
    }
    const v_1_1 = state.paftaEngine.exportSheetDxf(state.selectedPaftaSheet, state.gnssEngine.geodesy);
    downloadTextFile(state.selectedPaftaSheet.name + "_pafta.dxf", v_1_1);
    showToast("💾 " + state.selectedPaftaSheet.name + "_pafta.dxf indirildi.", "success");
  });
  document.getElementById("btnDownloadPaftaJson")?.addEventListener("click", () => {
    if (!state.selectedPaftaSheet) {
      return;
    }
    const v_1_1 = state.selectedPaftaSheet;
    const v_2_1 = state.paftaEngine.getHgmDatumRecord(v_1_1.name, v_1_1.centerLat, v_1_1.centerLon);
    const obj = {
      type: "FeatureCollection",
      features: [{
        type: "Feature",
        properties: {
          name: v_1_1.name,
          scale: v_1_1.scale,
          regionalName: v_1_1.regionalName || "",
          hgm_yukseklik_duz_m: v_2_1.yukseklikDuz,
          hgm_yukari_duz_m: v_2_1.yukariDuz,
          hgm_saga_duz_m: v_2_1.sagaDuz,
          hgm_enlem_duz_arcsec: v_2_1.enlemDuz,
          hgm_boylam_duz_arcsec: v_2_1.boylamDuz
        },
        geometry: {
          type: "Polygon",
          coordinates: [[[v_1_1.minLon, v_1_1.minLat], [v_1_1.maxLon, v_1_1.minLat], [v_1_1.maxLon, v_1_1.maxLat], [v_1_1.minLon, v_1_1.maxLat], [v_1_1.minLon, v_1_1.minLat]]]
        }
      }]
    };
    downloadTextFile(v_1_1.name + "_pafta.geojson", JSON.stringify(obj, null, 2));
    showToast("💾 " + v_1_1.name + "_pafta.geojson indirildi.", "success");
  });
  window.downloadPaftaDirect = (arg1, arg2) => {
    const v_3_1 = state.paftaEngine.resolveSheetByName(arg1);
    if (!v_3_1) {
      return;
    }
    if (arg2 === "kml") {
      downloadTextFile(v_3_1.name + "_pafta.kml", state.paftaEngine.exportSheetKml(v_3_1));
    } else if (arg2 === "dxf") {
      downloadTextFile(v_3_1.name + "_pafta.dxf", state.paftaEngine.exportSheetDxf(v_3_1, state.gnssEngine.geodesy));
    } else if (arg2 === "json") {
      const v_1_1 = state.paftaEngine.getHgmDatumRecord(v_3_1.name, v_3_1.centerLat, v_3_1.centerLon);
      const obj = {
        type: "FeatureCollection",
        features: [{
          type: "Feature",
          properties: {
            name: v_3_1.name,
            scale: v_3_1.scale,
            regionalName: v_3_1.regionalName || "",
            hgm_yukseklik_duz_m: v_1_1.yukseklikDuz,
            hgm_yukari_duz_m: v_1_1.yukariDuz,
            hgm_saga_duz_m: v_1_1.sagaDuz,
            hgm_enlem_duz_arcsec: v_1_1.enlemDuz,
            hgm_boylam_duz_arcsec: v_1_1.boylamDuz
          },
          geometry: {
            type: "Polygon",
            coordinates: [[[v_3_1.minLon, v_3_1.minLat], [v_3_1.maxLon, v_3_1.minLat], [v_3_1.maxLon, v_3_1.maxLat], [v_3_1.minLon, v_3_1.maxLat], [v_3_1.minLon, v_3_1.minLat]]]
          }
        }]
      };
      downloadTextFile(v_3_1.name + "_pafta.geojson", JSON.stringify(obj, null, 2));
    }
    showToast("💾 " + v_3_1.name + "_pafta." + arg2 + " indirildi.", "success");
  };
}
function initKmlKmzImporter() {
  const inputEl = document.getElementById("inputImportKml");
  const mapEl = document.getElementById("mapContainer");
  const domEl = document.getElementById("cardIntersectingPaftas");
  const btnEl = document.getElementById("btnCloseIntersectingCard");
  const elementsList = document.querySelectorAll(".btn-intersect-scale");
  state.currentIntersectScale = "25k";
  state.importedProjectData = null;
  inputEl?.addEventListener("change", async arg1 => {
    const v_2 = arg1.target.files?.[0];
    if (v_2) {
      await processImportedKmlKmz(v_2);
      inputEl.value = "";
    }
  });
  mapEl?.addEventListener("dragover", arg1 => {
    arg1.preventDefault();
    mapEl.style.outline = "2px dashed var(--cyan-400)";
  });
  mapEl?.addEventListener("dragleave", arg1 => {
    arg1.preventDefault();
    mapEl.style.outline = "none";
  });
  mapEl?.addEventListener("drop", async arg1 => {
    arg1.preventDefault();
    mapEl.style.outline = "none";
    const v_2 = arg1.dataTransfer?.files?.[0];
    if (v_2) {
      const v_1 = v_2.name.split(".").pop().toLowerCase();
      if (["kml", "kmz", "geojson", "json"].includes(v_1)) {
        await processImportedKmlKmz(v_2);
      } else {
        showToast("⚠️ Lütfen .KML, .KMZ veya .GeoJSON uzantılı bir dosya yükleyin.", "warning");
      }
    }
  });
  btnEl?.addEventListener("click", () => {
    if (domEl) {
      domEl.style.display = "none";
    }
    if (state.intersectingPaftaLayerGroup) {
      state.intersectingPaftaLayerGroup.clearLayers();
    }
    state.currentIntersectScale = "100k"; // Modal kapatılınca tıklama ölçeği 100k'ya döner
  });
  elementsList.forEach(item => {
    item.addEventListener("click", () => {
      elementsList.forEach(item_1 => {
        item_1.classList.remove("btn-primary");
        item_1.classList.add("btn-secondary");
      });
      item.classList.remove("btn-secondary");
      item.classList.add("btn-primary");
      const chosenScale = item.getAttribute("data-scale") || "25k";
      state.currentIntersectScale = chosenScale; // Tıklama ve analiz ölçeğini ayarla

      if (state.importedProjectData) {
        renderIntersectingPaftasAnalysis(state.importedProjectData);
      }
    });
  });
}
async function processImportedKmlKmz(arg1) {
  showToast("📂 '" + arg1.name + "' okunuyor ve çözümleniyor...", "info");
  logMessage("📂 [IMPORT] '" + arg1.name + "' dosyası içe aktarılıyor...");
  try {
    const v_1 = await parseKmlOrKmzFile(arg1);
    if (!v_1 || !v_1.features || v_1.features.length === 0) {
      showToast("⚠️ Dosya içinde geçerli nokta, çizgi veya poligon geometrisi bulunamadı.", "warning");
      return;
    }
    state.importedKmlLayerGroup.clearLayers();
    const v_2 = L.geoJSON(v_1, {
      style: arg1_1 => ({
        color: "#06b6d4",
        weight: 3,
        opacity: 0.9,
        fillColor: "#06b6d4",
        fillOpacity: 0.25,
        dashArray: null
      }),
      pointToLayer: (arg1_1, arg2) => {
        return L.circleMarker(arg2, {
          radius: 6,
          fillColor: "#f59e0b",
          color: "#ffffff",
          weight: 2,
          opacity: 1,
          fillOpacity: 0.9
        });
      },
      onEachFeature: (arg1_1, arg2) => {
        const v_3_1 = arg1_1.properties?.name || "Proje Unsuru";
        const v_4 = arg1_1.properties?.description || "";
        arg2.bindPopup("<b>" + v_3_1 + "</b>" + (v_4 ? "<br><small>" + v_4 + "</small>" : ""));
      }
    }).addTo(state.importedKmlLayerGroup);
    const v_3 = v_2.getBounds();
    if (!v_3.isValid()) {
      showToast("⚠️ Geometri koordinatları geçerli bir harita sınırına dönüştürülemedi.", "error");
      return;
    }
    state.map.fitBounds(v_3, {
      padding: [50, 50]
    });
    state.importedProjectData = {
      fileName: arg1.name,
      bounds: v_3,
      geojson: v_1,
      featureCount: v_1.features.length
    };

    // KML yüklendiğinde analiz ölçeğini kesinlikle 1/25 000 olarak başlat ve UI'ı güncelle
    state.currentIntersectScale = "25k";
    const scaleBtns = document.querySelectorAll(".btn-intersect-scale");
    scaleBtns.forEach(btn => {
      if (btn.getAttribute("data-scale") === "25k") {
        btn.classList.remove("btn-secondary");
        btn.classList.add("btn-primary");
      } else {
        btn.classList.remove("btn-primary");
        btn.classList.add("btn-secondary");
      }
    });

    renderIntersectingPaftasAnalysis(state.importedProjectData);
    logMessage("✨ [BAŞARILI] '" + arg1.name + "' haritaya yüklendi (" + v_1.features.length + " geometri, 1/25 000 paftaları hesaplandı).");
    showToast("✨ '" + arg1.name + "' yüklendi ve 1/25 000 temas eden paftalar hesaplandı.", "success");
  } catch (v_1) {
    logMessage("❌ [HATA] KML/KMZ işleme hatası: " + (v_1.message || v_1));
    showToast("❌ Dosya işlenemedi: " + (v_1.message || "Geçersiz format"), "error");
  }
}
async function parseKmlOrKmzFile(arg1) {
  const v_2 = arg1.name.split(".").pop().toLowerCase();
  if (v_2 === "kmz") {
    if (typeof JSZip === "undefined") {
      throw new Error("KMZ açıcı JSZip modülü bulunamadı.");
    }
    const v_1 = await JSZip.loadAsync(arg1);
    const v_2_1 = Object.keys(v_1.files).find(item => item.toLowerCase().endsWith(".kml"));
    if (!v_2_1) {
      throw new Error("KMZ arşivi içinde geçerli bir .kml dosyası bulunamadı.");
    }
    const v_3 = await v_1.files[v_2_1].async("string");
    return parseKmlTextToGeoJson(v_3);
  } else if (v_2 === "geojson" || v_2 === "json") {
    const v_1 = await arg1.text();
    return JSON.parse(v_1);
  } else {
    const v_1 = await arg1.text();
    return parseKmlTextToGeoJson(v_1);
  }
}
function parseKmlTextToGeoJson(arg1) {
  const v_2 = new DOMParser();
  const v_3 = v_2.parseFromString(arg1, "text/xml");
  const v_4 = v_3.getElementsByTagName("Placemark");
  const items = [];
  for (let num = 0; num < v_4.length; num++) {
    const v_1 = v_4[num];
    const v_2_1 = v_1.getElementsByTagName("name")[0]?.textContent?.trim() || "Geometri " + (num + 1);
    const v_3_1 = v_1.getElementsByTagName("description")[0]?.textContent?.trim() || "";
    const v_4_1 = v_1.getElementsByTagName("Polygon");
    for (let v_1_1 of v_4_1) {
      const v_1_2 = v_1_1.getElementsByTagName("coordinates");
      for (let v_1_3 of v_1_2) {
        const v_1_4 = parseCoordString(v_1_3.textContent);
        if (v_1_4.length >= 3) {
          items.push({
            type: "Feature",
            properties: {
              name: v_2_1,
              description: v_3_1
            },
            geometry: {
              type: "Polygon",
              coordinates: [v_1_4]
            }
          });
        }
      }
    }
    const v_5 = v_1.getElementsByTagName("LineString");
    for (let v_1_1 of v_5) {
      const v_1_2 = v_1_1.getElementsByTagName("coordinates")[0];
      if (v_1_2) {
        const v_1_3 = parseCoordString(v_1_2.textContent);
        if (v_1_3.length >= 2) {
          items.push({
            type: "Feature",
            properties: {
              name: v_2_1,
              description: v_3_1
            },
            geometry: {
              type: "LineString",
              coordinates: v_1_3
            }
          });
        }
      }
    }
    const v_6 = v_1.getElementsByTagName("Point");
    for (let v_1_1 of v_6) {
      const v_1_2 = v_1_1.getElementsByTagName("coordinates")[0];
      if (v_1_2) {
        const v_1_3 = v_1_2.textContent.trim().split(",").map(Number);
        if (!isNaN(v_1_3[0]) && !isNaN(v_1_3[1])) {
          items.push({
            type: "Feature",
            properties: {
              name: v_2_1,
              description: v_3_1
            },
            geometry: {
              type: "Point",
              coordinates: [v_1_3[0], v_1_3[1]]
            }
          });
        }
      }
    }
  }
  return {
    type: "FeatureCollection",
    features: items
  };
}
function parseCoordString(arg1) {
  if (!arg1) {
    return [];
  }
  const parts = arg1.trim().split(/\s+/);
  const items = [];
  for (let v_1 of parts) {
    const v_1_1 = v_1.split(",").map(Number);
    if (!isNaN(v_1_1[0]) && !isNaN(v_1_1[1])) {
      items.push([v_1_1[0], v_1_1[1]]);
    }
  }
  return items;
}
function renderIntersectingPaftasAnalysis(arg1) {
  const domEl = document.getElementById("cardIntersectingPaftas");
  const domEl_1 = document.getElementById("badgeIntersectingCount");
  const domEl_2 = document.getElementById("txtImportedFileName");
  const domEl_3 = document.getElementById("txtImportedFeatureCount");
  const domEl_4 = document.getElementById("listIntersectingPaftas");
  if (!domEl || !domEl_4) {
    return;
  }
  const v_2 = state.currentIntersectScale || "25k";
  const v_3 = v_2 === "25k" ? "1/25 000" : v_2 === "50k" ? "1/50 000" : "1/100 000";
  const v_4 = state.paftaEngine.getIntersectingSheets(arg1.bounds, v_2);
  domEl_2.textContent = "📁 " + arg1.fileName;
  domEl_3.textContent = arg1.featureCount + " Geometri";
  domEl_1.textContent = v_4.length + " Pafta";
  highlightIntersectingPaftas(v_4);
  domEl_4.innerHTML = "";
  if (v_4.length === 0) {
    domEl_4.innerHTML = "<div style=\"font-size: 11.5px; color: var(--text-dim); text-align: center; padding: 10px;\">Temas eden pafta bulunamadı.</div>";
  } else {
    v_4.forEach(item => {
      const v_1 = state.paftaEngine.getHgmDatumRecord(item.name, item.centerLat, item.centerLon);
      const v_2_1 = state.gnssEngine.geodesy.getAutoCentralMeridian3Deg(item.centerLon);
      const v_3_1 = item.regionalName ? " (" + item.regionalName + ")" : "";
      const divEl = document.createElement("div");
      divEl.className = "intersecting-sheet-card";
      divEl.innerHTML = "\n                <div style=\"display: flex; justify-content: space-between; align-items: center;\">\n                    <strong style=\"color: var(--cyan-400); font-family: var(--font-mono); font-size: 12.5px;\">" + item.name + " <span style=\"color: #f59e0b; font-weight: 700; font-size: 11px;\">" + v_3_1 + "</span></strong>\n                    <span style=\"font-size: 10px; color: var(--emerald-400); font-weight: 700; background: rgba(16, 185, 129, 0.15); padding: 1px 6px; border-radius: 4px;\">DOM " + v_2_1 + "°</span>\n                </div>\n                <div style=\"font-size: 10.5px; color: var(--text-dim); display: flex; justify-content: space-between;\">\n                    <span>Yükseklik Düz. (Δh): <strong style=\"color: #f59e0b;\">" + v_1.yukseklikDuz.toFixed(2) + " m</strong></span>\n                    <span>Yukarı (ΔX): <strong class=\"text-main\">" + v_1.yukariDuz.toFixed(1) + " m</strong></span>\n                </div>\n                <div style=\"display: flex; gap: 4px; margin-top: 2px;\">\n                    <button class=\"btn btn-secondary btn-sm\" style=\"flex: 1; padding: 2px 4px; font-size: 9.5px;\" onclick=\"event.stopPropagation(); window.downloadPaftaDirect('" + item.name + "', 'kml')\"><i class=\"fa-solid fa-earth-americas\"></i> KML</button>\n                    <button class=\"btn btn-secondary btn-sm\" style=\"flex: 1; padding: 2px 4px; font-size: 9.5px;\" onclick=\"event.stopPropagation(); window.downloadPaftaDirect('" + item.name + "', 'dxf')\"><i class=\"fa-solid fa-vector-square\"></i> DXF</button>\n                    <button class=\"btn btn-secondary btn-sm\" style=\"flex: 1; padding: 2px 4px; font-size: 9.5px;\" onclick=\"event.stopPropagation(); window.downloadPaftaDirect('" + item.name + "', 'json')\"><i class=\"fa-solid fa-code\"></i> JSON</button>\n                </div>\n            ";
      divEl.addEventListener("click", () => {
        const items = [[item.minLat, item.minLon], [item.maxLat, item.maxLon]];
        state.map.flyToBounds(items, {
          maxZoom: 14,
          padding: [60, 60]
        });
        highlightSheet(item);
        showFloatingPaftaCard(item);
      });
      domEl_4.appendChild(divEl);
    });
  }
  state.currentIntersectingSheets = v_4;
  const btnEl = document.getElementById("btnDownloadAllIntersectingKml");
  if (btnEl) {
    btnEl.onclick = () => {
      if (!state.currentIntersectingSheets || state.currentIntersectingSheets.length === 0) {
        showToast("⚠️ İndirilecek temas eden pafta bulunamadı.", "warning");
        return;
      }
      const v_1 = state.paftaEngine.exportMultipleSheetsKml(state.currentIntersectingSheets, "Temas Eden Paftalar (" + (state.currentIntersectScale || "25k") + ")");
      const v_2_1 = "temas_eden_paftalar_" + (state.currentIntersectScale || "25k") + ".kml";
      downloadTextFile(v_2_1, v_1);
      showToast("💾 " + state.currentIntersectingSheets.length + " adet pafta sınırı " + v_2_1 + " olarak indirildi.", "success");
    };
  }
  domEl.style.display = "block";
}
function highlightIntersectingPaftas(arg1) {
  if (!state.intersectingPaftaLayerGroup) {
    return;
  }
  state.intersectingPaftaLayerGroup.clearLayers();
  arg1.forEach(item => {
    const items = [[item.minLat, item.minLon], [item.maxLat, item.maxLon]];
    L.rectangle(items, {
      color: "#f59e0b",
      weight: 2.2,
      dashArray: "5, 5",
      fillColor: "#f59e0b",
      fillOpacity: 0.12
    }).addTo(state.intersectingPaftaLayerGroup);
  });
}
function renderPaftaGrid() {
  if (!state.map || !state.paftaLayerGroup || state.activePaftaScale === "off") {
    return;
  }
  state.paftaLayerGroup.clearLayers();
  const v_1 = state.map.getBounds();
  const v_2 = v_1.getSouth();
  const v_3 = v_1.getWest();
  const v_4 = v_1.getNorth();
  const v_5 = v_1.getEast();
  const v_6 = state.map.getZoom();
  if (state.activePaftaScale === "25k" && v_6 < 9) {
    const v_1_1 = state.paftaEngine.getVisibleSheets(v_2, v_3, v_4, v_5, "100k");
    v_1_1.forEach(item => {
      L.rectangle([[item.minLat, item.minLon], [item.maxLat, item.maxLon]], {
        color: "#10b981",
        weight: 1,
        fill: false,
        dashArray: "4, 4"
      }).addTo(state.paftaLayerGroup);
    });
    return;
  }
  const v_7 = state.paftaEngine.getVisibleSheets(v_2, v_3, v_4, v_5, state.activePaftaScale);
  v_7.forEach(item => {
    let str = "#06b6d4";
    let str_1 = "pafta-label-100k";
    let num = 1.6;
    let num_1 = 0.04;
    if (state.activePaftaScale === "50k") {
      str = "#a855f7";
      str_1 = "pafta-label-50k";
      num = 1.4;
      num_1 = 0.05;
    } else if (state.activePaftaScale === "25k") {
      str = "#10b981";
      str_1 = "pafta-label-25k";
      num = 1.2;
      num_1 = 0.06;
    }
    const v_1_1 = L.rectangle([[item.minLat, item.minLon], [item.maxLat, item.maxLon]], {
      color: str,
      weight: num,
      fillColor: str,
      fillOpacity: num_1
    }).addTo(state.paftaLayerGroup);
    v_1_1.on("click", arg1 => {
      L.DomEvent.stopPropagation(arg1);
      highlightSheet(item);
      showFloatingPaftaCard(item);
    });
    v_1_1.on("mouseover", function () {
      this.setStyle({
        weight: num + 1.2,
        fillOpacity: num_1 + 0.15
      });
    });
    v_1_1.on("mouseout", function () {
      this.setStyle({
        weight: num,
        fillOpacity: num_1
      });
    });
    if (v_6 >= (state.activePaftaScale === "100k" ? 7 : state.activePaftaScale === "50k" ? 9 : 11)) {
      const v_1_2 = L.divIcon({
        className: str_1,
        html: item.name,
        iconSize: null
      });
      L.marker([item.centerLat, item.centerLon], {
        icon: v_1_2,
        interactive: false
      }).addTo(state.paftaLayerGroup);
    }
  });
}
function renderDomGrid() {
  if (!state.map || !state.domLayerGroup || !state.isDomLayerActive) {
    return;
  }
  state.domLayerGroup.clearLayers();
  const v_1 = state.paftaEngine.getTurkishDomZones();
  const num = 34.2;
  const num_1 = 42.6;
  v_1.forEach((item, idx) => {
    const v_1_1 = L.rectangle([[num, item.minLon], [num_1, item.maxLon]], {
      color: "#f59e0b",
      weight: 2,
      dashArray: "6, 6",
      fillColor: idx % 2 === 0 ? "#f59e0b" : "#fbbf24",
      fillOpacity: 0.04
    }).addTo(state.domLayerGroup);
    const v_2 = L.divIcon({
      className: "",
      html: "<div class=\"dom-label-badge\" title=\"" + item.name + " (" + item.minLon + "° - " + item.maxLon + "° E)\">📍 DOM " + item.dom + "°<br><span style=\"font-size: 8.5px; font-weight: 500; opacity: 0.85;\">Dilim " + item.zone + "</span></div>",
      iconSize: null
    });
    const v_3 = L.divIcon({
      className: "",
      html: "<div class=\"dom-label-badge\" title=\"" + item.name + " (" + item.minLon + "° - " + item.maxLon + "° E)\">📍 DOM " + item.dom + "°<br><span style=\"font-size: 8.5px; font-weight: 500; opacity: 0.85;\">Dilim " + item.zone + "</span></div>",
      iconSize: null
    });
    const v_4 = L.marker([41.9, item.dom], {
      icon: v_2
    }).addTo(state.domLayerGroup);
    const v_5 = L.marker([35.8, item.dom], {
      icon: v_3
    }).addTo(state.domLayerGroup);
    const v_6 = "\n            <div style=\"font-family: var(--font-body); font-size: 12px; line-height: 1.5; color: #000; min-width: 250px;\">\n                <div style=\"font-size: 13.5px; font-weight: 800; color: #d97706; border-bottom: 2px solid #f59e0b; padding-bottom: 3px; margin-bottom: 6px;\">\n                    🌐 TUREF TM 3° - DOM " + item.dom + "° (Dilim " + item.zone + ")\n                </div>\n                <div style=\"margin-bottom: 4px;\"><strong>Dilim Orta Meridyeni:</strong> " + item.dom + "° 00' 00\" E</div>\n                <div style=\"margin-bottom: 4px;\"><strong>Boylam Kapsamı (3°):</strong> " + item.minLon + "° - " + item.maxLon + "° E (" + (item.dom - 1.5) + "° - " + (item.dom + 1.5) + "°)</div>\n                <div style=\"margin-bottom: 4px;\"><strong>TUREF / ITRF-96:</strong> <span style=\"font-family: monospace; font-weight: bold; color: #0284c7;\">" + item.epsg + "</span></div>\n                <div style=\"margin-bottom: 4px;\"><strong>ED-50:</strong> <span style=\"font-family: monospace; font-weight: bold; color: #7c3aed;\">" + item.epsgEd50 + "</span></div>\n                <div style=\"margin-top: 6px; font-size: 11px; color: #475569; background: #fef3c7; padding: 5px 8px; border-radius: 4px; border-left: 3px solid #f59e0b;\">\n                    <strong>Kapsadığı Bölgeler:</strong> " + item.desc + "\n                </div>\n            </div>\n        ";
    v_1_1.bindPopup(v_6);
    v_4.bindPopup(v_6);
    v_5.bindPopup(v_6);
  });
}
function highlightSheet(arg1) {
  if (!state.map) {
    return;
  }
  if (state.highlightedPaftaLayer) {
    state.map.removeLayer(state.highlightedPaftaLayer);
  }
  state.selectedPaftaSheet = arg1;
  state.highlightedPaftaLayer = L.rectangle([[arg1.minLat, arg1.minLon], [arg1.maxLat, arg1.maxLon]], {
    color: "#f59e0b",
    weight: 3.5,
    fillColor: "#f59e0b",
    fillOpacity: 0.18,
    dashArray: "2, 6"
  }).addTo(state.map);
}
function showFloatingPaftaCard(arg1, arg2) {
  state.selectedPaftaSheet = arg1;
  const domEl = document.getElementById("cardActivePafta");
  if (!domEl) {
    return;
  }
  const v_3 = state.gnssEngine.geodesy.getAutoCentralMeridian3Deg(arg1.centerLon);
  const v_4 = v_3 / 3 + 0;
  const v_5 = arg1.regionalName || "";
  document.getElementById("txtPaftaCardTitle").textContent = arg1.name;
  document.getElementById("txtPaftaCardScale").textContent = arg1.scale;
  document.getElementById("txtPaftaCardLat").textContent = arg1.centerLat.toFixed(5) + "° N";
  document.getElementById("txtPaftaCardLon").textContent = arg1.centerLon.toFixed(5) + "° E";
  document.getElementById("txtPaftaCardDom").textContent = "DOM " + v_3 + "° (Dilim " + v_4 + ")";

  const elTg20N = document.getElementById("txtPaftaCardTg20N");
  if (elTg20N && state.tg20Engine) {
    const nVal = state.tg20Engine.getGeoidHeight(arg1.centerLat, arg1.centerLon);
    elTg20N.textContent = nVal !== null ? (nVal >= 0 ? "+" : "") + nVal.toFixed(3) + " m" : "Kapsam Dışı";
  }

  let allSheetsObj = arg2;
  if (!allSheetsObj) {
    allSheetsObj = state.paftaEngine.getAllSheetsForPoint(arg1.centerLat, arg1.centerLon);
  }

  const el100k = document.getElementById("txtPaftaCard100k");
  const el50k = document.getElementById("txtPaftaCard50k");
  const el25k = document.getElementById("txtPaftaCard25k");

  if (el100k && allSheetsObj.s100k) {
    el100k.textContent = allSheetsObj.s100k.name;
    el100k.style.cursor = "pointer";
    el100k.title = "1/100 000 ölçekli " + allSheetsObj.s100k.name + " paftasını seç ve vurgula";
    el100k.onclick = () => {
      state.activePaftaScale = "100k";
      state.currentIntersectScale = "100k";
      highlightSheet(allSheetsObj.s100k);
      showFloatingPaftaCard(allSheetsObj.s100k, allSheetsObj);
    };
  }

  if (el50k && allSheetsObj.s50k) {
    el50k.textContent = allSheetsObj.s50k.name;
    el50k.style.cursor = "pointer";
    el50k.title = "1/50 000 ölçekli " + allSheetsObj.s50k.name + " paftasını seç ve vurgula";
    el50k.onclick = () => {
      state.activePaftaScale = "50k";
      state.currentIntersectScale = "50k";
      highlightSheet(allSheetsObj.s50k);
      showFloatingPaftaCard(allSheetsObj.s50k, allSheetsObj);
    };
  }

  if (el25k && allSheetsObj.s25k) {
    el25k.textContent = allSheetsObj.s25k.name;
    el25k.style.cursor = "pointer";
    el25k.title = "1/25 000 ölçekli " + allSheetsObj.s25k.name + " paftasını seç ve vurgula";
    el25k.onclick = () => {
      state.activePaftaScale = "25k";
      state.currentIntersectScale = "25k";
      highlightSheet(allSheetsObj.s25k);
      showFloatingPaftaCard(allSheetsObj.s25k, allSheetsObj);
    };
  }

  const v_6 = allSheetsObj.s25k || arg1;
  const v_7 = v_6 ? v_6.name : arg1.name;
  const v_8 = v_6 && v_6.datumCorr ? v_6.datumCorr : state.paftaEngine.getHgmDatumRecord(v_7, arg1.centerLat, arg1.centerLon);
  const domEl_1 = document.getElementById("txtHgmYukseklik");
  if (domEl_1) {
    domEl_1.textContent = v_8.yukseklikDuz.toFixed(2) + " m";
  }
  const domEl_2 = document.getElementById("txtHgmYukari");
  if (domEl_2) {
    domEl_2.textContent = v_8.yukariDuz.toFixed(1) + " m";
  }
  const domEl_3 = document.getElementById("txtHgmSaga");
  if (domEl_3) {
    domEl_3.textContent = v_8.sagaDuz.toFixed(1) + " m";
  }
  const domEl_4 = document.getElementById("txtHgmEnlem");
  if (domEl_4) {
    domEl_4.textContent = v_8.enlemDuz.toFixed(2) + "\"";
  }
  const domEl_5 = document.getElementById("txtHgmBoylam");
  if (domEl_5) {
    domEl_5.textContent = v_8.boylamDuz.toFixed(2) + "\"";
  }
  const domEl_6 = document.getElementById("txtHgmSourceLabel");
  if (domEl_6) {
    domEl_6.textContent = v_8.isOfficial ? "Resmi HGM DB" : "Hesaplanan";
    domEl_6.style.color = v_8.isOfficial ? "var(--emerald-400)" : "var(--amber-400)";
  }
  const domEl_7 = document.getElementById("txtPaftaCardRegion");
  if (domEl_7) {
    domEl_7.textContent = v_5 ? "Pafta Adı: " + v_5 : "";
    domEl_7.style.display = v_5 ? "block" : "none";
  }
  domEl.style.display = "block";
}
function initCadastreMap() {
  if (state.cadastreMap) {
    state.cadastreMap.invalidateSize();
    return;
  }
  const {
    baseMaps: v_1,
    defaultLayer: v_2
  } = createBaseLayers();
  state.cadastreMap = L.map("cadastreMapContainer", {
    center: [37.33, 28.45],
    zoom: 13,
    layers: [v_2]
  });
  L.control.layers(v_1, null, {
    position: "topright"
  }).addTo(state.cadastreMap);
  state.cadastreLayerGroup = L.layerGroup().addTo(state.cadastreMap);
  plotCadastrePointsOnMap();
  elements.btnFitCadastreMap.addEventListener("click", () => {
    if (state.cadastreLayerGroup && state.cadastreLayerGroup.getLayers().length > 0) {
      const v_1_1 = L.featureGroup(state.cadastreLayerGroup.getLayers()).getBounds();
      state.cadastreMap.fitBounds(v_1_1, {
        padding: [40, 40]
      });
    }
  });
}
function plotCadastrePointsOnMap() {
  if (!state.cadastreMap || !state.cadastreLayerGroup) {
    return;
  }
  state.cadastreLayerGroup.clearLayers();
  const v_1 = state.gnssEngine.rawPoints;
  if (v_1.length === 0) {
    return;
  }
  const items = [];
  v_1.forEach(item => {
    let lat = item.lat ?? item.latDec;
    let lon = item.lon ?? item.lonDec;
    if ((lat === undefined || lon === undefined) && state.geodesyEngine && item.e && item.n) {
      try {
        const geo = state.geodesyEngine.inverseTM(item.e, item.n, state.gnssEngine.centralMeridian, 1.0, false);
        lat = geo.lat;
        lon = geo.lon;
      } catch (e) {}
    }
    if (lat !== undefined && lon !== undefined) {
      items.push([lat, lon]);
      const v_1_1 = L.circleMarker([lat, lon], {
        radius: 6,
        fillColor: "#38bdf8",
        color: "#ffffff",
        weight: 2,
        opacity: 1,
        fillOpacity: 0.9
      }).addTo(state.cadastreLayerGroup);
      v_1_1.bindTooltip("<b>" + item.pn + "</b>", {
        permanent: true,
        direction: "top",
        className: "map-point-label"
      });
      const orthoH = item.orthoH !== undefined ? item.orthoH : item.h - 34.455;
      v_1_1.bindPopup(`
        <div style="font-family: sans-serif; font-size: 12px; line-height: 1.5;">
            <b style="color: #0284c7; font-size: 14px;">📍 Nokta: ${item.pn}</b><br>
            <strong>Sağa (Y):</strong> ${item.e.toFixed(3)} m<br>
            <strong>Yukarı (X):</strong> ${item.n.toFixed(3)} m<br>
            <strong>Kot (h):</strong> ${item.h.toFixed(3)} m (H≈${orthoH.toFixed(3)}m)<br>
            <strong>Enlem (Lat):</strong> ${lat.toFixed(8)}°<br>
            <strong>Boylam (Lon):</strong> ${lon.toFixed(8)}°<br>
            <strong>Tarih / Saat:</strong> ${item.dt} ${item.tm}<br>
            <strong>Yatay RMS:</strong> ${item.hsdvVal.toFixed(3)} m | <strong>PDOP:</strong> ${item.pdop}<br>
            <strong>Uydu:</strong> ${item.sats} | <strong>Durum:</strong> <span style="color: green; font-weight: bold;">${item.status}</span>
        </div>
      `);
    }
  });
  if (items.length > 0) {
    state.cadastreMap.fitBounds(L.latLngBounds(items), {
      padding: [40, 40]
    });
  }
}
function plotTrajectoryOnMap(arg1) {
  if (!state.map || !state.mapLayerGroup) {
    return;
  }
  state.mapLayerGroup.clearLayers();
  const v_2 = arg1.map(item => [item.lat, item.lon]);
  const v_3 = L.polyline(v_2, {
    color: "#06b6d4",
    weight: 4,
    opacity: 0.9
  }).addTo(state.mapLayerGroup);
  const v_4 = arg1[0];
  const v_5 = L.marker([v_4.lat, v_4.lon]).addTo(state.mapLayerGroup);
  v_5.bindPopup("<b>GNSS İstasyon Konumu</b><br>Enlem: " + v_4.lat.toFixed(8) + "°<br>Boylam: " + v_4.lon.toFixed(8) + "°<br>Yükseklik: " + v_4.h.toFixed(3) + " m<br>Epoch: " + arg1.length).openPopup();
  state.map.fitBounds(v_3.getBounds(), {
    padding: [40, 40]
  });
}
function exportKml() {
  // 1. Durum: Ekranda seçili/vurgulanmış bir Pafta varsa
  if (state.selectedPaftaSheet) {
    const kmlContent = state.paftaEngine.exportSingleSheetKml(state.selectedPaftaSheet);
    const fileName = `${state.selectedPaftaSheet.name}_pafta_siniri.kml`;
    downloadTextFile(fileName, kmlContent);
    showToast(`💾 ${fileName} Google Earth dosyası indirildi.`, "success");
    return;
  }

  // 2. Durum: Temas eden pafta listesi varsa
  if (state.currentIntersectingSheets && state.currentIntersectingSheets.length > 0) {
    const scaleLabel = state.currentIntersectScale || "25k";
    const kmlContent = state.paftaEngine.exportMultipleSheetsKml(state.currentIntersectingSheets, `Temas Eden Paftalar (${scaleLabel})`);
    const fileName = `temas_eden_paftalar_${scaleLabel}.kml`;
    downloadTextFile(fileName, kmlContent);
    showToast(`💾 ${fileName} (${state.currentIntersectingSheets.length} Pafta) indirildi.`, "success");
    return;
  }

  // 3. Durum: İçe aktarılmış proje geometrisi varsa
  if (state.importedProjectData && state.importedProjectData.geojson) {
    const fileName = `${(state.importedProjectData.fileName || "proje").replace(/\.[^/.]+$/, "")}_export.kml`;
    let str = '<?xml version="1.0" encoding="UTF-8"?>\n<kml xmlns="http://www.opengis.net/kml/2.2">\n<Document>\n<name>' + fileName + '</name>\n';
    const feats = state.importedProjectData.geojson.features || [];
    for (let f of feats) {
      const pName = f.properties?.name || "Geometri";
      if (f.geometry?.type === "Point") {
        const c = f.geometry.coordinates;
        str += `<Placemark><name>${pName}</name><Point><coordinates>${c[0]},${c[1]},${c[2] || 0}</coordinates></Point></Placemark>\n`;
      } else if (f.geometry?.type === "Polygon") {
        const coords = f.geometry.coordinates[0].map(pt => `${pt[0]},${pt[1]},${pt[2] || 0}`).join(" ");
        str += `<Placemark><name>${pName}</name><Polygon><outerBoundaryIs><LinearRing><coordinates>${coords}</coordinates></LinearRing></outerBoundaryIs></Polygon></Placemark>\n`;
      } else if (f.geometry?.type === "LineString") {
        const coords = f.geometry.coordinates.map(pt => `${pt[0]},${pt[1]},${pt[2] || 0}`).join(" ");
        str += `<Placemark><name>${pName}</name><LineString><coordinates>${coords}</coordinates></LineString></Placemark>\n`;
      }
    }
    str += '</Document>\n</kml>';
    downloadTextFile(fileName, str);
    showToast(`💾 ${fileName} Google Earth dosyası indirildi.`, "success");
    return;
  }

  // 4. Durum: Kadastro noktaları veya GNSS ölçüm çözümleri
  const points = (state.cadastrePoints && state.cadastrePoints.length > 0)
    ? state.cadastrePoints
    : (state.activePoints && state.activePoints.length > 0 ? state.activePoints : state.posSolutions || []);

  if (points.length === 0) {
    showToast("⚠️ Haritada dışa aktarılacak seçili pafta, içe aktarılmış KML veya nokta verisi bulunmuyor.", "warning");
    return;
  }

  let str = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<kml xmlns=\"http://www.opengis.net/kml/2.2\">\n<Document>\n<name>GNSS Noktaları & Rota</name>\n";
  for (let p of points) {
    const pName = p.name || p.id || p.pointId || "Nokta";
    const lon = p.lon ?? p.lng ?? p.longitude;
    const lat = p.lat ?? p.latitude;
    const h = p.h ?? p.height ?? p.elevation ?? p.ellipsoidalHeight ?? 0;
    if (lat !== undefined && lon !== undefined) {
      str += "<Placemark><name>" + pName + "</name><Point><coordinates>" + Number(lon).toFixed(8) + "," + Number(lat).toFixed(8) + "," + Number(h).toFixed(3) + "</coordinates></Point></Placemark>\n";
    }
  }
  str += "</Document>\n</kml>";
  downloadTextFile("gnss_points.kml", str);
  showToast("💾 gnss_points.kml Google Earth dosyası indirildi.", "success");
}

function exportGeoJson() {
  // 1. Durum: Ekranda seçili/vurgulanmış bir Pafta varsa
  if (state.selectedPaftaSheet) {
    const geoJsonContent = state.paftaEngine.exportSingleSheetGeoJson(state.selectedPaftaSheet);
    const fileName = `${state.selectedPaftaSheet.name}_pafta_siniri.geojson`;
    downloadTextFile(fileName, geoJsonContent);
    showToast(`💾 ${fileName} CBS GeoJSON dosyası indirildi.`, "success");
    return;
  }

  // 2. Durum: Temas eden pafta listesi varsa
  if (state.currentIntersectingSheets && state.currentIntersectingSheets.length > 0) {
    const scaleLabel = state.currentIntersectScale || "25k";
    const geoJsonContent = state.paftaEngine.exportMultipleSheetsGeoJson(state.currentIntersectingSheets);
    const fileName = `temas_eden_paftalar_${scaleLabel}.geojson`;
    downloadTextFile(fileName, geoJsonContent);
    showToast(`💾 ${fileName} (${state.currentIntersectingSheets.length} Pafta) indirildi.`, "success");
    return;
  }

  // 3. Durum: İçe aktarılmış proje geometrisi varsa
  if (state.importedProjectData && state.importedProjectData.geojson) {
    const fileName = `${(state.importedProjectData.fileName || "proje").replace(/\.[^/.]+$/, "")}_export.geojson`;
    downloadTextFile(fileName, JSON.stringify(state.importedProjectData.geojson, null, 2));
    showToast(`💾 ${fileName} GeoJSON dosyası indirildi.`, "success");
    return;
  }

  // 4. Durum: Kadastro noktaları veya GNSS ölçüm çözümleri
  const points = (state.cadastrePoints && state.cadastrePoints.length > 0)
    ? state.cadastrePoints
    : (state.activePoints && state.activePoints.length > 0 ? state.activePoints : state.posSolutions || []);

  if (points.length === 0) {
    showToast("⚠️ Haritada dışa aktarılacak seçili pafta, içe aktarılmış KML veya nokta verisi bulunmuyor.", "warning");
    return;
  }

  const features = points.map(item => {
    const lon = item.lon ?? item.lng ?? item.longitude;
    const lat = item.lat ?? item.latitude;
    const h = item.h ?? item.height ?? item.elevation ?? item.ellipsoidalHeight ?? 0;
    return {
      type: "Feature",
      properties: {
        name: item.name || item.id || item.pointId || "",
        code: item.code || item.description || "",
        height: h
      },
      geometry: {
        type: "Point",
        coordinates: [Number(lon), Number(lat), Number(h)]
      }
    };
  }).filter(item => !isNaN(item.geometry.coordinates[0]) && !isNaN(item.geometry.coordinates[1]));

  const obj = {
    type: "FeatureCollection",
    features: features
  };
  downloadTextFile("gnss_points.geojson", JSON.stringify(obj, null, 2));
  showToast("💾 gnss_points.geojson CBS dosyası indirildi.", "success");
}
function initGeodesy() {
  const v_1 = new GeodesyEngine();
  let items = [];
  const domEl = document.getElementById("selSourceEpsg");
  const domEl_1 = document.getElementById("selTargetEpsg");
  const domEl_10 = document.getElementById("selBatchSourceEpsg");
  const domEl_11 = document.getElementById("selBatchTargetEpsg");

  const populateAllEpsgSelects = () => {
    if (domEl) v_1.populateSelect(domEl, domEl.value || "EPSG:4326");
    if (domEl_1) v_1.populateSelect(domEl_1, domEl_1.value || "EPSG:5255");
    if (domEl_10) v_1.populateSelect(domEl_10, domEl_10.value || "EPSG:5255");
    if (domEl_11) v_1.populateSelect(domEl_11, domEl_11.value || "EPSG:4326");
  };
  populateAllEpsgSelects();
  window.refreshEpsgSelects = populateAllEpsgSelects;

  const btnEl = document.getElementById("btnSwapEpsg");
  const btnEl_1 = document.getElementById("btnConvertCoord");
  const btnEl_2 = document.getElementById("btnCopySingleCoordResult");
  const domEl_2 = document.getElementById("coordResultBox");
  const domEl_3 = document.getElementById("geoLat");
  const domEl_4 = document.getElementById("geoLon");
  const domEl_5 = document.getElementById("geoH");
  const inputEl = document.getElementById("lblInputC1");
  const inputEl_1 = document.getElementById("lblInputC2");
  const inputEl_2 = document.getElementById("lblInputC3");
  const domEl_6 = document.getElementById("crossDatumWarningBanner");
  const v_2 = () => {
    if (!domEl || !domEl_1 || !domEl_6) {
      return;
    }
    const v_1_1 = v_1.epsgRegistry[domEl.value] || v_1.epsgRegistry["EPSG:4326"];
    const v_2_1 = v_1.epsgRegistry[domEl_1.value] || v_1.epsgRegistry["EPSG:5255"];
    if (v_1_1.datum !== v_2_1.datum) {
      domEl_6.style.display = "block";
    } else {
      domEl_6.style.display = "none";
    }
  };
  const v_3 = () => {
    return {
      dx: parseFloat(document.getElementById("p_dx")?.value) || -84.1,
      dy: parseFloat(document.getElementById("p_dy")?.value) || -101.8,
      dz: parseFloat(document.getElementById("p_dz")?.value) || -129.7,
      rx: parseFloat(document.getElementById("p_rx")?.value) || 0,
      ry: parseFloat(document.getElementById("p_ry")?.value) || 0,
      rz: parseFloat(document.getElementById("p_rz")?.value) || 0,
      ds: parseFloat(document.getElementById("p_ds")?.value) || 0
    };
  };
  const btnEl_3 = document.getElementById("btnLoadBursaWolfSample");
  const domEl_7 = document.getElementById("txtBursaWolfCommonPoints");
  const btnEl_4 = document.getElementById("btnSolveBursaWolf");
  const domEl_8 = document.getElementById("lblBursaWolfM0");
  if (btnEl_3 && domEl_7) {
    btnEl_3.addEventListener("click", () => {
      domEl_7.value = "P1  4123450.000  2654320.000  4098760.000  4123365.900  2654218.200  4098630.300\nP2  4125600.000  2651200.000  4100100.000  4125515.800  2651098.300  4099970.200\nP3  4121200.000  2658900.000  4095400.000  4121116.100  2658798.100  4095270.400\nP4  4128900.000  2653400.000  4092100.000  4128815.950  2653298.150  4091970.350";
      showToast("🧪 Örnek 4 adet 3B ITRF & ED50 kontrol noktası yüklendi.", "info");
    });
  }
  if (btnEl_4 && domEl_7) {
    btnEl_4.addEventListener("click", () => {
      const v_1_1 = domEl_7.value.trim();
      if (!v_1_1) {
        showToast("Lütfen en az 3 adet 3B ortak kontrol noktası girin.", "warning");
        return;
      }
      const v_2_1 = v_1_1.split(/\r?\n/).map(item => item.trim()).filter(item => item.length > 0 && !item.startsWith("#") && !item.startsWith("//") && !item.startsWith(";"));
      const items_2 = [];
      v_2_1.forEach((item, idx) => {
        const parts = item.split(/[\s,;|\t]+/);
        if (parts.length >= 7) {
          const v_1_2 = parts[0];
          const v_2_2 = parseFloat(parts[1]);
          const v_3_1 = parseFloat(parts[2]);
          const v_4_1 = parseFloat(parts[3]);
          const v_5_1 = parseFloat(parts[4]);
          const v_6_1 = parseFloat(parts[5]);
          const v_7_1 = parseFloat(parts[6]);
          if (!isNaN(v_2_2) && !isNaN(v_3_1) && !isNaN(v_4_1) && !isNaN(v_5_1) && !isNaN(v_6_1) && !isNaN(v_7_1)) {
            items_2.push({
              name: v_1_2,
              x1: v_2_2,
              y1: v_3_1,
              z1: v_4_1,
              x2: v_5_1,
              y2: v_6_1,
              z2: v_7_1
            });
          }
        }
      });
      if (items_2.length < 3) {
        showToast("En az 3 geçerli 3B nokta gereklidir. (Okunan: " + items_2.length + ")", "warning");
        return;
      }
      try {
        const v_1_2 = v_1.solveBursaWolf7Param(items_2);
        if (document.getElementById("p_dx")) {
          document.getElementById("p_dx").value = v_1_2.dx.toFixed(3);
        }
        if (document.getElementById("p_dy")) {
          document.getElementById("p_dy").value = v_1_2.dy.toFixed(3);
        }
        if (document.getElementById("p_dz")) {
          document.getElementById("p_dz").value = v_1_2.dz.toFixed(3);
        }
        if (document.getElementById("p_rx")) {
          document.getElementById("p_rx").value = v_1_2.rx.toFixed(4);
        }
        if (document.getElementById("p_ry")) {
          document.getElementById("p_ry").value = v_1_2.ry.toFixed(4);
        }
        if (document.getElementById("p_rz")) {
          document.getElementById("p_rz").value = v_1_2.rz.toFixed(4);
        }
        if (document.getElementById("p_ds")) {
          document.getElementById("p_ds").value = v_1_2.ds.toFixed(3);
        }
        if (domEl_8) {
          domEl_8.innerHTML = "✅ m₀: <strong>" + (v_1_2.m0 * 100).toFixed(2) + " cm</strong> (" + v_1_2.pointCount + " Nokta)";
        }
        logMessage("🏛️ [7 PARAMETRE] dX: " + v_1_2.dx.toFixed(3) + " m, dY: " + v_1_2.dy.toFixed(3) + " m, dZ: " + v_1_2.dz.toFixed(3) + " m, rX: " + v_1_2.rx.toFixed(4) + "\", rY: " + v_1_2.ry.toFixed(4) + "\", rZ: " + v_1_2.rz.toFixed(4) + "\", dS: " + v_1_2.ds.toFixed(3) + " ppm, m0: " + (v_1_2.m0 * 100).toFixed(2) + " cm");
        showToast("✨ 7 Parametre hesaplandı ve aktif edildi! (m₀ = " + (v_1_2.m0 * 100).toFixed(2) + " cm)", "success");
      } catch (v_1_2) {
        logMessage("❌ [7 PARAMETRE HATA] " + v_1_2.message);
        showToast("❌ 7 Parametre hesabı başarısız: " + v_1_2.message, "error");
      }
    });
  }
  const v_4 = () => {
    if (!domEl) {
      return;
    }
    const v_1_1 = v_1.epsgRegistry[domEl.value] || v_1.epsgRegistry["EPSG:4326"];
    if (v_1_1.type === "GEO") {
      if (inputEl) {
        inputEl.textContent = "Enlem (Lat / Dec.Deg):";
      }
      if (inputEl_1) {
        inputEl_1.textContent = "Boylam (Lon / Dec.Deg):";
      }
      if (inputEl_2) {
        inputEl_2.textContent = "Elipsoit Kotu (h / m):";
      }
    } else if (v_1_1.type === "TM") {
      if (inputEl) {
        inputEl.textContent = "Sağa Değer (Y / Easting - m):";
      }
      if (inputEl_1) {
        inputEl_1.textContent = "Yukarı Değer (X / Northing - m):";
      }
      if (inputEl_2) {
        inputEl_2.textContent = "Kot / Yükseklik (h / Z - m):";
      }
    } else if (v_1_1.type === "ECEF") {
      if (inputEl) {
        inputEl.textContent = "Kartezyen X (m):";
      }
      if (inputEl_1) {
        inputEl_1.textContent = "Kartezyen Y (m):";
      }
      if (inputEl_2) {
        inputEl_2.textContent = "Kartezyen Z (m):";
      }
    }
    v_2();
  };
  if (domEl) {
    domEl.addEventListener("change", v_4);
    v_4();
  }
  if (domEl_1) {
    domEl_1.addEventListener("change", v_2);
  }
  if (btnEl) {
    btnEl.addEventListener("click", () => {
      const v_1_1 = domEl.value;
      domEl.value = domEl_1.value;
      domEl_1.value = v_1_1;
      v_4();
      v_5();
    });
  }
  const v_5 = () => {
    const v_1_1 = parseFloat(domEl_3.value);
    const v_2_1 = parseFloat(domEl_4.value);
    const v_3_1 = parseFloat(domEl_5.value) || 0;
    if (isNaN(v_1_1) || isNaN(v_2_1)) {
      showToast("Lütfen geçerli 1. ve 2. koordinat değerlerini girin.", "warning");
      return;
    }
    const v_4_1 = domEl.value;
    const v_5_1 = domEl_1.value;
    const v_6_1 = v_1.epsgRegistry[v_4_1] || v_1.epsgRegistry["EPSG:4326"];
    const v_7_1 = v_1.epsgRegistry[v_5_1] || v_1.epsgRegistry["EPSG:5255"];
    const v_8 = v_6_1.datum !== v_7_1.datum ? v_3() : null;
    const v_9 = v_1.transformCoordinate({
      c1: v_1_1,
      c2: v_2_1,
      c3: v_3_1
    }, v_4_1, v_5_1, v_8);
    let v_10 = "[KAYNAK SİSTEM]   : " + v_6_1.name + "\n" + ("[GİRİLEN DEĞER]   : C1 = " + v_1_1.toFixed(v_6_1.unit === "deg" ? 8 : 3) + ", C2 = " + v_2_1.toFixed(v_6_1.unit === "deg" ? 8 : 3) + ", Kot = " + v_3_1.toFixed(3) + "\n\n") + ("[HEDEF SİSTEM]    : " + v_7_1.name + "\n") + ("[DÖNÜŞÜM SONUCU]  : " + v_9.formattedResult + "\n");
    if (v_7_1.type === "TM") {
      const v_1_2 = v_7_1.lon0;
      v_10 += "[DİLİM BİLGİSİ]   : Dilim Orta Meridyeni (DOM) = " + v_1_2 + "° East (Zone " + (v_7_1.zone || "3°") + ")\n";
    }
    if (v_9.isCrossDatum) {
      v_10 += "[DATUM GEÇİŞİ]    : " + v_6_1.datum + " ➔ " + v_7_1.datum + " (7 Parametre Bursa-Wolf Uygulandı)\n";
    }
    v_10 += "[COĞRAFİ DEĞER]   : " + v_1.toDms(v_9.lat, true) + ", " + v_1.toDms(v_9.lon, false);
    lastSingleCoordResult = v_9;
    if (domEl_2) {
      domEl_2.textContent = v_10;
    }
    showToast("📐 Koordinat dönüşümü tamamlandı.", "success");
  };
  let lastSingleCoordResult = null;
  if (btnEl_1) {
    btnEl_1.addEventListener("click", v_5);
  }
  if (btnEl_2) {
    btnEl_2.addEventListener("click", () => {
      if (domEl_2) {
        navigator.clipboard.writeText(domEl_2.textContent);
        showToast("📋 Dönüşüm sonucu panoya kopyalandı.", "success");
      }
    });
  }
  document.getElementById("btnCopySingleTg20")?.addEventListener("click", () => {
    if (!lastSingleCoordResult) {
      showToast("Lütfen önce 'Hassas Dönüştür' butonuna basın.", "warning");
      return;
    }
    const txt = lastSingleCoordResult.lat.toFixed(8) + "  " + lastSingleCoordResult.lon.toFixed(8) + "  " + (lastSingleCoordResult.h || 0).toFixed(3);
    navigator.clipboard.writeText(txt);
    showToast("📋 TG-20 Formatında Kopyalandı (Enlem Boylam Kot):\n" + txt, "success");
  });
  document.getElementById("btnSendSingleToTg20")?.addEventListener("click", () => {
    if (!lastSingleCoordResult) {
      showToast("Lütfen önce 'Hassas Dönüştür' butonuna basın.", "warning");
      return;
    }
    const inLat = document.getElementById("inputTg20Lat");
    const inLon = document.getElementById("inputTg20Lon");
    const inH = document.getElementById("inputTg20H");
    if (inLat) inLat.value = lastSingleCoordResult.lat.toFixed(8);
    if (inLon) inLon.value = lastSingleCoordResult.lon.toFixed(8);
    if (inH) inH.value = (lastSingleCoordResult.h || 0).toFixed(3);
    const tabBtn = document.querySelector('[data-tab="tab-tg20"]');
    if (tabBtn) tabBtn.click();
    setTimeout(() => {
      document.getElementById("btnCalculateTg20Single")?.click();
    }, 150);
    showToast("🏔️ Nokta TG-20 Jeoid Modeline aktarıldı ve ortometrik kotu hesaplandı!", "success");
  });
  const inputEl_3 = document.getElementById("txtBatchInput");
  const inputEl_4 = document.getElementById("fileBatchInput");
  const domEl_9 = document.getElementById("selBatchDelimiter");
  const btnEl_5 = document.getElementById("btnSwapBatchEpsg");
  document.querySelectorAll(".btn-quick-epsg").forEach(item => {
    item.addEventListener("click", () => {
      const v_1_1 = item.getAttribute("data-src");
      const v_2_1 = item.getAttribute("data-tgt");
      if (domEl_10 && v_1_1) {
        domEl_10.value = v_1_1;
      }
      if (domEl_11 && v_2_1) {
        domEl_11.value = v_2_1;
      }
      showToast("⚡ Şablon Seçildi: " + item.textContent, "info");
    });
  });
  const btnEl_6 = document.getElementById("btnBatchTransform");
  const domEl_12 = document.getElementById("batchResultsWrapper");
  const domEl_13 = document.getElementById("tbodyBatchResults");
  const domEl_14 = document.getElementById("lblBatchSummary");
  const domEl_15 = document.getElementById("thBatchSrc1");
  const domEl_16 = document.getElementById("thBatchSrc2");
  const domEl_17 = document.getElementById("thBatchTgt1");
  const domEl_18 = document.getElementById("thBatchTgt2");
  const domEl_19 = document.getElementById("selCol1");
  const domEl_20 = document.getElementById("selCol2");
  const domEl_21 = document.getElementById("selCol3");
  const domEl_22 = document.getElementById("selCol4");
  if (btnEl_5 && domEl_10 && domEl_11) {
    btnEl_5.addEventListener("click", () => {
      const v_1_1 = domEl_10.value;
      domEl_10.value = domEl_11.value;
      domEl_11.value = v_1_1;
      showToast("🔄 Dosya Kaynak ve Hedef projeksiyonları değiştirildi.", "info");
    });
  }
  if (inputEl_4) {
    inputEl_4.addEventListener("change", async event => {
      const v_1_1 = event.target.files[0];
      if (v_1_1) {
        const v_1_2 = await v_1_1.text();
        if (inputEl_3) {
          inputEl_3.value = v_1_2;
        }
        showToast("📂 '" + v_1_1.name + "' içeriği yüklendi (" + (v_1_1.size / 1024).toFixed(1) + " KB).", "info");
      }
    });
  }
  if (btnEl_6) {
    btnEl_6.addEventListener("click", () => {
      const v_1_1 = inputEl_3?.value || "";
      if (!v_1_1.trim()) {
        showToast("Lütfen dönüştürülecek koordinat metnini yapıştırın veya dosya seçin.", "warning");
        return;
      }
      const v_2_1 = domEl_9?.value || "AUTO";
      const v_3_1 = v_1.parseBatchCoordinateText(v_1_1, v_2_1);
      if (v_3_1.rows.length === 0) {
        showToast("Geçerli koordinat satırı tespit edilemedi.", "warning");
        return;
      }
      const v_4_1 = domEl_19.value;
      const v_5_1 = domEl_20.value;
      const v_6_1 = domEl_21.value;
      const v_7_1 = domEl_22.value;
      const v_8 = domEl_10 ? domEl_10.value : domEl.value;
      const v_9 = domEl_11 ? domEl_11.value : domEl_1.value;
      const v_10 = v_1.epsgRegistry[v_8] || v_1.epsgRegistry["EPSG:5255"];
      const v_11 = v_1.epsgRegistry[v_9] || v_1.epsgRegistry["EPSG:4326"];
      const v_12 = v_10.datum !== v_11.datum ? v_3() : null;
      if (domEl_15) {
        domEl_15.textContent = "Kaynak 1 (" + (v_10.type === "GEO" ? "Enlem/Lat" : v_10.type === "ECEF" ? "X" : "Y-Sağa") + ")";
      }
      if (domEl_16) {
        domEl_16.textContent = "Kaynak 2 (" + (v_10.type === "GEO" ? "Boylam/Lon" : v_10.type === "ECEF" ? "Y" : "X-Yukarı") + ")";
      }
      if (domEl_17) {
        domEl_17.textContent = "Dönüşen 1 (" + (v_11.type === "GEO" ? "Enlem/Lat" : v_11.type === "ECEF" ? "X" : "Y-Sağa") + ")";
      }
      if (domEl_18) {
        domEl_18.textContent = "Dönüşen 2 (" + (v_11.type === "GEO" ? "Boylam/Lon" : v_11.type === "ECEF" ? "Y" : "X-Yukarı") + ")";
      }
      items = [];
      if (domEl_13) {
        domEl_13.innerHTML = "";
      }
      v_3_1.rows.forEach((item, idx) => {
        let v_1_2 = "P" + (idx + 1);
        let num = 0;
        let num_1 = 0;
        let num_2 = 0;
        let str = "";
        const v_2_2 = (arg1, arg2) => {
          const v_3_2 = item[arg2] || "";
          if (arg1 === "PN") {
            v_1_2 = v_3_2 || "P" + (idx + 1);
          } else if (arg1 === "C1") {
            num = parseFloat(v_3_2) || 0;
          } else if (arg1 === "C2") {
            num_1 = parseFloat(v_3_2) || 0;
          } else if (arg1 === "C3") {
            num_2 = parseFloat(v_3_2) || 0;
          } else if (arg1 === "CODE") {
            str = v_3_2;
          }
        };
        v_2_2(v_4_1, 0);
        v_2_2(v_5_1, 1);
        v_2_2(v_6_1, 2);
        v_2_2(v_7_1, 3);
        if (num !== 0 || num_1 !== 0) {
          const v_1_3 = v_1.transformCoordinate({
            c1: num,
            c2: num_1,
            c3: num_2
          }, v_8, v_9, v_12);
          const obj = {
            index: idx + 1,
            pn: v_1_2,
            srcC1: num,
            srcC2: num_1,
            srcC3: num_2,
            tgtC1: v_1_3.c1,
            tgtC2: v_1_3.c2,
            tgtC3: v_1_3.c3,
            lat: v_1_3.lat,
            lon: v_1_3.lon,
            h: v_1_3.h,
            code: str
          };
          items.push(obj);
          if (domEl_13) {
            const trEl = document.createElement("tr");
            const v_1_4 = v_10.unit === "deg" ? 8 : 3;
            const v_2_3 = v_11.unit === "deg" ? 8 : 3;
            trEl.innerHTML = "\n                            <td style=\"font-family: var(--font-mono); color: var(--text-dim);\">" + (idx + 1) + "</td>\n                            <td><strong class=\"font-bold text-main\">" + v_1_2 + "</strong></td>\n                            <td style=\"font-family: var(--font-mono);\">" + num.toFixed(v_1_4) + "</td>\n                            <td style=\"font-family: var(--font-mono);\">" + num_1.toFixed(v_1_4) + "</td>\n                            <td style=\"font-family: var(--font-mono);\">" + num_2.toFixed(3) + "</td>\n                            <td style=\"font-family: var(--font-mono); font-weight: 700; color: var(--cyan-400);\">" + v_1_3.c1.toFixed(v_2_3) + "</td>\n                            <td style=\"font-family: var(--font-mono); font-weight: 700; color: var(--cyan-400);\">" + v_1_3.c2.toFixed(v_2_3) + "</td>\n                            <td style=\"font-family: var(--font-mono); color: var(--purple-400);\">" + v_1_3.c3.toFixed(3) + "</td>\n                        ";
            domEl_13.appendChild(trEl);
          }
        }
      });
      if (items.length > 0) {
        if (domEl_12) {
          domEl_12.style.display = "flex";
        }
        if (domEl_14) {
          domEl_14.innerHTML = "✨ <strong>" + items.length + "</strong> adet nokta dönüştürüldü [" + v_10.name.split("(")[0] + " ➔ " + v_11.name.split("(")[0] + "].";
        }
        showToast("✨ " + items.length + " nokta [" + v_8 + " ➔ " + v_9 + "] dönüştürüldü!", "success");
      }
    });
  }
  document.getElementById("btnExportBatchNcn")?.addEventListener("click", () => {
    if (items.length === 0) {
      return;
    }
    let str = "";
    items.forEach(item => {
      const v_1_1 = item.tgtC1.toFixed(3).padStart(12, " ");
      const v_2_1 = item.tgtC2.toFixed(3).padStart(12, " ");
      const v_3_1 = item.tgtC3.toFixed(3).padStart(9, " ");
      str += item.pn.padEnd(12, " ") + " " + v_1_1 + " " + v_2_1 + " " + v_3_1 + "\n";
    });
    downloadTextFile("donusturulen_noktalar.ncn", str);
    showToast("💾 donusturulen_noktalar.ncn indirildi.", "success");
  });
  document.getElementById("btnExportBatchDxf")?.addEventListener("click", () => {
    if (items.length === 0) {
      return;
    }
    let str = "0\nSECTION\n2\nENTITIES\n";
    items.forEach(item => {
      str += "0\nPOINT\n8\nNOKTALAR\n10\n" + item.tgtC1.toFixed(3) + "\n20\n" + item.tgtC2.toFixed(3) + "\n30\n" + item.tgtC3.toFixed(3) + "\n";
      str += "0\nTEXT\n8\nNOKTA_ADI\n10\n" + (item.tgtC1 + 0.5).toFixed(3) + "\n20\n" + (item.tgtC2 + 0.5).toFixed(3) + "\n30\n" + item.tgtC3.toFixed(3) + "\n40\n1.2\n1\n" + item.pn + "\n";
      str += "0\nTEXT\n8\nKOTLAR\n10\n" + (item.tgtC1 + 0.5).toFixed(3) + "\n20\n" + (item.tgtC2 - 1).toFixed(3) + "\n30\n" + item.tgtC3.toFixed(3) + "\n40\n0.9\n1\n" + item.tgtC3.toFixed(3) + "\n";
    });
    str += "0\nENDSEC\n0\nEOF\n";
    downloadTextFile("donusturulen_noktalar.dxf", str);
    showToast("💾 donusturulen_noktalar.dxf indirildi.", "success");
  });
  document.getElementById("btnExportBatchKml")?.addEventListener("click", () => {
    if (items.length === 0) {
      return;
    }
    let str = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<kml xmlns=\"http://www.opengis.net/kml/2.2\">\n<Document>\n<name>Donusturulen Noktalar</name>\n";
    items.forEach(item => {
      str += "<Placemark>\n<name>" + item.pn + "</name>\n<description>Y: " + item.tgtC1.toFixed(3) + ", X: " + item.tgtC2.toFixed(3) + ", Kot: " + item.tgtC3.toFixed(3) + "</description>\n<Point>\n<coordinates>" + item.lon.toFixed(8) + "," + item.lat.toFixed(8) + "," + item.h.toFixed(3) + "</coordinates>\n</Point>\n</Placemark>\n";
    });
    str += "</Document>\n</kml>";
    downloadTextFile("donusturulen_noktalar.kml", str);
    showToast("💾 donusturulen_noktalar.kml indirildi.", "success");
  });
  document.getElementById("btnExportBatchTxt")?.addEventListener("click", () => {
    if (items.length === 0) {
      return;
    }
    let str = "NOKTA_NO,DONUSEN_1,DONUSEN_2,KOT,ENLEM_WGS84,BOYLAM_WGS84\n";
    items.forEach(item => {
      str += item.pn + "," + item.tgtC1.toFixed(3) + "," + item.tgtC2.toFixed(3) + "," + item.tgtC3.toFixed(3) + "," + item.lat.toFixed(8) + "," + item.lon.toFixed(8) + "\n";
    });
    downloadTextFile("donusturulen_noktalar.csv", str);
    showToast("💾 donusturulen_noktalar.csv indirildi.", "success");
  });
  document.getElementById("btnCopyBatchTg20")?.addEventListener("click", () => {
    if (items.length === 0) {
      showToast("Dönüştürülmüş nokta listesi bulunamadı.", "warning");
      return;
    }
    let txt = "";
    items.forEach(item => {
      txt += item.pn + "  " + item.lat.toFixed(8) + "  " + item.lon.toFixed(8) + "  " + (item.h || 0).toFixed(3) + "\n";
    });
    navigator.clipboard.writeText(txt.trim());
    showToast("📋 " + items.length + " nokta TG-20 formatında kopyalandı (NoktaNo Enlem Boylam Kot).", "success");
  });
  document.getElementById("btnSendBatchToTg20")?.addEventListener("click", () => {
    if (items.length === 0) {
      showToast("Dönüştürülmüş nokta listesi bulunamadı.", "warning");
      return;
    }
    let txt = "";
    items.forEach(item => {
      txt += item.pn + "  " + item.lat.toFixed(8) + "  " + item.lon.toFixed(8) + "  " + (item.h || 0).toFixed(3) + "\n";
    });
    const batchInput = document.getElementById("txtTg20BatchInput");
    if (batchInput) {
      batchInput.value = txt.trim();
    }
    const tabBtn = document.querySelector('[data-tab="tab-tg20"]');
    if (tabBtn) tabBtn.click();
    setTimeout(() => {
      document.getElementById("btnProcessTg20Batch")?.click();
    }, 200);
    showToast("✨ " + items.length + " nokta TG-20 sekmesine aktarıldı ve ortometrik kot hesabı yapıldı!", "success");
  });
  let v_6 = null;
  let items_1 = [];
  const btnEl_7 = document.getElementById("btnTabHelmertDns");
  const btnEl_8 = document.getElementById("btnTabHelmertPoints");
  const domEl_23 = document.getElementById("paneHelmertDns");
  const domEl_24 = document.getElementById("paneHelmertPoints");
  btnEl_7?.addEventListener("click", () => {
    btnEl_7.classList.add("btn-primary");
    btnEl_7.classList.remove("btn-secondary");
    btnEl_8.classList.add("btn-secondary");
    btnEl_8.classList.remove("btn-primary");
    if (domEl_23) {
      domEl_23.classList.remove("d-none");
      domEl_23.style.setProperty("display", "flex", "important");
    }
    if (domEl_24) {
      domEl_24.classList.add("d-none");
      domEl_24.style.setProperty("display", "none", "important");
    }
  });
  btnEl_8?.addEventListener("click", () => {
    btnEl_8.classList.add("btn-primary");
    btnEl_8.classList.remove("btn-secondary");
    btnEl_7.classList.add("btn-secondary");
    btnEl_7.classList.remove("btn-primary");
    if (domEl_24) {
      domEl_24.classList.remove("d-none");
      domEl_24.style.setProperty("display", "flex", "important");
    }
    if (domEl_23) {
      domEl_23.classList.add("d-none");
      domEl_23.style.setProperty("display", "none", "important");
    }
  });
  const inputEl_5 = document.getElementById("inputHelmertDnsFile");
  const domEl_25 = document.getElementById("txtHelmertDnsFileName");
  const domEl_26 = document.getElementById("txtHelmertDnsContent");
  const btnEl_9 = document.getElementById("btnApplyDnsParams");
  inputEl_5?.addEventListener("change", async arg1 => {
    const v_2_1 = arg1.target.files?.[0];
    if (v_2_1) {
      const v_1_1 = await v_2_1.text();
      if (domEl_26) {
        domEl_26.value = v_1_1;
      }
      if (domEl_25) {
        domEl_25.innerHTML = "<span style=\"color: var(--cyan-400); font-weight:700;\">" + v_2_1.name + "</span> <span class=\"badge\" style=\"font-size:10px;\">DNS Dosyası</span>";
      }
      v_7(v_1_1, v_2_1.name);
    }
  });
  function v_7(arg1, arg2 = "DNS Dosyası") {
    if (!arg1 || !arg1.trim()) {
      showToast("⚠️ Lütfen geçerli bir .DNS dosya içeriği girin.", "warning");
      return;
    }
    try {
      const v_1_1 = v_1.parseNetcadDns(arg1);
      v_6 = v_1_1;
      document.getElementById("resHelmertA").textContent = v_1_1.a.toFixed(8);
      document.getElementById("resHelmertB").textContent = v_1_1.b.toFixed(8);
      document.getElementById("resHelmertDy").textContent = v_1_1.dy0.toFixed(3) + " m";
      document.getElementById("resHelmertDx").textContent = v_1_1.dx0.toFixed(3) + " m";
      document.getElementById("resHelmertScale").textContent = v_1_1.scale_m.toFixed(8) + " (" + (v_1_1.dm_ppm > 0 ? "+" : "") + v_1_1.dm_ppm.toFixed(1) + " ppm)";
      document.getElementById("resHelmertTheta").textContent = v_1_1.theta_grad.toFixed(6) + " grad (" + v_1_1.theta_deg.toFixed(4) + "°)";
      document.getElementById("badgeHelmertM0").textContent = "Netcad .DNS Parametreleri";
      const domEl_33 = document.getElementById("lblHelmertStatusSource");
      if (domEl_33) {
        domEl_33.innerHTML = "<i class=\"fa-solid fa-file-lines\" style=\"color: var(--cyan-400);\"></i> " + arg2 + " Aktif Edildi";
      }
      const domEl_34 = document.getElementById("wrapperHelmertResiduals");
      if (domEl_34) {
        domEl_34.style.display = "none";
      }
      if (domEl_29) {
        domEl_29.style.display = "flex";
      }
      logMessage("📄 [DNS YÜKLENDİ] Netcad .DNS parametreleri başarıyla yüklendi (a=" + v_1_1.a.toFixed(6) + ", b=" + v_1_1.b.toFixed(6) + ", dy=" + v_1_1.dy0.toFixed(2) + ", dx=" + v_1_1.dx0.toFixed(2) + ")");
      showToast("✨ Netcad .DNS parametreleri aktif edildi! Şimdi noktalarınızı dönüştürebilirsiniz.", "success");
    } catch (v_1_1) {
      logMessage("❌ [DNS HATA] " + (v_1_1.message || v_1_1));
      showToast("❌ DNS dosyası okunamadı: " + v_1_1.message, "error");
    }
  }
  btnEl_9?.addEventListener("click", () => {
    v_7(domEl_26?.value, "Netcad .DNS Metni");
  });
  const btnEl_10 = document.getElementById("btnLoadHelmertSample");
  const btnEl_11 = document.getElementById("btnSolveHelmert");
  const btnEl_12 = document.getElementById("btnTransformHelmertPoints");
  const domEl_27 = document.getElementById("txtHelmertCommonPoints");
  const domEl_28 = document.getElementById("txtHelmertPointsToTransform");
  const domEl_29 = document.getElementById("helmertResultsWrapper");
  const domEl_30 = document.getElementById("tbodyHelmertResiduals");
  const domEl_31 = document.getElementById("wrapperHelmertTransformedPoints");
  const domEl_32 = document.getElementById("tbodyHelmertTransformed");
  btnEl_10?.addEventListener("click", () => {
    if (domEl_27) {
      domEl_27.value = "P1  500120.000  4520100.000  500122.500  4520104.200\nP2  501240.000  4520150.000  501242.600  4520154.100\nP3  501260.000  4521200.000  501262.400  4521204.300\nP4  500150.000  4521180.000  500152.700  4521184.000";
    }
    if (domEl_28) {
      domEl_28.value = "101  500500.000  4520500.000  125.400\n102  500650.000  4520750.000  128.200\n103  500800.000  4520900.000  131.050\n104  500950.000  4521050.000  133.800";
    }
    showToast("🧪 Örnek 4 adet ortak kontrol noktası yüklendi.", "info");
  });
  btnEl_11?.addEventListener("click", () => {
    const v_1_1 = domEl_27?.value.trim();
    if (!v_1_1) {
      showToast("⚠️ Lütfen en az 2 ortak kontrol noktası girin.", "warning");
      return;
    }
    const v_2_1 = v_1_1.split(/\r?\n/).map(item => item.trim()).filter(item => item.length > 0);
    const items_2 = [];
    v_2_1.forEach(item => {
      const v_1_2 = item.split(/[\s,;\t]+/).filter(Boolean);
      if (v_1_2.length >= 5) {
        const v_1_3 = v_1_2[0];
        const v_2_2 = parseFloat(v_1_2[1]);
        const v_3_1 = parseFloat(v_1_2[2]);
        const v_4_1 = parseFloat(v_1_2[3]);
        const v_5_1 = parseFloat(v_1_2[4]);
        if (!isNaN(v_2_2) && !isNaN(v_3_1) && !isNaN(v_4_1) && !isNaN(v_5_1)) {
          items_2.push({
            name: v_1_3,
            y1: v_2_2,
            x1: v_3_1,
            y2: v_4_1,
            x2: v_5_1
          });
        }
      }
    });
    if (items_2.length < 2) {
      showToast("⚠️ Geçerli ortak nokta sayısı yetersiz (en az 2 ortak nokta gereklidir).", "error");
      return;
    }
    try {
      const v_1_2 = v_1.solveHelmert2D(items_2);
      v_6 = v_1_2;
      document.getElementById("resHelmertA").textContent = v_1_2.a.toFixed(8);
      document.getElementById("resHelmertB").textContent = v_1_2.b.toFixed(8);
      document.getElementById("resHelmertDy").textContent = v_1_2.dy0.toFixed(3) + " m";
      document.getElementById("resHelmertDx").textContent = v_1_2.dx0.toFixed(3) + " m";
      document.getElementById("resHelmertScale").textContent = v_1_2.scale_m.toFixed(8) + " (" + (v_1_2.dm_ppm > 0 ? "+" : "") + v_1_2.dm_ppm.toFixed(1) + " ppm)";
      document.getElementById("resHelmertTheta").textContent = v_1_2.theta_grad.toFixed(6) + " grad (" + v_1_2.theta_deg.toFixed(4) + "°)";
      document.getElementById("badgeHelmertM0").textContent = "m0 = " + (v_1_2.m0 * 100).toFixed(2) + " cm (" + v_1_2.m0.toFixed(4) + " m)";
      const domEl_33 = document.getElementById("lblHelmertStatusSource");
      if (domEl_33) {
        domEl_33.innerHTML = "<i class=\"fa-solid fa-list-check\" style=\"color: var(--emerald-400);\"></i> Ortak Kontrol Noktalarından Hesaplandı (" + items_2.length + " Nokta)";
      }
      const domEl_34 = document.getElementById("wrapperHelmertResiduals");
      if (domEl_34) {
        domEl_34.style.display = "block";
      }
      if (domEl_30) {
        domEl_30.innerHTML = "";
        v_1_2.residuals.forEach(item => {
          const trEl = document.createElement("tr");
          const v_1_3 = (item.vy * 100).toFixed(2);
          const v_2_2 = (item.vx * 100).toFixed(2);
          const v_3_1 = (item.vs * 100).toFixed(2);
          trEl.innerHTML = "\n                        <td><strong>" + item.name + "</strong></td>\n                        <td style=\"font-family: var(--font-mono);\">" + item.y1.toFixed(3) + "</td>\n                        <td style=\"font-family: var(--font-mono);\">" + item.x1.toFixed(3) + "</td>\n                        <td style=\"font-family: var(--font-mono);\">" + item.y2.toFixed(3) + "</td>\n                        <td style=\"font-family: var(--font-mono);\">" + item.x2.toFixed(3) + "</td>\n                        <td style=\"font-family: var(--font-mono); color: var(--cyan-400);\">" + item.calc_y2.toFixed(3) + "</td>\n                        <td style=\"font-family: var(--font-mono); color: var(--cyan-400);\">" + item.calc_x2.toFixed(3) + "</td>\n                        <td style=\"font-family: var(--font-mono); color: " + (item.vy >= 0 ? "#34d399" : "#f87171") + ";\">" + (item.vy >= 0 ? "+" : "") + v_1_3 + "</td>\n                        <td style=\"font-family: var(--font-mono); color: " + (item.vx >= 0 ? "#34d399" : "#f87171") + ";\">" + (item.vx >= 0 ? "+" : "") + v_2_2 + "</td>\n                        <td style=\"font-family: var(--font-mono); font-weight: 700; color: #fef08a;\">" + v_3_1 + "</td>\n                    ";
          domEl_30.appendChild(trEl);
        });
      }
      if (domEl_29) {
        domEl_29.style.display = "flex";
      }
      logMessage("📐 [HELMERT 2D] " + items_2.length + " ortak nokta ile çözüldü. m0 = " + (v_1_2.m0 * 100).toFixed(2) + " cm, dm = " + v_1_2.dm_ppm.toFixed(1) + " ppm");
      showToast("✨ 2D Helmert çözüldü! m0 = " + (v_1_2.m0 * 100).toFixed(2) + " cm", "success");
    } catch (v_1_2) {
      logMessage("❌ [HELMERT HATA] " + (v_1_2.message || v_1_2));
      showToast("❌ Helmert çözülemedi: " + v_1_2.message, "error");
    }
  });
  btnEl_12?.addEventListener("click", () => {
    if (!v_6) {
      showToast("⚠️ Lütfen önce .DNS dosyasını yükleyin veya ortak noktalardan parametreleri çözün.", "warning");
      return;
    }
    const v_1_1 = domEl_28?.value.trim();
    if (!v_1_1) {
      showToast("⚠️ Lütfen dönüştürülecek nokta listesini girin.", "warning");
      return;
    }
    const v_2_1 = v_1_1.split(/\r?\n/).map(item => item.trim()).filter(item => item.length > 0);
    items_1 = [];
    if (domEl_32) {
      domEl_32.innerHTML = "";
    }
    v_2_1.forEach((item, idx) => {
      const v_1_2 = item.split(/[\s,;\t]+/).filter(Boolean);
      if (v_1_2.length >= 3) {
        const v_1_3 = v_1_2[0];
        const v_2_2 = parseFloat(v_1_2[1]);
        const v_3_1 = parseFloat(v_1_2[2]);
        const v_4_1 = v_1_2[3] ? parseFloat(v_1_2[3]) : 0;
        if (!isNaN(v_2_2) && !isNaN(v_3_1)) {
          const v_1_4 = v_1.transformPointHelmert2D(v_2_2, v_3_1, v_6);
          const obj = {
            name: v_1_3,
            y1: v_2_2,
            x1: v_3_1,
            y2: v_1_4.y,
            x2: v_1_4.x,
            z: isNaN(v_4_1) ? 0 : v_4_1
          };
          items_1.push(obj);
          if (domEl_32) {
            const trEl = document.createElement("tr");
            trEl.innerHTML = "\n                            <td style=\"font-family: var(--font-mono); color: var(--text-dim);\">" + (idx + 1) + "</td>\n                            <td><strong class=\"font-bold text-main\">" + v_1_3 + "</strong></td>\n                            <td style=\"font-family: var(--font-mono);\">" + v_2_2.toFixed(3) + "</td>\n                            <td style=\"font-family: var(--font-mono);\">" + v_3_1.toFixed(3) + "</td>\n                            <td style=\"font-family: var(--font-mono); font-weight: 700; color: var(--emerald-400);\">" + v_1_4.y.toFixed(3) + "</td>\n                            <td style=\"font-family: var(--font-mono); font-weight: 700; color: var(--emerald-400);\">" + v_1_4.x.toFixed(3) + "</td>\n                            <td style=\"font-family: var(--font-mono);\">" + obj.z.toFixed(3) + "</td>\n                        ";
            domEl_32.appendChild(trEl);
          }
        }
      }
    });
    if (items_1.length > 0) {
      if (domEl_31) {
        domEl_31.style.display = "block";
      }
      showToast("✨ " + items_1.length + " nokta Helmert ile yeni sisteme dönüştürüldü!", "success");
    }
  });
  document.getElementById("btnExportHelmertNcn")?.addEventListener("click", () => {
    if (items_1.length === 0) {
      return;
    }
    let str = "";
    items_1.forEach(item => {
      str += item.name.padEnd(12, " ") + " " + item.y2.toFixed(3).padStart(12, " ") + " " + item.x2.toFixed(3).padStart(12, " ") + " " + item.z.toFixed(3).padStart(9, " ") + "\n";
    });
    downloadTextFile("helmert_donusum_noktalari.ncn", str);
    showToast("💾 helmert_donusum_noktalari.ncn indirildi.", "success");
  });
  document.getElementById("btnExportHelmertDxf")?.addEventListener("click", () => {
    if (items_1.length === 0) {
      return;
    }
    let str = "0\nSECTION\n2\nENTITIES\n";
    items_1.forEach(item => {
      str += "0\nPOINT\n8\nNOKTALAR\n10\n" + item.y2.toFixed(3) + "\n20\n" + item.x2.toFixed(3) + "\n30\n" + item.z.toFixed(3) + "\n";
      str += "0\nTEXT\n8\nNOKTA_ADI\n10\n" + (item.y2 + 0.5).toFixed(3) + "\n20\n" + (item.x2 + 0.5).toFixed(3) + "\n30\n" + item.z.toFixed(3) + "\n40\n1.2\n1\n" + item.name + "\n";
    });
    str += "0\nENDSEC\n0\nEOF\n";
    downloadTextFile("helmert_donusum_noktalari.dxf", str);
    showToast("💾 helmert_donusum_noktalari.dxf indirildi.", "success");
  });
  document.getElementById("btnExportHelmertCsv")?.addEventListener("click", () => {
    if (items_1.length === 0) {
      return;
    }
    let str = "NOKTA,Y_KAYNAK,X_KAYNAK,Y_DONUSEN,X_DONUSEN,KOT\n";
    items_1.forEach(item => {
      str += item.name + "," + item.y1.toFixed(3) + "," + item.x1.toFixed(3) + "," + item.y2.toFixed(3) + "," + item.x2.toFixed(3) + "," + item.z.toFixed(3) + "\n";
    });
    downloadTextFile("helmert_donusum_noktalari.csv", str);
    showToast("💾 helmert_donusum_noktalari.csv indirildi.", "success");
  });
}
let tg20BatchReducedPoints = [];
function initTg20GeoidStation() {
  state.tg20Engine.loadFromUrl("./data/TG20.ggf").then(() => {
    logMessage("🇹🇷 [TG-20] Harita Genel Müdürlüğü Türkiye Hibrit Jeoidi 2020 (492.991 Grid Noktası) hazır.");
  }).catch(arg1 => {
    console.warn("TG-20 otomatik yükleme:", arg1);
  });
  const v_1 = arg1 => {
    if (!arg1) {
      return NaN;
    }
    if (typeof arg1 === "number") {
      return arg1;
    }
    arg1 = String(arg1).trim();
    if (!isNaN(parseFloat(arg1)) && !arg1.includes(" ") && !arg1.includes(":") && !arg1.includes("°")) {
      return parseFloat(arg1);
    }
    const v_2_1 = arg1.replace(/[°'"]/g, " ").split(/[:\s]+/).filter(Boolean).map(Number);
    if (v_2_1.length >= 3) {
      const v_1_1 = v_2_1[0] < 0 ? -1 : 1;
      return (Math.abs(v_2_1[0]) + v_2_1[1] / 60 + v_2_1[2] / 3600) * v_1_1;
    } else if (v_2_1.length === 2) {
      const v_1_1 = v_2_1[0] < 0 ? -1 : 1;
      return (Math.abs(v_2_1[0]) + v_2_1[1] / 60) * v_1_1;
    } else if (v_2_1.length === 1) {
      return v_2_1[0];
    }
    return NaN;
  };
  const inputEl = document.getElementById("inputTg20Lat");
  const inputEl_1 = document.getElementById("inputTg20Lon");
  const inputEl_2 = document.getElementById("inputTg20H");
  const btnEl = document.getElementById("btnCalculateTg20Single");
  const v_2 = async () => {
    if (!state.tg20Engine.isLoaded) {
      try {
        await state.tg20Engine.loadFromUrl("./data/TG20.ggf");
      } catch (v_1_2) {
        showToast("TG20.ggf jeoid veri dosyası yüklenemedi.", "error");
        return;
      }
    }
    const v_1_1 = v_1(inputEl?.value);
    const v_2_1 = v_1(inputEl_1?.value);
    const v_3_1 = parseFloat(inputEl_2?.value) || 0;
    if (isNaN(v_1_1) || isNaN(v_2_1)) {
      showToast("Lütfen geçerli bir WGS-84 Enlem ve Boylam değeri girin.", "warning");
      return;
    }
    const v_4 = state.tg20Engine.reduceHeight(v_1_1, v_2_1, v_3_1);
    const domEl_3 = document.getElementById("resTg20LatLon");
    const domEl_4 = document.getElementById("resTg20ElipH");
    const domEl_5 = document.getElementById("resTg20N");
    const domEl_6 = document.getElementById("resTg20OrthH");
    if (domEl_3) {
      domEl_3.textContent = v_4.lat.toFixed(6) + "° K, " + v_4.lon.toFixed(6) + "° D";
    }
    if (domEl_4) {
      domEl_4.textContent = v_3_1.toFixed(3) + " m";
    }
    if (domEl_5) {
      domEl_5.textContent = v_4.N !== null ? "" + (v_4.N >= 0 ? "+" : "") + v_4.N.toFixed(3) + " m" : "Kapsam Dışı";
    }
    if (domEl_6) {
      domEl_6.textContent = v_4.H !== null ? v_4.H.toFixed(3) + " m" : v_3_1.toFixed(3) + " m";
    }
    if (v_4.inBounds) {
      showToast("🏔️ TG-20 İndirgemesi: N = " + v_4.N.toFixed(3) + " m ➔ Ortometrik H = " + v_4.H.toFixed(3) + " m", "success");
      logMessage("🏔️ [TG-20 İNDİRGEME] Enlem: " + v_4.lat.toFixed(6) + "°, Boylam: " + v_4.lon.toFixed(6) + "°, Elipsoit h: " + v_3_1.toFixed(3) + " m, N: " + v_4.N.toFixed(3) + " m, Ortometrik H: " + v_4.H.toFixed(3) + " m");
    } else {
      showToast("⚠️ Belirtilen nokta Türkiye TG-20 jeoid sınırları (35.5°-42.5°K, 25.5°-45.0°D) dışındadır.", "warning");
    }
  };
  document.getElementById("btnCopyTg20SingleReport")?.addEventListener("click", () => {
    const v_1_1 = v_1(inputEl?.value);
    const v_2_1 = v_1(inputEl_1?.value);
    const v_3_1 = parseFloat(inputEl_2?.value) || 0;
    const v_4 = state.tg20Engine.reduceHeight(v_1_1, v_2_1, v_3_1);
    const v_5 = "==================================================\n  TG-20 JEOİT İNDİRGEME TEK NOKTA RAPORU\n==================================================\nWGS-84 Enlem (Lat)    : " + v_4.lat.toFixed(6) + "° K\nWGS-84 Boylam (Lon)   : " + v_4.lon.toFixed(6) + "° D\nElipsoit Kotu (h)     : " + v_3_1.toFixed(3) + " m\nTG-20 Undülasyonu (N) : " + (v_4.N !== null ? "+" + v_4.N.toFixed(3) : "--") + " m\nOrtometrik Kot (H)    : " + (v_4.H !== null ? v_4.H.toFixed(3) : "--") + " m (TUDKA-99)\nTemel Bağıntı         : H = h - N\nDurum                 : " + v_4.status + "\nTarih                 : " + new Date().toLocaleDateString("tr-TR") + "\n==================================================";
    navigator.clipboard.writeText(v_5).then(() => {
      showToast("📋 Tek nokta TG-20 indirgeme raporu panoya kopyalandı.", "success");
    });
  });
  if (btnEl) {
    btnEl.addEventListener("click", v_2);
  }
  const btnEl_1 = document.getElementById("btnLoadTg20SamplePoints");
  const inputEl_3 = document.getElementById("fileTg20BatchInput");
  const inputEl_4 = document.getElementById("txtTg20BatchInput");
  const btnEl_2 = document.getElementById("btnProcessTg20Batch");
  const domEl = document.getElementById("wrapperTg20BatchResults");
  const domEl_1 = document.getElementById("tbodyTg20BatchResults");
  const domEl_2 = document.getElementById("lblTg20BatchSummary");
  const v_3 = async () => {
    const v_1_1 = inputEl_4?.value.trim() || "";
    if (!v_1_1) {
      showToast("Lütfen indirgenecek nokta listesini girin veya dosya seçin.", "warning");
      return false;
    }
    if (!state.tg20Engine.isLoaded) {
      try {
        await state.tg20Engine.loadFromUrl("./data/TG20.ggf");
      } catch (v_1_2) {
        showToast("TG20.ggf jeoid veri dosyası yüklenemedi.", "error");
        return false;
      }
    }
    const v_2_1 = v_1_1.split(/\r?\n/).map(item => item.trim()).filter(item => item.length > 0 && !item.startsWith(";") && !item.startsWith("#"));
    const items = [];
    v_2_1.forEach((line, idx) => {
      const parts = line.split(/[\s,;\t]+/).filter(Boolean);
      if (parts.length < 2) return;

      let name = "P" + (idx + 1);
      let lat = NaN;
      let lon = NaN;
      let h = 0;

      if (parts.length >= 4) {
        name = parts[0];
        const val1 = v_1(parts[1]);
        const val2 = v_1(parts[2]);
        h = parseFloat(parts[3]) || 0;

        if (val1 >= 34 && val1 <= 44 && val2 >= 24 && val2 <= 46) {
          lat = val1;
          lon = val2;
        } else if (val2 >= 34 && val2 <= 44 && val1 >= 24 && val1 <= 46) {
          lat = val2;
          lon = val1;
        } else if (state.geodesyEngine && (val1 > 100000 || val2 > 100000)) {
          let y = val1, x = val2;
          if (val1 > val2) { x = val1; y = val2; }
          const approxDom = Math.round(Math.min(Math.max((y - 500000) / 100000 * 1.5 + 33, 27), 45) / 3) * 3;
          const geo = state.geodesyEngine.tmToGeographic(y, x, approxDom || 33);
          lat = geo.lat;
          lon = geo.lon;
        } else {
          lat = val1;
          lon = val2;
        }
      } else if (parts.length === 3) {
        const val0 = v_1(parts[0]);
        const val1 = v_1(parts[1]);
        const val2 = parseFloat(parts[2]) || 0;

        if (val0 >= 34 && val0 <= 44 && val1 >= 24 && val1 <= 46) {
          lat = val0;
          lon = val1;
          h = val2;
        } else if (val1 >= 34 && val1 <= 44 && parseFloat(parts[2]) >= 24 && parseFloat(parts[2]) <= 46) {
          name = parts[0];
          lat = val1;
          lon = parseFloat(parts[2]);
          h = 0;
        } else if (state.geodesyEngine && (val0 > 100000 || val1 > 100000)) {
          let y = val0, x = val1;
          if (val0 > val1) { x = val0; y = val1; }
          const approxDom = Math.round(Math.min(Math.max((y - 500000) / 100000 * 1.5 + 33, 27), 45) / 3) * 3;
          const geo = state.geodesyEngine.tmToGeographic(y, x, approxDom || 33);
          lat = geo.lat;
          lon = geo.lon;
          h = val2;
        } else {
          name = parts[0];
          lat = val1;
          lon = val2;
        }
      } else if (parts.length === 2) {
        const val0 = v_1(parts[0]);
        const val1 = v_1(parts[1]);
        if (val0 >= 34 && val0 <= 44 && val1 >= 24 && val1 <= 46) {
          lat = val0;
          lon = val1;
        } else {
          name = parts[0];
          lat = val1;
          lon = 0;
        }
      }

      if (!isNaN(lat) && !isNaN(lon)) {
        items.push({
          name: name,
          lat: lat,
          lon: lon,
          h: h
        });
      }
    });
    if (items.length === 0) {
      showToast("Geçerli koordinat satırı tespit edilemedi.", "warning");
      return false;
    }
    tg20BatchReducedPoints = items.map(item => {
      const v_1_2 = state.tg20Engine.reduceHeight(item.lat, item.lon, item.h);
      return {
        name: item.name,
        lat: item.lat,
        lon: item.lon,
        h: item.h,
        N: v_1_2.N,
        H: v_1_2.H,
        inBounds: v_1_2.inBounds,
        status: v_1_2.status
      };
    });
    if (domEl_1) {
      domEl_1.innerHTML = "";
    }
    tg20BatchReducedPoints.forEach((item, idx) => {
      const trEl = document.createElement("tr");
      trEl.innerHTML = `
        <td style="font-family: var(--font-mono); color: var(--text-dim); text-align: center;">${idx + 1}</td>
        <td><strong class="font-bold text-main font-mono">${item.name}</strong></td>
        <td style="font-family: var(--font-mono);">${item.lat.toFixed(6)}°</td>
        <td style="font-family: var(--font-mono);">${item.lon.toFixed(6)}°</td>
        <td style="font-family: var(--font-mono); color: var(--cyan-400); font-weight: 600;">${item.h.toFixed(3)} m</td>
        <td style="font-family: var(--font-mono); font-weight: 700; color: var(--amber-400);">${item.N !== null ? (item.N >= 0 ? "+" : "") + item.N.toFixed(3) + " m" : "--"}</td>
        <td style="font-family: var(--font-mono); font-weight: 800; color: var(--emerald-400); font-size: 13px;">${item.H !== null ? item.H.toFixed(3) + " m" : "--"}</td>
        <td style="text-align: center;"><span class="badge ${item.inBounds ? "badge-emerald" : "badge-rose"}" style="font-size: 10px; padding: 2px 8px;">${item.inBounds ? "TG-20 OK" : "Kapsam Dışı"}</span></td>
      `;
      domEl_1?.appendChild(trEl);
    });
    if (domEl) {
      domEl.classList.remove("d-none");
      domEl.style.display = "flex";
      domEl.style.flexDirection = "column";
      domEl.style.width = "100%";
    }
    if (domEl_2) {
      const v_1_2 = tg20BatchReducedPoints.filter(item => item.inBounds).length;
      const v_2_2 = v_1_2 > 0 ? (tg20BatchReducedPoints.filter(item => item.inBounds).reduce((arg1, arg2) => arg1 + arg2.N, 0) / v_1_2).toFixed(3) : "--";
      domEl_2.innerHTML = "✅ Toplam <strong>" + tg20BatchReducedPoints.length + "</strong> nokta hesaplandı (Ortalama N: <strong>" + v_2_2 + " m</strong>)";
    }
    logMessage("🇹🇷 [TG-20 TOPLU İNDİRGEME] " + tg20BatchReducedPoints.length + " nokta TG-20 ile indirgendi.");
    return true;
  };
  if (btnEl_1 && inputEl_4) {
    btnEl_1.addEventListener("click", async () => {
      inputEl_4.value = "ANKARA_KIZILAY   39.920800   32.854100   900.000\nISTANBUL_TAKSIM  41.037000   28.985000   100.000\nIZMIR_KONAK      38.419200   27.128700    50.000\nANTALYA_KALEICI  36.884100   30.705600    60.000\nTRABZON_MEYDAN   41.002700   39.716800    40.000\nDIYARBAKIR_SUR   37.914400   40.230600   650.000";
      showToast("🧪 Örnek 6 şehir kadastro WGS-84 noktası yüklendi.", "info");
      await v_3();
    });
  }
  if (inputEl_3 && inputEl_4) {
    inputEl_3.addEventListener("change", async event => {
      const v_1_1 = event.target.files?.[0];
      if (v_1_1) {
        const v_1_2 = await v_1_1.text();
        inputEl_4.value = v_1_2;
        showToast("📂 '" + v_1_1.name + "' içeriği yüklendi (" + (v_1_1.size / 1024).toFixed(1) + " KB).", "info");
        await v_3();
      }
    });
  }
  if (btnEl_2) {
    btnEl_2.addEventListener("click", async () => {
      const v_1_1 = await v_3();
      if (v_1_1) {
        showToast("✨ " + tg20BatchReducedPoints.length + " nokta TG-20 modeliyle başarıyla ortometrik kota indirgendi!", "success");
      }
    });
  }
  document.getElementById("btnExportTg20ReportTxt")?.addEventListener("click", async () => {
    if (tg20BatchReducedPoints.length === 0) {
      const v_1_2 = await v_3();
      if (!v_1_2) {
        return;
      }
    }
    const v_1_1 = state.tg20Engine.generateReductionReport(tg20BatchReducedPoints);
    downloadTextFile("Kadastro_TG20_Kot_Indirgeme_Raporu.txt", v_1_1);
    showToast("📄 Kadastro_TG20_Kot_Indirgeme_Raporu.txt indirildi.", "success");
  });
  document.getElementById("btnExportTg20Ncn")?.addEventListener("click", async () => {
    if (tg20BatchReducedPoints.length === 0) {
      const v_1_1 = await v_3();
      if (!v_1_1) {
        return;
      }
    }
    let str = "";
    tg20BatchReducedPoints.forEach(item => {
      const v_1_1 = (item.H !== null ? item.H : item.h).toFixed(3);
      str += item.name.padEnd(12, " ") + " " + item.lon.toFixed(6).padStart(12, " ") + " " + item.lat.toFixed(6).padStart(12, " ") + " " + v_1_1.padStart(9, " ") + "\n";
    });
    downloadTextFile("Kadastro_TG20_Ortometrik.ncn", str);
    showToast("💾 Kadastro_TG20_Ortometrik.ncn indirildi.", "success");
  });
  document.getElementById("btnExportTg20Csv")?.addEventListener("click", async () => {
    if (tg20BatchReducedPoints.length === 0) {
      const v_1_1 = await v_3();
      if (!v_1_1) {
        return;
      }
    }
    let str = "NOKTA_ADI,ENLEM_WGS84,BOYLAM_WGS84,ELIPSOIT_KOTU_h,TG20_JEOIT_N,ORTOMETRIK_KOT_H,DURUM\n";
    tg20BatchReducedPoints.forEach(item => {
      str += item.name + "," + item.lat.toFixed(6) + "," + item.lon.toFixed(6) + "," + item.h.toFixed(3) + "," + (item.N !== null ? item.N.toFixed(3) : "") + "," + (item.H !== null ? item.H.toFixed(3) : "") + "," + (item.inBounds ? "TG-20" : "KAPSAM_DISI") + "\n";
    });
    downloadTextFile("Kadastro_TG20_Ortometrik.csv", str);
    showToast("💾 Kadastro_TG20_Ortometrik.csv indirildi.", "success");
  });
  document.getElementById("btnPrintTg20Report")?.addEventListener("click", async () => {
    if (tg20BatchReducedPoints.length === 0) {
      const v_1_2 = await v_3();
      if (!v_1_2) {
        return;
      }
    }
    const v_1_1 = state.tg20Engine.generatePrintableReport(tg20BatchReducedPoints);
    const v_2_1 = window.open("", "_blank", "width=950,height=750");
    if (v_2_1) {
      v_2_1.document.write(v_1_1);
      v_2_1.document.close();
      logMessage("🖨️ [TG-20 RAPOR] Yazdırılabilir indirgeme raporu yeni pencerede açıldı.");
      showToast("🖨️ TG-20 İndirgeme Raporu yazdırma penceresi açıldı.", "success");
    }
  });

  // Window level helpers for map popup button actions
  window.sendTg20PointToSingle = (lat, lng) => {
    if (inputEl) inputEl.value = Number(lat).toFixed(6);
    if (inputEl_1) inputEl_1.value = Number(lng).toFixed(6);
    btnEl?.click();
    showToast("📍 Koordinatlar Tek Nokta Kot İndirgemesine aktarıldı.", "success");
    document.getElementById("cardTg20SingleResult")?.scrollIntoView({ behavior: "smooth", block: "center" });
  };

  window.copyTg20NVal = valStr => {
    navigator.clipboard.writeText(valStr).then(() => {
      showToast(`📋 Ondülasyon değeri panoya kopyalandı: ${valStr}`, "success");
    });
  };

  document.getElementById("btnSendTg20MapToSingle")?.addEventListener("click", () => {
    if (state.lastTg20QueryPoint) {
      window.sendTg20PointToSingle(state.lastTg20QueryPoint.lat, state.lastTg20QueryPoint.lng);
    } else {
      showToast("Önce harita üzerinde bir noktaya tıklayın.", "info");
    }
  });

  initTg20InteractiveMap();
}

function initTg20InteractiveMap() {
  const mapEl = document.getElementById("tg20MapContainer");
  if (!mapEl || typeof L === "undefined") return;

  if (state.tg20Map) {
    state.tg20Map.invalidateSize();
    return;
  }

  const { baseMaps, defaultLayer } = createBaseLayers({ defaultType: "hybrid" });

  state.tg20Map = L.map("tg20MapContainer", {
    center: [39.0, 35.2],
    zoom: 6,
    minZoom: 5,
    maxZoom: 19,
    layers: [defaultLayer]
  });

  L.control.layers(baseMaps, null, { position: "topright" }).addTo(state.tg20Map);

  // Türkiye TG-20 Sınır Çerçevesi (35.5° - 42.5° N, 25.5° - 45.0° E)
  const tg20Bounds = [
    [35.5, 25.5],
    [35.5, 45.0],
    [42.5, 45.0],
    [42.5, 25.5]
  ];
  L.polygon(tg20Bounds, {
    color: "#f59e0b",
    weight: 1.5,
    dashArray: "4, 6",
    fillColor: "#f59e0b",
    fillOpacity: 0.03,
    interactive: false
  }).addTo(state.tg20Map);

  state.tg20GridLayerGroup = L.layerGroup().addTo(state.tg20Map);

  // Custom Pulsing TG-20 Icon
  const tg20Icon = L.divIcon({
    className: "tg20-leaflet-icon-wrapper",
    html: `
      <div class="tg20-pulsing-marker">
        <div class="tg20-pulsing-ring"></div>
        <div class="tg20-pulsing-core"></div>
      </div>
    `,
    iconSize: [32, 32],
    iconAnchor: [16, 16]
  });

  // Window level helper to zoom to the 1'x1' grid cell
  window.zoomToTg20Cell = () => {
    if (state.lastTg20CellBounds && state.tg20Map) {
      state.tg20Map.flyToBounds(state.lastTg20CellBounds, { padding: [100, 100], maxZoom: 15 });
      showToast("🔍 1' x 1' TG-20 Enterpolasyon Hücresine Yaklaşıldı", "info");
    }
  };

  // Harita Tıklama Olayı: Anlık N Ondülasyonu & 4 Düğüm Noktası Sorgulama
  state.tg20Map.on("click", async e => {
    try {
      const { lat, lng } = e.latlng;

      if (!state.tg20Engine.isLoaded) {
        try {
          await state.tg20Engine.loadFromUrl("./data/TG20.ggf");
        } catch (err) {
          showToast("TG20.ggf jeoid verisi yükleniyor...", "info");
        }
      }

      state.tg20GridLayerGroup.clearLayers();
      const details = state.tg20Engine.getGeoidInterpolationDetails(lat, lng);
      state.lastTg20CellBounds = details ? details.cellBounds : null;
      state.lastTg20QueryPoint = { lat, lng, N: details ? details.interpolatedN : null };

      const hudNVal = document.getElementById("tg20HudNValue");
      const hudStatus = document.getElementById("tg20HudStatus");
      const hudLatLon = document.getElementById("tg20HudLatLon");
      const hudTmPafta = document.getElementById("tg20HudTmPafta");

      if (details && details.interpolatedN !== null) {
        const N = details.interpolatedN;
        const dom = state.gnssEngine?.geodesy?.getAutoCentralMeridian3Deg(lng) || 33;
        const tm = state.gnssEngine?.geodesy?.wgs84ToTurefTM(lat, lng, dom) || { y: 0, x: 0 };
        const zone = Math.round(dom / 3);
        const sheet25k = state.paftaEngine?.calculate25kSheet(lat, lng);
        const sheet100k = state.paftaEngine?.calculate100kSheet(lat, lng);
        const paftaName = sheet25k ? (sheet25k.sheetName + (sheet25k.regionalName ? ` (${sheet25k.regionalName})` : "")) : (sheet100k ? sheet100k.sheetName : "--");

        const nFormatted = (N >= 0 ? "+" : "") + N.toFixed(3) + " m";

        // 1. Üçgenleme (Triangulation / TIN Mesh) Görselleştirmesi
        const pNW = [details.nodes.nw.lat, details.nodes.nw.lon];
        const pNE = [details.nodes.ne.lat, details.nodes.ne.lon];
        const pSW = [details.nodes.sw.lat, details.nodes.sw.lon];
        const pSE = [details.nodes.se.lat, details.nodes.se.lon];
        const pCenter = [lat, lng];

        // 4 Adet Üçgenleme Yüzeyi (Merkez Nokta ile 4 Izgara Düğümü Arasındaki Üçgenler)
        const triangles = [
          { pts: [pCenter, pNW, pNE], color: "#06b6d4", fillOp: 0.12 }, // Kuzey Üçgeni
          { pts: [pCenter, pNE, pSE], color: "#38bdf8", fillOp: 0.10 }, // Doğu Üçgeni
          { pts: [pCenter, pSE, pSW], color: "#10b981", fillOp: 0.12 }, // Güney Üçgeni
          { pts: [pCenter, pSW, pNW], color: "#f59e0b", fillOp: 0.10 }  // Batı Üçgeni
        ];

        triangles.forEach(tri => {
          L.polygon(tri.pts, {
            color: "#0284c7",
            weight: 1.5,
            dashArray: "3, 5",
            fillColor: tri.color,
            fillOpacity: tri.fillOp,
            interactive: false
          }).addTo(state.tg20GridLayerGroup);
        });

        // Dış 1'x1' Izgara Hücresi Çerçevesi
        L.polygon(details.cellBounds, {
          color: "#06b6d4",
          weight: 2,
          dashArray: "6, 6",
          fillOpacity: 0,
          interactive: false
        }).addTo(state.tg20GridLayerGroup);

        // Merkezden 4 Köşeye Üçgenleme Radyal Işınları (Dashed Tie Lines)
        [pNW, pNE, pSW, pSE].forEach(corner => {
          L.polyline([pCenter, corner], {
            color: "#f59e0b",
            weight: 1.8,
            dashArray: "4, 4",
            opacity: 0.85,
            interactive: false
          }).addTo(state.tg20GridLayerGroup);
        });

        // 2. Etraftaki 4 Izgara Düğüm Noktasına Yanıp Sönen Pinler
        const nodeList = [details.nodes.nw, details.nodes.ne, details.nodes.sw, details.nodes.se];
        for (const node of nodeList) {
          const gridPinIcon = L.divIcon({
            className: "tg20-leaflet-icon-wrapper",
            html: `
              <div class="tg20-grid-pin" title="TG-20 Izgara Düğümü (${node.id}): N = +${node.N.toFixed(3)}m">
                <div class="tg20-grid-pin-ring"></div>
                <div class="tg20-grid-pin-core"></div>
              </div>
            `,
            iconSize: [24, 24],
            iconAnchor: [12, 12]
          });

          L.marker([node.lat, node.lon], { icon: gridPinIcon })
            .bindTooltip(`TG-20 ${node.id}: +${node.N.toFixed(3)} m`, { direction: "top", offset: [0, -8] })
            .addTo(state.tg20GridLayerGroup);
        }

        // HUD Bilgi Panelini Güncelle (Harita Görüşünü Kapatmayan Sabit Köşe Paneli)
        if (hudNVal) hudNVal.textContent = nFormatted;
        if (hudStatus) {
          hudStatus.textContent = "TG-20 Kapsamında";
          hudStatus.className = "badge badge-emerald text-2xs";
        }
        if (hudLatLon) hudLatLon.textContent = `${lat.toFixed(6)}° K, ${lng.toFixed(6)}° D`;
        if (hudTmPafta) hudTmPafta.textContent = `Y: ${tm.y.toFixed(2)}, X: ${tm.x.toFixed(2)} (DOM ${dom}°) | Pafta: ${paftaName}`;

        // Marker Yerleştir (Popup Yok, Harita ve Üçgenler %100 Açık ve Görünür)
        if (!state.tg20MapMarker) {
          state.tg20MapMarker = L.marker([lat, lng], { icon: tg20Icon }).addTo(state.tg20Map);
        } else {
          state.tg20MapMarker.setLatLng([lat, lng]);
        }

        showToast(`🌊 TG-20 Ondülasyonu: ${nFormatted} | 4 Enterpolasyon Düğümü Çizildi`, "info");
        logMessage(`🌊 [TG-20 4-NOKTA ENTERPOLASYONU] ${lat.toFixed(6)}°K, ${lng.toFixed(6)}°D ➔ N: ${nFormatted} | Düğümler: NW(+${details.nodes.nw.N.toFixed(3)}m %${details.nodes.nw.weightPercent}), NE(+${details.nodes.ne.N.toFixed(3)}m %${details.nodes.ne.weightPercent}), SW(+${details.nodes.sw.N.toFixed(3)}m %${details.nodes.sw.weightPercent}), SE(+${details.nodes.se.N.toFixed(3)}m %${details.nodes.se.weightPercent})`);
      } else {
        if (hudNVal) hudNVal.textContent = "Kapsam Dışı";
        if (hudStatus) {
          hudStatus.textContent = "Türkiye Sınırı Dışında";
          hudStatus.className = "badge badge-rose text-2xs";
        }
        if (hudLatLon) hudLatLon.textContent = `${lat.toFixed(6)}° K, ${lng.toFixed(6)}° D`;
        if (hudTmPafta) hudTmPafta.textContent = "--";

        if (!state.tg20MapMarker) {
          state.tg20MapMarker = L.marker([lat, lng], { icon: tg20Icon }).addTo(state.tg20Map);
        } else {
          state.tg20MapMarker.setLatLng([lat, lng]);
        }

        showToast("⚠️ Tıklanan nokta Türkiye TG-20 jeoid sınırları dışındadır.", "warning");
      }
    } catch (err) {
      console.error("TG-20 map click error:", err);
    }
  });

  document.getElementById("btnTg20MapResetView")?.addEventListener("click", () => {
    state.tg20Map?.flyTo([39.0, 35.2], 6, { duration: 1 });
  });

  // Window level action: transfer map point to single-point calculator & auto switch subtab
  window.sendTg20PointToSingle = (lat, lng) => {
    const inLat = document.getElementById("inputTg20Lat");
    const inLon = document.getElementById("inputTg20Lon");
    if (inLat && inLon) {
      inLat.value = Number(lat).toFixed(6);
      inLon.value = Number(lng).toFixed(6);
    }
    const btnCalc = document.getElementById("btnTg20SubtabCalc");
    if (btnCalc) btnCalc.click();

    setTimeout(() => {
      document.getElementById("btnCalculateTg20Single")?.click();
    }, 120);

    showToast("📍 Koordinat Tek Nokta Kot İndirgeme sekmesine aktarıldı.", "success");
  };

  document.getElementById("btnSendTg20MapToSingle")?.addEventListener("click", () => {
    if (state.lastTg20QueryPoint) {
      window.sendTg20PointToSingle(state.lastTg20QueryPoint.lat, state.lastTg20QueryPoint.lng);
    } else {
      showToast("Lütfen önce harita üzerinde bir noktaya tıklayın.", "info");
    }
  });

  document.getElementById("btnCopyTg20HudN")?.addEventListener("click", () => {
    const nText = document.getElementById("tg20HudNValue")?.textContent?.trim();
    if (nText && nText !== "+--.--- m" && nText !== "Kapsam Dışı") {
      navigator.clipboard?.writeText(nText);
      showToast(`📋 TG-20 Ondülasyon Değeri Kopyalandı: ${nText}`, "success");
    } else {
      showToast("Lütfen önce haritada bir nokta seçin.", "info");
    }
  });

  // TG-20 Subtab Switcher
  document.querySelectorAll(".tg20-subtab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tg20-subtab-btn").forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".tg20-pane").forEach(p => p.classList.remove("active"));
      btn.classList.add("active");
      const targetId = btn.getAttribute("data-tg20-target");
      const targetPane = document.getElementById(targetId);
      if (targetPane) {
        targetPane.classList.add("active");
      }
      if (targetId === "tg20PaneMap") {
        initTg20InteractiveMap();
        setTimeout(() => {
          state.tg20Map?.invalidateSize();
        }, 150);
      }
    });
  });
}
function initPpkInspector() {
  let v_1 = null;
  let v_2 = null;
  const inputEl = document.getElementById("inputPpkBaseFile");
  const inputEl_1 = document.getElementById("inputPpkRoverFile");
  const domEl = document.getElementById("txtPpkBaseFileName");
  const domEl_1 = document.getElementById("txtPpkRoverFileName");
  const domEl_2 = document.getElementById("ppkAnalysisResultWrapper");
  const v_3 = () => {
    if (!v_1 || !v_2) {
      return;
    }
    try {
      const v_1_1 = UniversalRinexInspector.inspectPpkOverlap(v_1, v_2);
      if (domEl_2) {
        domEl_2.style.display = "flex";
      }
      const domEl_3 = document.getElementById("bannerPpkStatus");
      const domEl_4 = document.getElementById("iconPpkStatus");
      const domEl_5 = document.getElementById("titlePpkStatus");
      const domEl_6 = document.getElementById("descPpkStatus");
      const domEl_7 = document.getElementById("badgePpkOverlapPercent");
      if (v_1_1.statusLevel === "SUCCESS") {
        if (domEl_3) {
          domEl_3.style.background = "rgba(16, 185, 129, 0.12)";
          domEl_3.style.borderColor = "rgba(16, 185, 129, 0.4)";
        }
        if (domEl_4) {
          domEl_4.className = "fa-solid fa-circle-check";
          domEl_4.style.color = "var(--emerald-400)";
        }
        if (domEl_5) {
          domEl_5.style.color = "var(--emerald-400)";
        }
        if (domEl_7) {
          domEl_7.style.background = "rgba(16, 185, 129, 0.2)";
          domEl_7.style.color = "var(--emerald-400)";
        }
      } else if (v_1_1.statusLevel === "WARNING") {
        if (domEl_3) {
          domEl_3.style.background = "rgba(245, 158, 11, 0.12)";
          domEl_3.style.borderColor = "rgba(245, 158, 11, 0.4)";
        }
        if (domEl_4) {
          domEl_4.className = "fa-solid fa-triangle-exclamation";
          domEl_4.style.color = "var(--amber-400)";
        }
        if (domEl_5) {
          domEl_5.style.color = "var(--amber-400)";
        }
        if (domEl_7) {
          domEl_7.style.background = "rgba(245, 158, 11, 0.2)";
          domEl_7.style.color = "var(--amber-400)";
        }
      } else {
        if (domEl_3) {
          domEl_3.style.background = "rgba(239, 68, 68, 0.12)";
          domEl_3.style.borderColor = "rgba(239, 68, 68, 0.4)";
        }
        if (domEl_4) {
          domEl_4.className = "fa-solid fa-circle-xmark";
          domEl_4.style.color = "var(--red-400)";
        }
        if (domEl_5) {
          domEl_5.style.color = "var(--red-400)";
        }
        if (domEl_7) {
          domEl_7.style.background = "rgba(239, 68, 68, 0.2)";
          domEl_7.style.color = "var(--red-400)";
        }
      }
      if (domEl_5) {
        domEl_5.textContent = v_1_1.statusTitle;
      }
      if (domEl_6) {
        domEl_6.textContent = v_1_1.statusDesc;
      }
      if (domEl_7) {
        domEl_7.textContent = "%" + v_1_1.overlapPercent.toFixed(1) + " Kapsama";
      }
      const domEl_8 = document.getElementById("statPpkBaseTime");
      const domEl_9 = document.getElementById("statPpkRoverTime");
      const domEl_10 = document.getElementById("statPpkOverlapDuration");
      const v_2_1 = document.getElementById("statPpkBaselineDist") || document.getElementById("statPpkBaselineKm");
      const v_3_1 = document.getElementById("statPpkCommonSystems") || document.getElementById("statPpkCommonConst");
      if (domEl_8) {
        domEl_8.textContent = v_1_1.baseStartStr + " - " + v_1_1.baseEndStr + " (" + v_1_1.baseDurationStr + ")";
      }
      if (domEl_9) {
        domEl_9.textContent = v_1_1.roverStartStr + " - " + v_1_1.roverEndStr + " (" + v_1_1.roverDurationStr + ")";
      }
      if (domEl_10) {
        domEl_10.textContent = v_1_1.overlapDurationStr + " (%" + v_1_1.overlapPercent.toFixed(1) + ")";
      }
      if (v_2_1) {
        v_2_1.innerHTML = "<span style=\"color:var(--purple-400); font-weight:700;\">" + v_1_1.baselineStr + "</span> <span style=\"font-size:10px; color:#94a3b8; display:block; font-weight:normal;\">" + v_1_1.baselineNote + "</span>";
      }
      if (v_3_1) {
        v_3_1.textContent = v_1_1.commonConstellations.join(", ") || "GPS";
      }
      const domEl_11 = document.getElementById("barPpkBase");
      const domEl_12 = document.getElementById("barPpkRover");
      if (domEl_11) {
        domEl_11.style.left = v_1_1.timeline.baseLeft + "%";
        domEl_11.style.width = v_1_1.timeline.baseWidth + "%";
      }
      if (domEl_12) {
        domEl_12.style.left = v_1_1.timeline.roverLeft + "%";
        domEl_12.style.width = v_1_1.timeline.roverWidth + "%";
      }
      logMessage("🛰️ [PPK ANALİZİ] Kapsama: %" + v_1_1.overlapPercent.toFixed(1) + ", Baz: " + v_1_1.baselineKm.toFixed(2) + " km, Ortak Süre: " + v_1_1.overlapDurationStr);
      showToast("✨ PPK Analizi: %" + v_1_1.overlapPercent.toFixed(1) + " Kapsama (" + v_1_1.baselineKm.toFixed(1) + " km baz)", v_1_1.statusLevel === "SUCCESS" ? "success" : "warning");
    } catch (v_1_1) {
      logMessage("❌ [PPK HATA] " + (v_1_1.message || v_1_1));
      showToast("❌ PPK analizi yapılamadı: " + v_1_1.message, "error");
    }
  };
  inputEl?.addEventListener("change", async arg1 => {
    const v_2_1 = arg1.target.files?.[0];
    if (v_2_1) {
      const v_1_1 = await v_2_1.text();
      v_1 = UniversalRinexInspector.inspectRinexHeader(v_1_1, v_2_1.name);
      if (domEl) {
        domEl.innerHTML = "<span style=\"color: var(--cyan-400); font-weight: 700;\">" + v_2_1.name + "</span> <span class=\"badge\" style=\"font-size: 10px;\">Sabit</span>";
      }
      showToast("🏛️ Sabit İstasyon yüklendi: " + v_2_1.name, "info");
      v_3();
    }
  });
  inputEl_1?.addEventListener("change", async arg1 => {
    const v_2_1 = arg1.target.files?.[0];
    if (v_2_1) {
      const v_1_1 = await v_2_1.text();
      v_2 = UniversalRinexInspector.inspectRinexHeader(v_1_1, v_2_1.name);
      if (domEl_1) {
        domEl_1.innerHTML = "<span style=\"color: var(--emerald-400); font-weight: 700;\">" + v_2_1.name + "</span> <span class=\"badge\" style=\"font-size: 10px;\">Gezici</span>";
      }
      showToast("🚁 Gezici yüklendi: " + v_2_1.name, "info");
      v_3();
    }
  });
}
function initRinexQualityInspector() {
  const inputEl = document.getElementById("inputRinexQualityFile");
  const domEl = document.getElementById("rinexQualityDashboard");
  inputEl?.addEventListener("change", async arg1 => {
    const v_2 = arg1.target.files?.[0];
    if (!v_2) {
      return;
    }
    showToast("🔍 '" + v_2.name + "' analiz ediliyor...", "info");
    try {
      const v_1 = await v_2.text();
      const v_2_1 = UniversalRinexInspector.analyzeRinexQuality(v_1);
      if (domEl) {
        domEl.style.display = "flex";
      }
      document.getElementById("statQualityEpochs").textContent = v_2_1.totalEpochs + " Epoch (" + v_2_1.startTime + " - " + v_2_1.endTime + ")";
      document.getElementById("statQualityInterval").textContent = v_2_1.detectedInterval + " sn";
      document.getElementById("statQualitySatCount").textContent = v_2_1.avgSats + " / " + v_2_1.maxSats + " Uydu";
      document.getElementById("statQualityConstellation").textContent = "G:" + v_2_1.avgGps + " | R:" + v_2_1.avgGlo + " | E:" + v_2_1.avgGal + " | C:" + v_2_1.avgBds;
      document.getElementById("statQualityScore").textContent = "%" + v_2_1.qualityScore + " " + (v_2_1.qualityScore >= 80 ? "Mükemmel" : "İyi");
      drawRinexQualityChart(v_2_1.timeline);
      logMessage("📊 [RINEX KALİTE] " + v_2.name + ": " + v_2_1.totalEpochs + " Epoch, Ort. " + v_2_1.avgSats + " Uydu, Kalite Skoru %" + v_2_1.qualityScore);
      showToast("✨ '" + v_2.name + "' başarıyla analiz edildi (Ort. " + v_2_1.avgSats + " Uydu).", "success");
    } catch (v_1) {
      logMessage("❌ [RINEX KALİTE HATA] " + (v_1.message || v_1));
      showToast("❌ Kalite analizi yapılamadı: " + v_1.message, "error");
    }
  });
  window.addEventListener("resize", () => {
    const domEl_1 = document.getElementById("canvasRinexQualityChart");
    if (domEl_1 && domEl_1.offsetParent !== null && window.lastRinexQualityTimeline) {
      drawRinexQualityChart(window.lastRinexQualityTimeline);
    }
  });
}
function drawRinexQualityChart(arg1) {
  const domEl = document.getElementById("canvasRinexQualityChart");
  if (!domEl || !arg1 || arg1.length === 0) {
    return;
  }
  window.lastRinexQualityTimeline = arg1;
  const v_2 = domEl.getContext("2d");
  const v_3 = domEl.width = domEl.parentElement.clientWidth || 900;
  const v_4 = domEl.height = 180;
  v_2.clearRect(0, 0, v_3, v_4);
  const num = 35;
  const num_1 = 15;
  const num_2 = 15;
  const num_3 = 25;
  const v_5 = v_3 - num - num_1;
  const v_6 = v_4 - num_2 - num_3;
  const v_7 = Math.max(35, Math.ceil((Math.max(...arg1.map(item => item.total)) + 5) / 5) * 5);
  v_2.strokeStyle = "rgba(255, 255, 255, 0.08)";
  v_2.lineWidth = 1;
  v_2.fillStyle = "#64748b";
  v_2.font = "10px monospace";
  v_2.textAlign = "right";
  const num_4 = 4;
  for (let num_5 = 0; num_5 <= num_4; num_5++) {
    const v_1 = Math.round(v_7 / num_4 * num_5);
    const v_2_1 = num_2 + v_6 - v_1 / v_7 * v_6;
    v_2.beginPath();
    v_2.moveTo(num, v_2_1);
    v_2.lineTo(v_3 - num_1, v_2_1);
    v_2.stroke();
    v_2.fillText("" + v_1, num - 5, v_2_1 + 3);
  }
  const v_8 = arg1_1 => num + arg1_1 / (arg1.length - 1) * v_5;
  const v_9 = arg1_1 => num_2 + v_6 - arg1_1 / v_7 * v_6;
  const v_10 = (arg1_1, arg2, arg3, arg4 = null) => {
    if (arg1.length < 2) {
      return;
    }
    v_2.beginPath();
    v_2.moveTo(v_8(0), v_9(arg1[0][arg1_1]));
    for (let num_5 = 1; num_5 < arg1.length; num_5++) {
      v_2.lineTo(v_8(num_5), v_9(arg1[num_5][arg1_1]));
    }
    if (arg4) {
      v_2.save();
      v_2.lineTo(v_8(arg1.length - 1), num_2 + v_6);
      v_2.lineTo(v_8(0), num_2 + v_6);
      v_2.closePath();
      v_2.fillStyle = arg4;
      v_2.fill();
      v_2.restore();
    }
    v_2.strokeStyle = arg2;
    v_2.lineWidth = arg3;
    v_2.shadowColor = arg2;
    v_2.shadowBlur = arg3 > 1.5 ? 6 : 0;
    v_2.stroke();
    v_2.shadowBlur = 0;
  };
  const v_11 = v_2.createLinearGradient(0, num_2, 0, num_2 + v_6);
  v_11.addColorStop(0, "rgba(245, 158, 11, 0.25)");
  v_11.addColorStop(1, "rgba(245, 158, 11, 0.0)");
  v_10("total", "#f59e0b", 2.5, v_11);
  v_10("gps", "#38bdf8", 1.8);
  v_10("glo", "#f87171", 1.4);
  v_10("gal", "#c084fc", 1.4);
  v_10("bds", "#34d399", 1.4);
  v_2.fillStyle = "#94a3b8";
  v_2.textAlign = "center";
  const v_12 = Math.min(6, arg1.length);
  for (let num_5 = 0; num_5 < v_12; num_5++) {
    const v_1 = Math.floor(num_5 / (v_12 - 1) * (arg1.length - 1));
    const v_2_1 = v_8(v_1);
    v_2.fillText(arg1[v_1].time, v_2_1, v_4 - 8);
  }
}
function initFlightPlannerStudio() {
  if (!state.flightEngine) {
    state.flightEngine = new FlightPlannerEngine();
  }
  const mapEl = document.getElementById("flightMapContainer");
  if (!mapEl) {
    return;
  }
  if (!state.flightMap) {
    const {
      baseMaps: v_1,
      defaultLayer: v_2
    } = createBaseLayers();
    state.flightMap = L.map("flightMapContainer", {
      center: [39, 35.2],
      zoom: 6,
      layers: [v_2]
    });
    L.control.layers(v_1, null, {
      position: "topright"
    }).addTo(state.flightMap);
    state.flightOriginalLayer = L.layerGroup().addTo(state.flightMap);
    state.flightSimplifiedLayer = L.layerGroup().addTo(state.flightMap);
    state.flightRoadLayer = L.layerGroup().addTo(state.flightMap);
    state.flightTriangulationLayer = L.layerGroup().addTo(state.flightMap);
    state.flightGcpLayer = L.layerGroup().addTo(state.flightMap);
    state.isFlightMapInit = true;
    bindRoadDrawingMapEvents();
    document.getElementById("btnDrawCustomRoad")?.addEventListener("click", () => {
      startDrawingRoad();
    });
    document.getElementById("btnPanelDrawRoad")?.addEventListener("click", () => {
      startDrawingRoad();
    });
    document.getElementById("btnFinishDrawRoad")?.addEventListener("click", () => {
      finishDrawingRoad();
    });
    document.getElementById("btnCancelDrawRoad")?.addEventListener("click", () => {
      cancelDrawingRoad();
    });
    document.getElementById("btnUploadRoadFile")?.addEventListener("click", () => {
      document.getElementById("inputCustomRoadFile")?.click();
    });
    document.getElementById("inputCustomRoadFile")?.addEventListener("change", async arg1 => {
      const v_2_1 = arg1.target.files?.[0];
      if (!v_2_1) {
        return;
      }
      try {
        const v_1_1 = await state.flightEngine.parseRoadFile(v_2_1);
        renderRoadNetworkOnMap(state.flightEngine.roadWays);
        showToast("✅ " + v_1_1.length + " adet dış yol geometrisi başarıyla yüklendi!", "success");
        if (state.flightEngine.gcpPoints && state.flightEngine.gcpPoints.length > 0) {
          state.flightEngine.gcpPoints.forEach(item => state.flightEngine.recalculatePointRoadDistance(item, 600));
          renderGcpMarkersOnMap(state.flightEngine.gcpPoints);
          renderGcpTable(state.flightEngine.gcpPoints);
        }
      } catch (v_1_1) {
        showToast("Yol dosyası açılamadı: " + v_1_1.message, "error");
      }
      arg1.target.value = "";
    });
    document.getElementById("btnFlightFitBounds")?.addEventListener("click", () => {
      const v_1_1 = state.flightEngine.simplifiedPolygon || state.flightEngine.originalPolygon;
      if (v_1_1 && v_1_1.length > 0) {
        const v_1_2 = v_1_1.map(item => [item.lat, item.lon]);
        state.flightMap.fitBounds(L.latLngBounds(v_1_2), {
          padding: [40, 40]
        });
      } else {
        showToast("Haritaya sığdırılacak yüklü bir uçuş poligonu bulunamadı.", "info");
      }
    });
    document.getElementById("btnFetchRoadsNow")?.addEventListener("click", async () => {
      const v_1_1 = state.flightEngine.simplifiedPolygon || state.flightEngine.originalPolygon;
      if (!v_1_1 || v_1_1.length === 0) {
        showToast("Lütfen önce bir KML uçuş alanı yükleyiniz.", "info");
        return;
      }
      const btnEl_3 = document.getElementById("btnFetchRoadsNow");
      const btnEl_4 = document.getElementById("txtRoadBtn");
      if (btnEl_4) {
        btnEl_4.textContent = "İndiriliyor...";
      }
      if (btnEl_3) {
        btnEl_3.disabled = true;
      }
      logMessage("🛣️ [YOL SORGUSU] OpenStreetMap sunucularından yol ağı indiriliyor...");
      try {
        const v_1_2 = await state.flightEngine.fetchRoadNetwork();
        renderRoadNetworkOnMap(v_1_2);
        showToast("✅ " + v_1_2.length + " adet yol ve patika segmenti haritaya işlendi!", "success");
        logMessage("✅ [YOL SORGUSU] " + v_1_2.length + " yol segmenti başarıyla haritaya yüklendi.");
        if (state.flightEngine.gcpPoints && state.flightEngine.gcpPoints.length > 0) {
          await generateFlightGCPs();
        }
      } catch (v_1_2) {
        console.error("Yol indirme hatası:", v_1_2);
        showToast("Yol ağı indirilemedi: " + v_1_2.message, "error");
      } finally {
        if (btnEl_3) {
          btnEl_3.disabled = false;
        }
      }
    });
    document.getElementById("btnToggleRoadNetwork")?.addEventListener("click", arg1 => {
      const v_2_1 = arg1.currentTarget;
      if (state.flightMap.hasLayer(state.flightRoadLayer)) {
        state.flightMap.removeLayer(state.flightRoadLayer);
        v_2_1.classList.remove("active");
        v_2_1.classList.add("inactive");
      } else {
        state.flightMap.addLayer(state.flightRoadLayer);
        v_2_1.classList.add("active");
        v_2_1.classList.remove("inactive");
      }
    });
    document.getElementById("btnToggleGcpPins")?.addEventListener("click", arg1 => {
      const v_2_1 = arg1.currentTarget;
      if (state.flightMap.hasLayer(state.flightGcpLayer)) {
        state.flightMap.removeLayer(state.flightGcpLayer);
        v_2_1.classList.remove("active");
        v_2_1.classList.add("inactive");
      } else {
        state.flightMap.addLayer(state.flightGcpLayer);
        v_2_1.classList.add("active");
        v_2_1.classList.remove("inactive");
      }
    });
    document.getElementById("btnToggleTriangles")?.addEventListener("click", arg1 => {
      const v_2_1 = arg1.currentTarget;
      if (state.flightMap.hasLayer(state.flightTriangulationLayer)) {
        state.flightMap.removeLayer(state.flightTriangulationLayer);
        v_2_1.classList.remove("active");
        v_2_1.classList.add("inactive");
      } else {
        state.flightMap.addLayer(state.flightTriangulationLayer);
        v_2_1.classList.add("active");
        v_2_1.classList.remove("inactive");
      }
    });
    const btnEl = document.getElementById("btnToggleFlightLines");
    const btnEl_1 = document.getElementById("btnToggleCorridors");
    const btnEl_2 = document.getElementById("btnToggleWaypoints");
    if (btnEl) {
      btnEl.addEventListener("click", () => {
        const v_1_1 = btnEl.classList.toggle("active");
        if (state.flightLinesLayer) {
          if (v_1_1) {
            state.flightMap.addLayer(state.flightLinesLayer);
          } else {
            state.flightMap.removeLayer(state.flightLinesLayer);
          }
        }
        if (state.flightHomeLayer) {
          if (v_1_1) {
            state.flightMap.addLayer(state.flightHomeLayer);
          } else {
            state.flightMap.removeLayer(state.flightHomeLayer);
          }
        }
      });
    }
    if (btnEl_2) {
      btnEl_2.addEventListener("click", () => {
        const v_1_1 = btnEl_2.classList.toggle("active");
        if (state.flightWaypointsLayer) {
          if (v_1_1) {
            state.flightMap.addLayer(state.flightWaypointsLayer);
          } else {
            state.flightMap.removeLayer(state.flightWaypointsLayer);
          }
        }
      });
    }
  } else {
    setTimeout(() => {
      state.flightMap.invalidateSize();
    }, 250);
  }
  const domEl = document.getElementById("flightDatePicker");
  if (domEl && !domEl.value) {
    domEl.value = new Date().toISOString().split("T")[0];
  }
  bindFlightIngestHandlers();
  bindFlightSimplificationHandlers();
  bindSolarAndWeatherHandlers();
  initDroneDatabaseUI();
  bindGcpGenerationHandlers();
  bindFlightExportHandlers();

  if (!state.flightEngine && typeof FlightPlannerEngine !== "undefined") {
    state.flightEngine = new FlightPlannerEngine();
  }
  if (state.flightEngine) {
    const defaultDate = domEl?.value || new Date().toISOString().split("T")[0];
    updateWeatherAndSolar(39.9208, 32.8541, defaultDate);
  }
}
function bindFlightIngestHandlers() {
  const inputEl = document.getElementById("inputFlightFile");
  const btnEl = document.getElementById("btnLoadDemoFlightKml");
  inputEl?.addEventListener("change", async arg1 => {
    if (!arg1.target.files || arg1.target.files.length === 0) {
      return;
    }
    const v_2 = arg1.target.files[0];
    try {
      logMessage("📂 [İHA UÇUŞ] '" + v_2.name + "' dosyası ayrıştırılıyor...");
      showToast("'" + v_2.name + "' uçuş sahası yükleniyor...", "info");
      await state.flightEngine.parsePolygonFile(v_2);
      await onFlightPolygonLoaded(v_2.name);
    } catch (v_1) {
      console.error("Uçuş poligonu yükleme hatası:", v_1);
      showToast("Poligon yüklenemedi: " + v_1.message, "error");
      logMessage("⛔ [HATA] " + v_1.message);
    }
  });
  btnEl?.addEventListener("click", async () => {
    try {
      logMessage("✨ [DEMO] Gerçekçi çok kırıklı İHA uçuş sahası (Muğla/Milas Maden & Tarım Sahası) yükleniyor...");
      const v_1 = getSampleFlightKmlString();
      const v_2 = new Blob([v_1], {
        type: "application/vnd.google-earth.kml+xml"
      });
      const v_3 = new File([v_2], "Ornek_Cok_Krikli_Ucus_Sahasi.kml", {
        type: "application/vnd.google-earth.kml+xml"
      });
      await state.flightEngine.parsePolygonFile(v_3);
      await onFlightPolygonLoaded(v_3.name);
      showToast("✨ Örnek uçuş sahası yüklendi (38 kırıklı poligon)!", "success");
    } catch (v_1) {
      console.error("Demo poligon hatası:", v_1);
      showToast("Demo poligon yüklenemedi: " + v_1.message, "error");
    }
  });
}
async function onFlightPolygonLoaded(arg1) {
  const v_2 = state.flightEngine.originalStats;
  const v_3 = state.flightEngine.simplifiedStats;
  const domEl = document.getElementById("kpiVertexRatio");
  const domEl_1 = document.getElementById("kpiAreaDiff");
  const domEl_2 = document.getElementById("kpiAreaDisplay");
  const domEl_3 = document.getElementById("badgeFlightSimplification");
  const statVertices = document.getElementById("statFlightVertices");
  const statPerimeter = document.getElementById("statFlightPerimeter");
  const statArea = document.getElementById("statFlightArea");
  const statGain = document.getElementById("statFlightGain");
  if (v_2 && v_3) {
    if (domEl) {
      domEl.textContent = v_2.uniqueVertexCount + " ➔ " + v_3.uniqueVertexCount + " Köşe";
    }
    if (domEl_1) {
      domEl_1.textContent = "(+%" + v_3.areaDiffPct.toFixed(1) + ")";
    }
    if (domEl_2) {
      domEl_2.textContent = "Alan: " + v_3.areaHa.toFixed(2) + " ha (" + v_3.areaKm2.toFixed(3) + " km²) | Çevre: " + Math.round(v_3.perimeterM) + " m";
    }
    if (statVertices) {
      statVertices.textContent = v_2.uniqueVertexCount + " ➔ " + v_3.uniqueVertexCount + " Köşe";
    }
    if (statPerimeter) {
      statPerimeter.textContent = Math.round(v_3.perimeterM) + " m";
    }
    if (statArea) {
      statArea.textContent = v_3.areaHa.toFixed(2) + " ha";
    }
    const gPct = Math.round((1 - v_3.uniqueVertexCount / v_2.uniqueVertexCount) * 100);
    if (statGain) {
      statGain.textContent = "%" + gPct + " Tasarruf";
    }
    if (domEl_3) {
      domEl_3.textContent = v_3.uniqueVertexCount + " Köşe (%-" + gPct + ")";
    }
  }
  renderFlightPolygonsOnMap();
  const v_4 = state.flightEngine.simplifiedPolygon || state.flightEngine.originalPolygon;
  if (v_4 && v_4.length > 0) {
    state.flightMap.fitBounds(L.latLngBounds(v_4.map(item => [item.lat, item.lon || item.lng])), {
      padding: [40, 40]
    });
  }
  const inputEl = document.getElementById("inputFlightHeading");
  const domEl_4 = document.getElementById("sliderFlightHeading");
  if (state.flightEngine) {
    const v_1 = state.flightEngine.findOptimalLongAxisHeading();
    if (inputEl && !inputEl.dataset.customized) {
      inputEl.value = v_1;
      if (domEl_4) {
        domEl_4.value = v_1;
      }
    }
  }
  recalculatePhotogrammetry();
  try {
    logMessage("🛣️ [YOL AĞI] Saha çevresindeki OpenStreetMap yol ve patika ağı çekiliyor...");
    const v_1 = await state.flightEngine.fetchRoadNetwork();
    renderRoadNetworkOnMap(v_1);
    logMessage("✅ [YOL AĞI] " + v_1.length + " adet erişilebilir yol segmenti haritaya işlendi.");
    recalculatePhotogrammetry();
  } catch (v_1) {
    console.warn("Yol ağı çekme hatası:", v_1);
  }
  try {
    const v_1 = document.getElementById("flightDatePicker")?.value || new Date().toISOString().split("T")[0];
    const v_2_1 = v_2 ? v_2.centroid.lat : v_4[0].lat;
    const v_3_1 = v_2 ? v_2.centroid.lon : v_4[0].lon;
    await updateWeatherAndSolar(v_2_1, v_3_1, v_1);
  } catch (v_1) {
    console.warn("Hava durumu çekme hatası:", v_1);
  }
  try {
    await generateFlightGCPs();
  } catch (v_1) {
    console.warn("GCP üretim hatası:", v_1);
  }
  logMessage("✅ [İHA PLANLAMA] " + arg1 + " için uçuş sahası, koridorlar ve akıllı YKN ağı hazırlandı.");
}
function renderFlightPolygonsOnMap() {
  if (!state.flightMap) {
    return;
  }
  state.flightOriginalLayer.clearLayers();
  state.flightSimplifiedLayer.clearLayers();
  const v_1 = state.flightEngine.originalPolygon;
  const v_2 = state.flightEngine.simplifiedPolygon;
  if (v_1 && v_1.length > 0) {
    const v_1_1 = v_1.map(item => [item.lat, item.lon || item.lng]);
    const v_2_1 = L.polygon(v_1_1, {
      color: "#ef4444",
      weight: 2,
      dashArray: "5, 5",
      fillColor: "#ef4444",
      fillOpacity: 0.08
    }).bindTooltip("Orijinal KML Sınırı (Kırıklı)", {
      sticky: true
    });
    state.flightOriginalLayer.addLayer(v_2_1);
  }
  if (v_2 && v_2.length > 0) {
    const v_1_1 = v_2.map(item => [item.lat, item.lon || item.lng]);
    const v_2_1 = L.polygon(v_1_1, {
      color: "#00f2ff",
      weight: 3.2,
      fillColor: "#00f2ff",
      fillOpacity: 0.15
    }).bindTooltip("Akıllı Optimize Edilmiş Uçuş Sınırı", {
      sticky: true
    });
    state.flightSimplifiedLayer.addLayer(v_2_1);
  }
}
function bindFlightSimplificationHandlers() {
  const domEl = document.getElementById("sliderSimplification");
  const domEl_1 = document.getElementById("txtSimplificationLevel");
  const btnEl = document.getElementById("btnToggleOriginalLayer");
  const btnEl_1 = document.getElementById("btnToggleSimplifiedLayer");
  domEl?.addEventListener("input", arg1 => {
    const v_2 = parseInt(arg1.target.value, 10);
    const v_3 = v_2 / 100;
    let v_4 = "Dengeli (%" + v_2 + ")";
    if (v_2 === 0) {
      v_4 = "Ham Sınır (%0)";
    } else if (v_2 <= 25) {
      v_4 = "Hafif Düzeltme (%" + v_2 + ")";
    } else if (v_2 >= 90) {
      v_4 = "Dış Sınır Çerçevesi (%" + v_2 + ")";
    }
    if (domEl_1) {
      domEl_1.textContent = v_4;
    }
    if (state.flightEngine && state.flightEngine.originalPolygon) {
      state.flightEngine.simplify(v_3);
      const v_1 = state.flightEngine.originalStats;
      const v_2_1 = state.flightEngine.simplifiedStats;
      const domEl_2 = document.getElementById("kpiVertexRatio");
      const domEl_3 = document.getElementById("kpiAreaDiff");
      const domEl_4 = document.getElementById("kpiAreaDisplay");
      const domEl_5 = document.getElementById("badgeFlightSimplification");
      if (domEl_2 && v_1 && v_2_1) {
        domEl_2.textContent = v_1.uniqueVertexCount + " ➔ " + v_2_1.uniqueVertexCount + " Köşe";
      }
      if (domEl_3 && v_2_1) {
        domEl_3.textContent = "(+%" + v_2_1.areaDiffPct.toFixed(1) + ")";
      }
      if (domEl_4 && v_2_1) {
        domEl_4.textContent = "Alan: " + v_2_1.areaHa.toFixed(2) + " ha (" + v_2_1.areaKm2.toFixed(3) + " km²) | Çevre: " + Math.round(v_2_1.perimeterM) + " m";
      }
      if (domEl_5 && v_1 && v_2_1) {
        const v_1_1 = Math.round((1 - v_2_1.uniqueVertexCount / Math.max(1, v_1.uniqueVertexCount)) * 100);
        domEl_5.textContent = v_2_1.uniqueVertexCount + " Köşe (%-" + v_1_1 + ")";
      }
      renderFlightPolygonsOnMap();
      recalculatePhotogrammetry();
    }
  });
  btnEl?.addEventListener("click", () => {
    if (state.flightMap.hasLayer(state.flightOriginalLayer)) {
      state.flightMap.removeLayer(state.flightOriginalLayer);
      btnEl.classList.remove("btn-primary");
      btnEl.classList.add("btn-secondary");
    } else {
      state.flightMap.addLayer(state.flightOriginalLayer);
      btnEl.classList.remove("btn-secondary");
      btnEl.classList.add("btn-primary");
    }
  });
  btnEl_1?.addEventListener("click", () => {
    if (state.flightMap.hasLayer(state.flightSimplifiedLayer)) {
      state.flightMap.removeLayer(state.flightSimplifiedLayer);
      btnEl_1.classList.remove("btn-primary");
      btnEl_1.classList.add("btn-secondary");
    } else {
      state.flightMap.addLayer(state.flightSimplifiedLayer);
      btnEl_1.classList.remove("btn-secondary");
      btnEl_1.classList.add("btn-primary");
    }
  });
}
function getCardinalDirectionTr(arg1) {
  const items = ["K (Kuzey)", "KKD", "KD (Kuzeydoğu)", "DKD", "D (Doğu)", "DGD", "GD (Güneydoğu)", "GGD", "G (Güney)", "GGB", "GB (Güneybatı)", "BGB", "B (Batı)", "BKB", "KB (Kuzeybatı)", "KKB"];
  const v_2 = Math.round((arg1 % 360 + 360) % 360 / 22.5) % 16;
  return items[v_2];
}
function initFlightDatePickerBounds() {
  const v_1 = new Date();
  const v_2 = v_1.toISOString().split("T")[0];
  const v_3 = new Date(v_1.getTime() + 1296000000);
  const v_4 = v_3.toISOString().split("T")[0];
  const domEl = document.getElementById("flightDatePicker");
  if (domEl) {
    domEl.min = v_2;
    domEl.max = v_4;
    if (!domEl.value || domEl.value < v_2 || domEl.value > v_4) {
      domEl.value = v_2;
    }
  }
}
async function updateWeatherAndSolar(arg1, arg2, arg3) {
  if (!state.flightEngine) {
    return;
  }
  const v_4 = state.flightEngine.calculateSolarTrajectory(arg1, arg2, arg3);
  const domEl = document.getElementById("kpiOptimalSolarWindow");
  const domEl_1 = document.getElementById("kpiSolarDetail");
  const domEl_2 = document.getElementById("badgeSolarStatus");
  if (domEl) {
    domEl.textContent = v_4.optimalWindow;
  }
  if (domEl_1) {
    domEl_1.textContent = "Maks Tepe Açısı: " + v_4.maxElevationDeg + "° | Min Gölge: " + v_4.minShadowMultiplier + "x";
  }
  if (domEl_2) {
    domEl_2.textContent = v_4.hasSufficientSun ? "Verimli Güneş (≥35°)" : "Düşük Açı";
    domEl_2.className = v_4.hasSufficientSun ? "status-pill badge-safety-safe" : "status-pill badge-safety-warning";
  }
  if (typeof window !== "undefined" && typeof window.renderSolarTimelineBars === "function") {
    window.renderSolarTimelineBars(v_4.hourlySeries);
  }
  const v_5 = await state.flightEngine.fetchLiveWeather(arg1, arg2, arg3);
  const domEl_3 = document.getElementById("kpiWindSpeed");
  const domEl_4 = document.getElementById("kpiWindKmh");
  const domEl_5 = document.getElementById("kpiWeatherSummary");
  const domEl_6 = document.getElementById("badgeFlightSafety");
  const domEl_7 = document.getElementById("txtOptimalHeadingVal");
  if (domEl_3) {
    domEl_3.textContent = v_5.maxWindMs + " m/s";
  }
  if (domEl_4) {
    domEl_4.textContent = "(" + v_5.maxWindKmh + " km/h)";
  }
  if (domEl_5) {
    domEl_5.textContent = "Hamle: " + v_5.maxGustMs + " m/s | Yağış: %" + v_5.maxPrecipProb;
  }
  if (domEl_6) {
    domEl_6.textContent = v_5.overallBadge;
    domEl_6.className = "status-pill badge-safety-" + v_5.overallSafety;
  }
  if (domEl_7) {
    domEl_7.textContent = v_5.optimalFlightHeading || "--";
  }
  const domEl_8 = document.getElementById("hudFlightAtmosphere");
  if (domEl_8) {
    domEl_8.style.display = "block";
  }
  const v_6 = parseInt(document.getElementById("sliderToolbarFlightTime")?.value || "660", 10);
  onFlightTimeSliderChange(v_6);
}
function onFlightTimeSliderChange(arg1) {
  const domEl = document.getElementById("sliderToolbarFlightTime");
  const domEl_1 = document.getElementById("sliderSunTime");
  const domEl_2 = document.getElementById("txtToolbarFlightTime");
  const domEl_3 = document.getElementById("txtSunTimeSim");
  const domEl_4 = document.getElementById("hudLiveTimeBadge");
  const domEl_5 = document.getElementById("badgeLiveSunTime");
  if (domEl && parseInt(domEl.value, 10) !== arg1) {
    domEl.value = arg1;
  }
  if (domEl_1 && parseInt(domEl_1.value, 10) !== arg1) {
    domEl_1.value = arg1;
  }
  const v_2 = Math.floor(arg1 / 60);
  const v_3 = arg1 % 60;
  const v_4 = String(v_2).padStart(2, "0") + ":" + String(v_3).padStart(2, "0");
  if (domEl_2) {
    domEl_2.textContent = v_4;
  }
  if (domEl_3) {
    domEl_3.textContent = v_4 + " (" + (v_2 >= 11 && v_2 <= 14 ? "Öğle" : v_2 < 11 ? "Kuşluk" : "İkindi") + ")";
  }
  if (domEl_4) {
    domEl_4.textContent = v_4;
  }
  if (domEl_5) {
    domEl_5.textContent = v_4;
  }
  updateAtmosphereSimulation(arg1);
}
function updateAtmosphereSimulation(arg1) {
  if (!state.flightEngine) {
    return;
  }
  const hourDecimal = arg1 / 60;
  const currentHour = Math.floor(hourDecimal);
  const minuteFract = (arg1 % 60) / 60;

  let sunAzimuth = 145;
  let sunElevation = 45;
  let shadowMultiplier = 0.8;

  if (state.flightEngine.solarData && state.flightEngine.solarData.hourlySeries && state.flightEngine.solarData.hourlySeries.length > 0) {
    const series = state.flightEngine.solarData.hourlySeries;
    const s0 = series.find(item => Math.floor(item.hourDecimal) === currentHour) || series[0];
    const s1 = series.find(item => Math.floor(item.hourDecimal) === currentHour + 1) || s0;
    
    // Smooth angle interpolation for sun azimuth
    const diffAz = ((s1.azimuthDeg - s0.azimuthDeg + 540) % 360) - 180;
    sunAzimuth = Math.round((s0.azimuthDeg + diffAz * minuteFract + 360) % 360);
    sunElevation = Math.round(s0.elevationDeg + (s1.elevationDeg - s0.elevationDeg) * minuteFract);
    const sh0 = s0.shadowMultiplier || 0;
    const sh1 = s1.shadowMultiplier || 0;
    shadowMultiplier = Math.max(0, sh0 + (sh1 - sh0) * minuteFract);
  }

  const dialSun = document.getElementById("dialSunPointer");
  const lblSunAzimuth = document.getElementById("lblWidgetSunAzimuth");
  const lblSunElev = document.getElementById("lblWidgetSunElev");
  const lblShadowMult = document.getElementById("lblWidgetShadowMult");

  if (dialSun) {
    dialSun.style.transform = "rotate(" + sunAzimuth + "deg)";
  }
  if (lblSunAzimuth) {
    const cardDir = getCardinalDirectionTr(sunAzimuth).split(" ")[0];
    lblSunAzimuth.textContent = sunAzimuth + "° (" + cardDir + ")";
  }
  if (lblSunElev) {
    lblSunElev.textContent = sunElevation > 0 ? "(" + sunElevation + "°)" : "(Gece)";
  }
  if (lblShadowMult) {
    lblShadowMult.textContent = sunElevation > 0 ? shadowMultiplier.toFixed(1) + "x Boy" : "Gece";
  }

  let windSpeedMs = 3.5;
  let windSpeedKmh = 12.6;
  let windDir = 45;
  let gustMs = 4.8;

  let cloudPct = 15;
  let precipProb = 0;

  if (state.flightEngine.weatherData && state.flightEngine.weatherData.hours && state.flightEngine.weatherData.hours.length > 0) {
    const hours = state.flightEngine.weatherData.hours;
    const h0 = hours.find(item => item.hour === currentHour) || hours[0];
    const h1 = hours.find(item => item.hour === currentHour + 1) || h0;

    // Linear interpolation between the two hours for minute-level dynamic simulation
    const w0Ms = h0.windSpeedMs !== undefined ? h0.windSpeedMs : h0.windSpeedKmh / 3.6;
    const w1Ms = h1.windSpeedMs !== undefined ? h1.windSpeedMs : h1.windSpeedKmh / 3.6;
    windSpeedMs = w0Ms + (w1Ms - w0Ms) * minuteFract;
    windSpeedKmh = windSpeedMs * 3.6;

    const g0Ms = h0.gustMs !== undefined ? h0.gustMs : w0Ms * 1.35;
    const g1Ms = h1.gustMs !== undefined ? h1.gustMs : w1Ms * 1.35;
    gustMs = g0Ms + (g1Ms - g0Ms) * minuteFract;

    const diffDir = ((h1.windDir - h0.windDir + 540) % 360) - 180;
    windDir = Math.round((h0.windDir + diffDir * minuteFract + 360) % 360);

    const c0 = h0.cloud !== undefined ? h0.cloud : 15;
    const c1 = h1.cloud !== undefined ? h1.cloud : 15;
    cloudPct = Math.round(c0 + (c1 - c0) * minuteFract);

    const p0 = h0.precipProb !== undefined ? h0.precipProb : 0;
    const p1 = h1.precipProb !== undefined ? h1.precipProb : 0;
    precipProb = Math.round(p0 + (p1 - p0) * minuteFract);
  }

  const inputAlt = document.getElementById("inputFlightAltitude");
  const flightAlt = Math.round(state.flightEngine.currentFlightAltitudeM || (inputAlt ? parseFloat(inputAlt.value) : 100) || 100);
  
  // Power law altitude wind gradient: v(h) = v10 * (h/10)^0.14
  const altitudeWindSpeedMs = Math.max(0.5, windSpeedMs * Math.pow(Math.max(10, flightAlt) / 10, 0.14));
  const altitudeWindSpeedKmh = Math.round(altitudeWindSpeedMs * 3.6);

  const dialWind = document.getElementById("dialWindPointer");
  const lblAlt = document.getElementById("lblWidgetFlightAlt");
  const lblWindSpeed = document.getElementById("lblWidgetWindSpeed");
  const lblWindDir = document.getElementById("lblWidgetWindDir");
  const lblWindSafety = document.getElementById("lblWidgetWindSafety");
  const txtSource = document.getElementById("txtWeatherDataSource");

  const lblCloudCover = document.getElementById("lblWidgetCloudCover");
  const lblCloudDesc = document.getElementById("lblWidgetCloudDesc");
  const lblLightCond = document.getElementById("lblWidgetLightCondition");
  const iconCloud = document.getElementById("iconWidgetCloud");

  if (dialWind) {
    dialWind.style.transform = "rotate(" + windDir + "deg)";
  }
  if (lblAlt) {
    lblAlt.textContent = flightAlt + "m";
  }
  if (lblWindSpeed) {
    lblWindSpeed.textContent = altitudeWindSpeedMs.toFixed(1) + " m/s (" + altitudeWindSpeedKmh + " km/sa)";
  }
  if (lblWindDir) {
    const cardDir = getCardinalDirectionTr(windDir).split(" ")[0];
    lblWindDir.textContent = windDir + "° (" + cardDir + ")";
  }
  if (lblWindSafety) {
    if (altitudeWindSpeedMs <= 6.5) {
      lblWindSafety.textContent = "🟢 Sakin / İdeal";
      lblWindSafety.style.color = "var(--emerald-400)";
    } else if (altitudeWindSpeedMs <= 10.5) {
      lblWindSafety.textContent = "🟡 Orta Rüzgar";
      lblWindSafety.style.color = "var(--amber-400)";
    } else {
      lblWindSafety.textContent = "🔴 Riskli Rüzgar";
      lblWindSafety.style.color = "#ef4444";
    }
  }

  // Cloud and Lighting Quality Updates
  if (lblCloudCover) {
    lblCloudCover.textContent = "%" + cloudPct;
  }
  if (lblCloudDesc) {
    if (cloudPct <= 15) lblCloudDesc.textContent = "(Açık)";
    else if (cloudPct <= 45) lblCloudDesc.textContent = "(Az Bulutlu)";
    else if (cloudPct <= 75) lblCloudDesc.textContent = "(Parçalı)";
    else lblCloudDesc.textContent = "(Kapalı)";
  }
  if (iconCloud) {
    if (precipProb > 40) {
      iconCloud.className = "fa-solid fa-cloud-showers-heavy text-rose";
    } else if (cloudPct <= 20) {
      iconCloud.className = "fa-solid fa-sun text-amber";
    } else if (cloudPct <= 50) {
      iconCloud.className = "fa-solid fa-cloud-sun text-sky";
    } else if (cloudPct <= 80) {
      iconCloud.className = "fa-solid fa-cloud-sun text-dim";
    } else {
      iconCloud.className = "fa-solid fa-cloud text-dim";
    }
  }
  if (lblLightCond) {
    if (precipProb > 40) {
      lblLightCond.textContent = "🔴 Yağış Riski";
      lblLightCond.style.color = "#ef4444";
    } else if (cloudPct <= 25) {
      lblLightCond.textContent = "🟢 Net Güneş";
      lblLightCond.style.color = "var(--emerald-400)";
    } else if (cloudPct <= 60) {
      lblLightCond.textContent = "🟢 Dengeli Işık";
      lblLightCond.style.color = "var(--emerald-400)";
    } else if (cloudPct <= 85) {
      lblLightCond.textContent = "🟡 Değişken Gölge";
      lblLightCond.style.color = "var(--amber-400)";
    } else {
      lblLightCond.textContent = "⚪ Dağınık Difüz Işık";
      lblLightCond.style.color = "var(--text-dim)";
    }
  }

  if (txtSource && state.flightEngine.weatherData) {
    txtSource.textContent = state.flightEngine.weatherData.isLive ? "Canlı ECMWF" : "Simülasyon Modeli";
  }

  // Real-time cross-wind optimal heading
  const domHeadingVal = document.getElementById("txtOptimalHeadingVal");
  if (domHeadingVal) {
    const cross1 = (windDir + 90) % 360;
    const cross2 = (windDir + 270) % 360;
    domHeadingVal.textContent = cross1 + "° / " + cross2 + "° (Rüzgara Dik)";
  }

  const domEl_9 = document.getElementById("txtSimSunElev");
  const domEl_10 = document.getElementById("txtSimShadowMult");
  if (domEl_9) {
    domEl_9.textContent = sunElevation + "°";
  }
  if (domEl_10) {
    domEl_10.textContent = sunElevation > 0 ? shadowMultiplier.toFixed(1) + "x" : "Gece";
  }
}
function bindSolarAndWeatherHandlers() {
  initFlightDatePickerBounds();
  const domEl = document.getElementById("sliderToolbarFlightTime");
  const domEl_1 = document.getElementById("sliderSunTime");
  const domEl_2 = document.getElementById("flightDatePicker");
  domEl?.addEventListener("input", arg1 => {
    onFlightTimeSliderChange(parseInt(arg1.target.value, 10));
  });
  domEl_1?.addEventListener("input", arg1 => {
    onFlightTimeSliderChange(parseInt(arg1.target.value, 10));
  });
  domEl_2?.addEventListener("change", async arg1 => {
    const v_2 = arg1.target.value;
    const v_3 = state.flightEngine.simplifiedStats || state.flightEngine.originalStats;
    const lat = v_3 ? v_3.centroid.lat : 39.9208;
    const lon = v_3 ? v_3.centroid.lon : 32.8541;
    showToast("🌤️ " + v_2 + " tarihi için hava durumu ve güneş analizi çekiliyor...", "info");
    await updateWeatherAndSolar(lat, lon, v_2);
    showToast("✅ " + v_2 + " tahminleri haritaya işlendi!", "success");
  });
}
function initDroneDatabaseUI() {
  if (!window.DroneDatabase) {
    return;
  }
  window.refreshDroneDatabaseUI = initDroneDatabaseUI;
  const domEl = document.getElementById("selectDroneModel");
  const domEl_1 = document.getElementById("selectDroneCamera");
  const domEl_2 = document.getElementById("badgeDroneType");
  const domEl_3 = document.getElementById("badgeSensorType");
  const inputEl = document.getElementById("inputFlightSpeed");
  const inputEl_1 = document.getElementById("inputSafeBatteryDuration");
  const domEl_4 = document.getElementById("lblDroneSpeedLimitBadge");
  const domEl_5 = document.getElementById("sliderFlightHeading");
  const inputEl_2 = document.getElementById("inputFlightHeading");
  if (!domEl || !domEl_1) {
    return;
  }
  const v_1 = domEl.value;
  const v_2 = window.DroneDatabase.getDrones();
  domEl.innerHTML = "";
  const v_3 = v_2.filter(item => item.brand === "DJI");
  const v_4 = v_2.filter(item => item.brand === "Quantum Systems" || item.brand === "Wingtra");
  const v_5 = v_2.filter(item => item.brand !== "DJI" && item.brand !== "Quantum Systems" && item.brand !== "Wingtra");
  const v_6 = (arg1, arg2) => {
    if (arg2.length === 0) {
      return;
    }
    const optgroupEl = document.createElement("optgroup");
    optgroupEl.label = arg1;
    arg2.forEach(item => {
      const optionEl = document.createElement("option");
      optionEl.value = item.id;
      optionEl.textContent = item.model;
      optgroupEl.appendChild(optionEl);
    });
    domEl.appendChild(optgroupEl);
  };
  v_6("DJI Enterprise & RTK Serisi", v_3);
  v_6("VTOL / Sabit Kanat Haritalama İHA’ları", v_4);
  v_6("Diğer / Özel Platformlar", v_5);
  if (v_1 && v_2.some(item => item.id === v_1)) {
    domEl.value = v_1;
  } else {
    domEl.value = "dji_m3e";
  }
  function v_7(arg1) {
    if (!domEl_4 || !arg1) {
      return;
    }
    const v_2_1 = parseFloat(inputEl?.value || arg1.defaultSpeedMs);
    const v_3_1 = arg1.maxSpeedMs || 15;
    const v_4_1 = arg1.maxSpeedKmh || (v_3_1 * 3.6).toFixed(1);
    const v_5_1 = arg1.defaultSpeedMs || 12;
    const v_6_1 = arg1.windResistanceMs || 12;
    const v_7_1 = state.flightEngine ? state.flightEngine.flightParams : null;
    const v_8_1 = v_7_1 ? v_7_1.isTriggerSpeedSafe !== false : true;
    if (v_2_1 > v_3_1) {
      domEl_4.innerHTML = `
        <div class="flight-telemetry-chip" style="grid-column: 1 / -1; border-color: rgba(239, 68, 68, 0.5); background: rgba(239, 68, 68, 0.12);">
          <span style="color: #f87171;">⚠️ UYARI</span>
          <strong style="color: #ef4444;">Otonom Görev Sınırı Aşıldı! (Maks: ${v_3_1} m/s / ${v_4_1} km/h)</strong>
        </div>`;
    } else if (!v_8_1) {
      domEl_4.innerHTML = `
        <div class="flight-telemetry-chip" style="grid-column: 1 / -1; border-color: rgba(245, 158, 11, 0.5); background: rgba(245, 158, 11, 0.12);">
          <span style="color: #fbbf24;">⚠️ DİKKAT</span>
          <strong style="color: #f59e0b;">Deklanşör Gecikmesi! Bu irtifada ${v_2_1} m/s hızda fotoğraf atlayabilir</strong>
        </div>`;
    } else {
      domEl_4.innerHTML = `
        <div class="flight-telemetry-chip">
          <span>Otonom Maks</span>
          <strong class="text-cyan">${v_3_1} m/s</strong>
        </div>
        <div class="flight-telemetry-chip">
          <span>Önerilen Hız</span>
          <strong class="text-emerald">${v_5_1} m/s</strong>
        </div>
        <div class="flight-telemetry-chip">
          <span>Rüzgar Direnci</span>
          <strong class="text-amber">${v_6_1} m/s</strong>
        </div>`;
    }
  }
  function v_8(arg1 = null) {
    const v_2_1 = domEl.value;
    const v_3_1 = window.DroneDatabase.getDrone(v_2_1);
    if (domEl_2 && v_3_1) {
      domEl_2.textContent = v_3_1.type || "İHA";
    }
    if (v_3_1) {
      if (inputEl) {
        inputEl.max = v_3_1.maxSpeedMs || 15;
        inputEl.min = v_3_1.minSpeedMs || 1;
        if (!inputEl.dataset.customized) {
          inputEl.value = v_3_1.defaultSpeedMs || 12;
        }
      }
      if (inputEl_1 && !inputEl_1.dataset.customized) {
        inputEl_1.value = v_3_1.safeFlightTimeMin || 32;
      }
      v_7(v_3_1);
    }
    const v_4_1 = window.DroneDatabase.getCamerasForDrone(v_2_1);
    domEl_1.innerHTML = "";
    v_4_1.forEach(item => {
      const optionEl = document.createElement("option");
      optionEl.value = item.id;
      optionEl.textContent = "" + item.name;
      domEl_1.appendChild(optionEl);
    });
    if (arg1 && v_4_1.some(item => item.id === arg1)) {
      domEl_1.value = arg1;
    } else if (v_4_1.length > 0) {
      domEl_1.value = v_4_1[0].id;
    }
    v_9();
    v_10();
    recalculatePhotogrammetry();
  }
  function v_9() {
    const v_1_1 = domEl_1.value;
    const v_2_1 = window.DroneDatabase.getCamera(v_1_1);
    const inputEl_5 = document.getElementById("inputFlightAltitude");
    const inputEl_6 = document.getElementById("inputTargetGsd");
    if (!v_2_1 || !inputEl_5 || !inputEl_6) {
      return;
    }
    const v_3_1 = v_2_1.sensorW || v_2_1.sensorWidthMm || 17.3;
    const v_4_1 = v_2_1.imageW || v_2_1.imageWidthPx || 5280;
    const v_5_1 = v_2_1.pixelSizeUm || v_3_1 / v_4_1 * 1000 || 3.3;
    const v_6_1 = v_2_1.focalMm || v_2_1.focalLengthMm || 12.3;
    if (inputEl_5.value && parseFloat(inputEl_5.value) > 0) {
      const v_1_2 = parseFloat(inputEl_5.value);
      const v_2_2 = v_1_2 * (v_5_1 / 1000) / v_6_1 * 100;
      inputEl_6.value = v_2_2.toFixed(2);
    } else if (inputEl_6.value && parseFloat(inputEl_6.value) > 0) {
      const v_1_2 = parseFloat(inputEl_6.value);
      const v_2_2 = v_1_2 / 100 * v_6_1 / (v_5_1 / 1000);
      inputEl_5.value = v_2_2.toFixed(1);
    }
  }
  function v_10() {
    const v_1_1 = domEl_1.value;
    const v_2_1 = window.DroneDatabase.getCamera(v_1_1);
    if (domEl_3 && v_2_1) {
      domEl_3.textContent = v_2_1.megapixels + "MP (" + (v_2_1.focalLengthMm || v_2_1.focalMm) + "mm)";
    }
  }
  domEl.addEventListener("change", () => {
    if (inputEl) {
      delete inputEl.dataset.customized;
    }
    if (inputEl_1) {
      delete inputEl_1.dataset.customized;
    }
    v_8();
  });
  domEl_1.addEventListener("change", () => {
    v_9();
    v_10();
    recalculatePhotogrammetry();
  });
  inputEl?.addEventListener("input", () => {
    inputEl.dataset.customized = "true";
    const v_1_1 = window.DroneDatabase.getDrone(domEl.value);
    if (v_1_1) {
      v_7(v_1_1);
    }
    recalculatePhotogrammetry();
  });
  inputEl_1?.addEventListener("input", () => {
    inputEl_1.dataset.customized = "true";
    recalculatePhotogrammetry();
  });
  const inputEl_3 = document.getElementById("inputFlightAltitude");
  const inputEl_4 = document.getElementById("inputTargetGsd");
  let v_11 = null;
  const v_12 = (arg1 = 100) => {
    clearTimeout(v_11);
    v_11 = setTimeout(() => {
      recalculatePhotogrammetry();
    }, arg1);
  };
  inputEl_3?.addEventListener("input", () => {
    inputEl_3.dataset.customized = "true";
    delete inputEl_4?.dataset.customized;
    const v_1_1 = domEl_1.value;
    const v_2_1 = window.DroneDatabase ? window.DroneDatabase.getCamera(v_1_1) : null;
    const v_3_1 = parseFloat(inputEl_3.value);
    if (v_2_1 && inputEl_4 && !isNaN(v_3_1) && v_3_1 > 0) {
      const v_1_2 = v_2_1.sensorW || v_2_1.sensorWidthMm || 17.3;
      const v_2_2 = v_2_1.imageW || v_2_1.imageWidthPx || 5280;
      const v_3_2 = v_2_1.pixelSizeUm || v_1_2 / v_2_2 * 1000 || 3.3;
      const v_4_1 = v_2_1.focalMm || v_2_1.focalLengthMm || 12.3;
      const v_5_1 = v_3_1 * (v_3_2 / 1000) / v_4_1 * 100;
      inputEl_4.value = v_5_1.toFixed(2);
    }
    v_12();
  });
  inputEl_4?.addEventListener("input", () => {
    inputEl_4.dataset.customized = "true";
    delete inputEl_3?.dataset.customized;
    const v_1_1 = domEl_1.value;
    const v_2_1 = window.DroneDatabase ? window.DroneDatabase.getCamera(v_1_1) : null;
    const v_3_1 = parseFloat(inputEl_4.value);
    if (v_2_1 && inputEl_3 && !isNaN(v_3_1) && v_3_1 > 0) {
      const v_1_2 = v_2_1.sensorW || v_2_1.sensorWidthMm || 17.3;
      const v_2_2 = v_2_1.imageW || v_2_1.imageWidthPx || 5280;
      const v_3_2 = v_2_1.pixelSizeUm || v_1_2 / v_2_2 * 1000 || 3.3;
      const v_4_1 = v_2_1.focalMm || v_2_1.focalLengthMm || 12.3;
      const v_5_1 = v_3_1 / 100 * v_4_1 / (v_3_2 / 1000);
      inputEl_3.value = v_5_1.toFixed(1);
    }
    v_12();
  });
  ["inputForwardOverlap", "inputSideOverlap", "inputFlightSpeed", "inputSafeBatteryDuration"].forEach(item => {
    document.getElementById(item)?.addEventListener("input", () => {
      v_12(100);
    });
  });
  if (domEl_5 && inputEl_2) {
    domEl_5.addEventListener("input", () => {
      inputEl_2.value = domEl_5.value;
      inputEl_2.dataset.customized = "true";
      recalculatePhotogrammetry();
    });
    inputEl_2.addEventListener("input", () => {
      domEl_5.value = inputEl_2.value;
      inputEl_2.dataset.customized = "true";
      recalculatePhotogrammetry();
    });
  }
  document.getElementById("btnAutoOptimalHeading")?.addEventListener("click", () => {
    if (!state.flightEngine) {
      return;
    }
    const v_1_1 = state.flightEngine.findOptimalLongAxisHeading();
    if (domEl_5) {
      domEl_5.value = v_1_1;
    }
    if (inputEl_2) {
      inputEl_2.value = v_1_1;
      inputEl_2.dataset.customized = "true";
    }
    recalculatePhotogrammetry();
    showToast("Optimal Hat Doğrultusu", "En az dönüşlü uzun eksen (" + v_1_1 + "°) otomatik ayarlandı.", "info");
  });
  document.getElementById("btnWindAlignHeading")?.addEventListener("click", () => {
    if (!state.flightEngine) {
      return;
    }
    const curTime = parseInt(document.getElementById("sliderToolbarFlightTime")?.value || "660", 10);
    const curHour = Math.floor(curTime / 60);
    const minuteFract = (curTime % 60) / 60;
    let windDir = 45;
    if (state.flightEngine.weatherData && state.flightEngine.weatherData.hours && state.flightEngine.weatherData.hours.length > 0) {
      const hours = state.flightEngine.weatherData.hours;
      const h0 = hours.find(item => item.hour === curHour) || hours[0];
      const h1 = hours.find(item => item.hour === curHour + 1) || h0;
      const diffDir = ((h1.windDir - h0.windDir + 540) % 360) - 180;
      windDir = Math.round((h0.windDir + diffDir * minuteFract + 360) % 360);
    }
    const crossWindHeading = (windDir + 90) % 360;
    if (domEl_5) {
      domEl_5.value = crossWindHeading;
    }
    if (inputEl_2) {
      inputEl_2.value = crossWindHeading;
      inputEl_2.dataset.customized = "true";
    }
    recalculatePhotogrammetry();
    showToast("Rüzgar Uyumlu Doğrultu", "Uçuş hatları " + windDir + "° rüzgara dik (" + crossWindHeading + "°) olarak hizalandı.", "info");
  });
  v_8();
}
function recalculatePhotogrammetry() {
  if (!state.flightEngine) {
    if (typeof FlightPlannerEngine !== "undefined") {
      state.flightEngine = new FlightPlannerEngine();
    } else {
      return;
    }
  }
  const v_1 = document.getElementById("selectDroneModel")?.value || "dji_m3e";
  const v_2 = document.getElementById("selectDroneCamera")?.value || "m3e_built_in";
  const inputEl = document.getElementById("inputFlightAltitude");
  const inputEl_1 = document.getElementById("inputTargetGsd");
  const v_3 = inputEl?.dataset.customized === "true";
  const v_4 = parseFloat(inputEl_1?.value) || 2.5;
  const v_5 = parseFloat(inputEl?.value) || 93.2;
  const v_6 = parseFloat(document.getElementById("inputForwardOverlap")?.value) || 80;
  const v_7 = parseFloat(document.getElementById("inputSideOverlap")?.value) || 70;
  const v_8 = parseFloat(document.getElementById("inputFlightSpeed")?.value) || 12;
  const v_9 = parseFloat(document.getElementById("inputSafeBatteryDuration")?.value) || 32;
  const v_10 = parseFloat(document.getElementById("inputFlightHeading")?.value) || 0;
  const domEl = document.getElementById("sliderSimplification");
  const v_11 = domEl ? parseInt(domEl.value, 10) / 100 : 0.5;
  const v_12 = state.flightEngine.generatePhotogrammetryGrid({
    headingDeg: v_10,
    droneKey: v_1,
    cameraKey: v_2,
    targetGsdCm: v_3 ? null : v_4,
    flightAltitudeM: v_3 ? v_5 : null,
    forwardOverlapPct: v_6,
    sideOverlapPct: v_7,
    flightSpeedMs: v_8,
    batteryDurationMin: v_9
  });
  const v_13 = state.flightEngine.flightParams || {};
  state.flightEngine.currentFlightAltitudeM = v_12 ? v_12.flightAltitudeM : v_13.flightAltitudeM || 90;
  if (v_12) {
    if (!v_3 && inputEl && document.activeElement !== inputEl) {
      inputEl.value = v_12.flightAltitudeM;
    } else if (v_3 && inputEl_1 && document.activeElement !== inputEl_1) {
      inputEl_1.value = v_13.targetGsdCm ? v_13.targetGsdCm.toFixed(2) : v_4;
    }
  }
  const domEl_1 = document.getElementById("resCalcAltitude");
  const domEl_2 = document.getElementById("resCalcGridLines");
  const domEl_3 = document.getElementById("resCalcPathLength");
  const domEl_4 = document.getElementById("resCalcPhotos");
  const domEl_5 = document.getElementById("resCalcDuration");
  const domEl_6 = document.getElementById("txtFlightHeadingVal");
  const v_14 = v_12 ? v_12.flightAltitudeM : v_13.flightAltitudeM || v_5;
  const v_15 = v_13.targetGsdCm || v_4;
  const v_16 = v_12 ? v_12.totalLinesCount : v_13.numberOfLines;
  const v_17 = v_12 ? v_12.lineSpacingM : v_13.lineSpacingSideM;
  const v_18 = v_12 ? v_12.groundWidthM : v_13.groundWidthM;
  if (domEl_1) {
    domEl_1.textContent = v_14 + " m AGL (" + Math.round(v_14 * 3.28084) + " ft) | GSD: " + v_15.toFixed(2) + " cm";
  }
  if (domEl_6) {
    domEl_6.textContent = v_10 + "°";
  }
  if (v_12) {
    if (domEl_2) {
      domEl_2.textContent = v_12.totalLinesCount + " Hat (Aralık: " + v_12.lineSpacingM + "m | Kapsama: " + v_12.groundWidthM + "m)";
    }
    if (domEl_3) {
      domEl_3.textContent = v_12.totalDistanceKm + " km (" + v_12.totalLinesCount + " Hat)";
    }
    if (domEl_4) {
      const v_1_1 = !v_13.isTriggerSpeedSafe ? " ⚠️ (Aşırı Hız)" : "";
      domEl_4.textContent = v_12.totalPhotosCount + " Tetikleme (~" + (v_13.triggerIntervalS || 1.5) + " sn)" + v_1_1;
      domEl_4.style.color = v_13.isTriggerSpeedSafe !== false ? "#fff" : "#ef4444";
    }
    if (domEl_5) {
      domEl_5.textContent = v_12.flightDurationMin + " Dk (" + v_12.batteryPacks + " Batarya Seti)";
      domEl_5.style.color = v_12.batteryPacks === 1 ? "var(--emerald-400)" : v_12.batteryPacks <= 2 ? "var(--amber-400)" : "#ef4444";
    }
    if (typeof renderFlightGridOnMap === "function") {
      renderFlightGridOnMap(v_12);
    }
  } else {
    if (domEl_2) {
      domEl_2.textContent = v_16 ? "Tahmini ~" + v_16 + " Hat (Aralık: " + v_17 + "m)" : "Saha Bekleniyor";
    }
    if (domEl_3) {
      domEl_3.textContent = "Poligon Yükleyiniz";
    }
    if (domEl_4) {
      const v_1_1 = !v_13.isTriggerSpeedSafe ? " ⚠️ (Aşırı Hız)" : "";
      domEl_4.textContent = "~" + (v_13.triggerIntervalS || 1.5) + " sn / Tetikleme" + v_1_1;
      domEl_4.style.color = v_13.isTriggerSpeedSafe !== false ? "#fff" : "#ef4444";
    }
    if (domEl_5) {
      domEl_5.textContent = "~" + (v_13.effectiveBatteryMin || 32) + " Dk / Batarya";
      domEl_5.style.color = "var(--emerald-400)";
    }
  }
  try {
    const v_1_1 = parseInt(document.getElementById("sliderToolbarFlightTime")?.value || "660", 10);
    if (typeof updateAtmosphereSimulation === "function") {
      updateAtmosphereSimulation(v_1_1);
    }
  } catch (v_1_1) {}
}
function bindGcpGenerationHandlers() {
  const btnEl = document.getElementById("btnGenerateGCPs");
  btnEl?.addEventListener("click", async () => {
    await generateFlightGCPs();
  });
  const domEl = document.getElementById("filterGcpSearch");
  domEl?.addEventListener("input", arg1 => {
    const v_2 = arg1.target.value.toLowerCase().trim();
    filterGcpTable(v_2);
  });

  const chkSnap = document.getElementById("chkSnapToRoads");
  const inputSnapRadius = document.getElementById("inputSnapMaxRadius");
  const statSnapEl = document.getElementById("statSnapDistance");
  const inputMaxDist = document.getElementById("inputMaxGcpDistance");
  const statTriEl = document.getElementById("statTriangleSpacing");

  const updateGcpStatChips = () => {
    if (chkSnap && inputSnapRadius && statSnapEl) {
      if (!chkSnap.checked) {
        inputSnapRadius.disabled = true;
        inputSnapRadius.style.opacity = "0.45";
        statSnapEl.textContent = "Kapalı (Grid)";
      } else {
        inputSnapRadius.disabled = false;
        inputSnapRadius.style.opacity = "1";
        const val = parseFloat(inputSnapRadius.value) || 300;
        statSnapEl.textContent = `Maks ${val} m`;
      }
    }
    if (inputMaxDist && statTriEl) {
      const dist = parseFloat(inputMaxDist.value) || 1000;
      statTriEl.textContent = `~${dist} m`;
    }
  };

  chkSnap?.addEventListener("change", updateGcpStatChips);
  inputSnapRadius?.addEventListener("input", updateGcpStatChips);
  inputMaxDist?.addEventListener("input", updateGcpStatChips);
  updateGcpStatChips();
}
async function generateFlightGCPs() {
  if (!state.flightEngine || !state.flightEngine.simplifiedPolygon && !state.flightEngine.originalPolygon) {
    showToast("Lütfen önce bir KML/KMZ uçuş sahası yükleyiniz.", "warning");
    return;
  }
  const v_1 = parseFloat(document.getElementById("inputMaxGcpDistance")?.value) || 1000;
  const v_2 = parseFloat(document.getElementById("inputInwardOffset")?.value) || 100;
  const v_3 = parseFloat(document.getElementById("selectGcpRatio")?.value) || 0.75;
  const v_4 = document.getElementById("chkSnapToRoads")?.checked ?? true;
  const snapRadius = parseFloat(document.getElementById("inputSnapMaxRadius")?.value) || 300;

  showToast("🚀 Yol ağı taranıyor ve akıllı YKN/DN üçgenleme ağı kuruluyor...", "info");
  logMessage("⏳ [YKN ÜRETECİ] Maks Aralık: " + v_1 + "m, Yol Snap: " + (v_4 ? `Açık (${snapRadius}m)` : "Kapalı") + "...");
  try {
    const v_1_1 = await state.flightEngine.generateSmartGCPs({
      maxDistanceMeters: v_1,
      inwardOffsetMeters: v_2,
      yknRatio: v_3,
      snapToRoads: v_4,
      snapMaxRadiusM: snapRadius,
      geodesyEngine: state.geodesyEngine,
      tg20Engine: state.tg20Engine
    });
    const v_2_1 = v_1_1.filter(item => item.type === "YKN").length;
    const v_3_1 = v_1_1.filter(item => item.type === "DN").length;
    const v_4_1 = v_1_1.filter(item => item.isRoadSnapped).length;
    const v_5 = v_1_1.length > 0 ? Math.round(v_4_1 / v_1_1.length * 100) : 0;
    const kpiCountEl = document.getElementById("kpiGcpCount");
    const kpiDistEl = document.getElementById("kpiGcpDistance");
    const badgeSnapEl = document.getElementById("badgeGcpRoadSnap");
    if (kpiCountEl) kpiCountEl.textContent = v_2_1 + " YKN + " + v_3_1 + " DN";
    if (kpiDistEl) kpiDistEl.textContent = "Maks: " + v_1 + "m | %" + v_5 + " Yol Kenarı";
    if (badgeSnapEl) badgeSnapEl.textContent = v_4 ? "%" + v_5 + " Yol Snap" : "Doğrudan Grid";
    const targetGcpEl = document.getElementById("statTargetGcpCount");
    const targetChkEl = document.getElementById("statTargetChkCount");
    const triSpacingEl = document.getElementById("statTriangleSpacing");
    const statSnapDistance = document.getElementById("statSnapDistance");
    if (targetGcpEl) targetGcpEl.textContent = v_2_1 + " YKN";
    if (targetChkEl) targetChkEl.textContent = v_3_1 + " DN";
    if (triSpacingEl) triSpacingEl.textContent = "~" + Math.round(v_1) + " m";
    if (statSnapDistance) statSnapDistance.textContent = v_4 ? "Maks " + snapRadius + " m" : "Kapalı";
    renderGcpMarkersOnMap(v_1_1);
    renderRoadNetworkOnMap(state.flightEngine.roadWays);
    renderGcpTable(v_1_1);
    showToast("✅ " + v_1_1.length + " adet nokta (" + v_2_1 + " YKN, " + v_3_1 + " DN) başarıyla üretildi!", "success");
    logMessage("🎯 [YKN TAMAMLANDI] " + v_2_1 + " YKN ve " + v_3_1 + " Denetim Noktası (DN) TG-20 kotlarıyla hesaplandı.");
  } catch (v_1_1) {
    console.error("YKN üretim hatası:", v_1_1);
    showToast("YKN üretilirken hata oluştu: " + v_1_1.message, "error");
  }
}
function buildGcpPopupContent(arg1) {
  const v_2 = arg1.type === "YKN";
  const v_3 = arg1.roadDistM !== null ? "<div style=\"margin-top: 4px; color: #0284c7; font-weight: 600;\">\n            <i class=\"fa-solid fa-road\"></i> " + arg1.status + "\n         </div>" : "<div style=\"margin-top: 4px; color: #64748b; font-weight: 600;\">\n            <i class=\"fa-solid fa-mountain\"></i> Açık Arazi\n         </div>";
  return "\n        <div style=\"font-family: var(--font-sans); font-size: 12px; line-height: 1.5; color: #0f172a; min-width: 230px;\">\n            <div style=\"font-weight: 800; font-size: 14px; margin-bottom: 4px; color: " + (v_2 ? "#059669" : "#d97706") + ";\">\n                " + arg1.name + " <span style=\"font-size: 11px; background: #e2e8f0; padding: 2px 6px; border-radius: 4px;\">" + (arg1.type === "YKN" ? "Yer Kontrol Noktası" : "Denetim Noktası (DN)") + "</span>\n            </div>\n            <hr style=\"margin: 4px 0; border: none; border-top: 1px solid #cbd5e1;\"/>\n            <div><strong>WGS-84 (Enlem/Boylam):</strong></div>\n            <div style=\"font-family: var(--font-mono); font-size: 11px; color: #334155;\">\n                " + arg1.lat.toFixed(7) + "°, " + arg1.lon.toFixed(7) + "°\n            </div>\n            <div style=\"margin-top: 3px;\"><strong>ITRF-96 TM 3° (DOM " + arg1.dom + "°):</strong></div>\n            <div style=\"font-family: var(--font-mono); font-size: 11.5px; font-weight: 700; background: #f1f5f9; padding: 4px 6px; border-radius: 4px; margin: 3px 0; color: #0369a1;\">\n                Y: " + arg1.itrfY.toFixed(3) + "<br/>X: " + arg1.itrfX.toFixed(3) + "\n            </div>\n            " + v_3 + "\n            <div style=\"margin-top: 6px; font-size: 10.5px; color: #64748b; font-style: italic; border-top: 1px dashed #cbd5e1; padding-top: 3px;\">\n                💡 Noktayı fareyle sürükleyerek istediğiniz yere kaydırabilirsiniz.\n            </div>\n            <button type=\"button\" class=\"btn btn-danger btn-xs\" style=\"margin-top: 8px; width: 100%; background: #ef4444; color: #ffffff; border: none; padding: 5px 8px; border-radius: 4px; font-weight: 700; font-size: 11px; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 5px;\" onclick=\"window.deleteGcpPoint(" + arg1.id + ")\">\n                <i class=\"fa-solid fa-trash-can\"></i> Bu Noktayı Sil (Ağı Yenile)\n            </button>\n        </div>\n    ";
}
function highlightTableRow(arg1) {
  const domEl = document.getElementById("tbodyFlightGcpResults");
  if (!domEl) {
    return;
  }
  const domEl_1 = domEl.querySelector("tr[data-point-id=\"" + arg1 + "\"]");
  if (domEl_1) {
    domEl_1.scrollIntoView({
      behavior: "smooth",
      block: "nearest"
    });
    domEl_1.classList.remove("table-row-highlight");
    domEl_1.offsetWidth;
    domEl_1.classList.add("table-row-highlight");
  }
}
window.deleteGcpPoint = function (arg1) {
  if (!state.flightEngine || !state.flightEngine.gcpPoints) {
    return;
  }
  const v_2 = state.flightEngine.gcpPoints.find(item => item.id == arg1 || item.name == arg1);
  if (!v_2) {
    return;
  }
  state.flightEngine.gcpPoints = state.flightEngine.gcpPoints.filter(item => item.id != arg1 && item.name != arg1);
  if (state.flightMap) {
    state.flightMap.closePopup();
  }
  renderGcpMarkersOnMap(state.flightEngine.gcpPoints);
  renderGcpTable(state.flightEngine.gcpPoints);
  const tableEl = document.getElementById("badgeGcpTableCount");
  if (tableEl) {
    tableEl.textContent = state.flightEngine.gcpPoints.length + " Nokta";
  }
  const domEl = document.getElementById("statGcpCount");
  if (domEl) {
    domEl.textContent = state.flightEngine.gcpPoints.length;
  }
  showToast("🗑️ " + v_2.name + " noktası kaldırıldı. Nirengi / Üçgenleme ağı güncellendi.", "warning");
  logMessage("🗑️ [YKN SİLME] " + v_2.name + " noktası kaldırıldı. Kalan " + state.flightEngine.gcpPoints.length + " nokta ile nirengi ağı yeniden bağlandı.");
};
function renderGcpMarkersOnMap(arg1) {
  if (!state.flightMap || !state.flightGcpLayer) {
    return;
  }
  state.flightGcpLayer.clearLayers();
  if (state.flightTriangulationLayer) {
    state.flightTriangulationLayer.clearLayers();
  }
  if (state.flightTriangulationLayer && arg1.length >= 3) {
    const v_1 = computeDelaunayEdges(arg1);
    v_1.forEach(([item, item_1]) => {
      const v_1_1 = Math.PI / 180;
      const v_2 = (item_1.lat - item.lat) * v_1_1;
      const v_3 = (item_1.lon - item.lon) * v_1_1;
      const v_4 = Math.sin(v_2 / 2) ** 2 + Math.cos(item.lat * v_1_1) * Math.cos(item_1.lat * v_1_1) * Math.sin(v_3 / 2) ** 2;
      const v_5 = Math.round(Math.atan2(Math.sqrt(v_4), Math.sqrt(1 - v_4)) * 12756274);
      const v_6 = L.polyline([[item.lat, item.lon], [item_1.lat, item_1.lon]], {
        color: "#00e5ff",
        weight: 1.6,
        dashArray: "3, 4",
        opacity: 0.35
      }).bindTooltip("📐 Nirengi / Üçgen Kenarı: " + item.name + " ➔ " + item_1.name + " (" + v_5 + "m)", {
        sticky: true
      });
      state.flightTriangulationLayer.addLayer(v_6);
    });
  }
  arg1.forEach(item => {
    const v_1 = item.type === "YKN";
    const v_2 = v_1 ? "gcp-pin-ykn" : "gcp-pin-dn";
    const v_3 = "\n            <div class=\"gcp-map-pin " + v_2 + "\">\n                <span class=\"gcp-pin-num\">" + item.id + "</span>\n                <div class=\"gcp-pin-del-badge\" title=\"" + item.name + " Noktasını Kaldır\" onclick=\"event.stopPropagation(); window.deleteGcpPoint(" + item.id + ")\">✕</div>\n            </div>\n        ";
    const v_4 = L.divIcon({
      html: v_3,
      className: "custom-gcp-icon-wrap",
      iconSize: [28, 28],
      iconAnchor: [14, 14]
    });
    let v_5 = null;
    if (item.nearestRoad && item.roadDistM !== null) {
      v_5 = L.polyline([[item.lat, item.lon], [item.nearestRoad.lat, item.nearestRoad.lon]], {
        color: "#f59e0b",
        weight: 2,
        dashArray: "4, 4",
        opacity: 0.8
      });
      if (item.roadDistM >= 20) {
        v_5.bindTooltip("📏 " + item.roadDistM + "m", {
          permanent: true,
          direction: "center",
          className: "road-dist-tooltip"
        });
      } else {
        v_5.bindTooltip("🛣️ " + item.roadDistM + "m (" + (item.nearestRoad.roadInfo?.name || "Yol") + ")", {
          sticky: true,
          className: "road-dist-tooltip"
        });
      }
      state.flightGcpLayer.addLayer(v_5);
    }
    const v_6 = L.marker([item.lat, item.lon], {
      icon: v_4,
      draggable: true,
      zIndexOffset: 1000,
      title: item.name + " - Konumu değiştirmek için sürükleyiniz"
    }).bindPopup(buildGcpPopupContent(item));
    v_6.on("drag", arg1_1 => {
      const v_2_1 = v_6.getLatLng();
      if (state.flightEngine.roadWays && state.flightEngine.roadWays.length > 0) {
        const v_1_1 = state.flightEngine._findNearestRoadPoint(v_2_1.lat, v_2_1.lng, state.flightEngine.roadWays, 600);
        if (v_1_1 && v_1_1.distanceM <= 600) {
          const v_1_2 = Math.round(v_1_1.distanceM);
          if (!v_5) {
            v_5 = L.polyline([[v_2_1.lat, v_2_1.lng], [v_1_1.lat, v_1_1.lon]], {
              color: "#f59e0b",
              weight: 2,
              dashArray: "4, 4",
              opacity: 0.8
            }).addTo(state.flightGcpLayer);
            if (v_1_2 >= 20) {
              v_5.bindTooltip("📏 " + v_1_2 + "m", {
                permanent: true,
                direction: "center",
                className: "road-dist-tooltip"
              });
            }
          } else {
            v_5.setLatLngs([[v_2_1.lat, v_2_1.lng], [v_1_1.lat, v_1_1.lon]]);
            if (v_1_2 >= 20) {
              v_5.setTooltipContent("📏 " + v_1_2 + "m");
            }
          }
        } else if (v_5) {
          state.flightGcpLayer.removeLayer(v_5);
          v_5 = null;
        }
      }
    });
    v_6.on("dragend", arg1_1 => {
      const v_2_1 = v_6.getLatLng();
      item.lat = v_2_1.lat;
      item.lon = v_2_1.lng;
      let v_3_1 = Math.round(item.lon / 3) * 3;
      if (v_3_1 < 27) {
        v_3_1 = 27;
      }
      if (v_3_1 > 45) {
        v_3_1 = 45;
      }
      item.dom = v_3_1;
      if (state.geodesyEngine && typeof state.geodesyEngine.wgs84ToTurefTM === "function") {
        const v_1_1 = state.geodesyEngine.wgs84ToTurefTM(item.lat, item.lon, item.dom);
        item.itrfY = Math.round(v_1_1.Y * 1000) / 1000;
        item.itrfX = Math.round(v_1_1.X * 1000) / 1000;
      } else {
        const v_1_1 = Math.PI / 180;
        const num = 6378137;
        const v_2_2 = Math.cos(item.lat * v_1_1);
        item.itrfY = Math.round((500000 + (item.lon - item.dom) * v_1_1 * num * v_2_2) * 1000) / 1000;
        item.itrfX = Math.round(item.lat * v_1_1 * num * 1000) / 1000;
      }
      state.flightEngine.recalculatePointRoadDistance(item, 600);
      v_6.setPopupContent(buildGcpPopupContent(item));
      renderGcpTable(state.flightEngine.gcpPoints);
      highlightTableRow(item.id);
      if (state.flightTriangulationLayer) {
        renderGcpMarkersOnMap(state.flightEngine.gcpPoints);
      }
      showToast("📍 " + item.name + " yeni konuma yerleştirildi (Y: " + item.itrfY.toFixed(3) + ", X: " + item.itrfX.toFixed(3) + ")", "info");
    });
    v_6.on("click", () => {
      highlightTableRow(item.id);
    });
    state.flightGcpLayer.addLayer(v_6);
    setTimeout(() => {
      const v_1_1 = v_6.getElement();
      if (v_1_1) {
        const domEl = v_1_1.querySelector(".gcp-pin-del-badge");
        if (domEl) {
          L.DomEvent.disableClickPropagation(domEl);
          L.DomEvent.disableScrollPropagation(domEl);
          domEl.addEventListener("click", event => {
            event.stopPropagation();
            event.preventDefault();
            window.deleteGcpPoint(item.id);
          });
          domEl.addEventListener("mousedown", event => {
            event.stopPropagation();
          });
          domEl.addEventListener("touchstart", event => {
            event.stopPropagation();
            window.deleteGcpPoint(item.id);
          });
        }
      }
    }, 10);
  });
}
function renderRoadNetworkOnMap(arg1) {
  if (!state.flightMap || !state.flightRoadLayer) {
    return;
  }
  state.flightRoadLayer.clearLayers();
  const domEl = document.getElementById("badgeRoadCount");
  const btnEl = document.getElementById("txtRoadBtn");
  if (!arg1 || arg1.length === 0) {
    if (domEl) {
      domEl.textContent = "0 Yol Segmenti";
    }
    if (btnEl) {
      btnEl.textContent = "Yolları Çek";
    }
    return;
  }
  if (domEl) {
    domEl.textContent = arg1.length + " Yol Segmenti";
  }
  if (btnEl) {
    btnEl.textContent = arg1.length + " Yol Aktif";
  }
  arg1.forEach(item => {
    const v_1 = item.geometry || (Array.isArray(item) ? item : []);
    if (!v_1 || v_1.length < 2) {
      return;
    }
    const v_2 = v_1.map(item_1 => [item_1.lat, item_1.lon]);
    const v_3 = (item.type || "road").toLowerCase();
    const v_4 = item.name || "";
    let str = "#818cf8";
    let num = 2.5;
    let num_1 = 0.85;
    let v_5 = null;
    let str_1 = "Yerel Yol";
    if (item.isCustom || v_3 === "custom_track") {
      str = "#f59e0b";
      num = 3.5;
      v_5 = "6, 4";
      str_1 = "✏️ Manuel Çizilen Arazi Yolu";
    } else if (["motorway", "trunk", "primary"].includes(v_3)) {
      str = "#38bdf8";
      num = 3.5;
      str_1 = "Ana Yol (Asfalt)";
    } else if (["secondary", "tertiary"].includes(v_3)) {
      str = "#34d399";
      num = 3;
      str_1 = "Tali / Köy Yolu";
    } else if (["residential", "unclassified", "living_street"].includes(v_3)) {
      str = "#cbd5e1";
      num = 2.5;
      str_1 = "Mahalle Yolu";
    } else if (["track", "service"].includes(v_3)) {
      str = "#c084fc";
      num = 2.2;
      v_5 = "5, 4";
      str_1 = "Tarla / Traktör Yolu (Track)";
    } else if (["path", "footway"].includes(v_3)) {
      str = "#fbbf24";
      num = 1.8;
      v_5 = "3, 3";
      str_1 = "Patika / Arazi İzi";
    }
    const v_6 = v_4 ? "🛣️ <strong>" + v_4 + "</strong> (" + str_1 + ")" : "🛣️ " + str_1;
    const v_7 = L.polyline(v_2, {
      color: str,
      weight: num,
      opacity: num_1,
      dashArray: v_5
    }).bindTooltip(v_6, {
      sticky: true
    });
    state.flightRoadLayer.addLayer(v_7);
  });
}
function renderGcpTable(arg1) {
  const domEl = document.getElementById("tbodyFlightGcpResults");
  const tableEl = document.getElementById("badgeGcpTableCount");
  if (!domEl) {
    return;
  }
  if (tableEl) {
    tableEl.textContent = arg1.length + " Nokta";
  }
  domEl.innerHTML = "";
  if (arg1.length === 0) {
    domEl.innerHTML = "<tr><td colspan=\"9\" style=\"text-align: center; padding: 24px; color: var(--text-muted);\">Üretilmiş YKN noktası bulunamadı.</td></tr>";
    return;
  }
  arg1.forEach(item => {
    const trEl = document.createElement("tr");
    trEl.setAttribute("data-point-id", item.id);
    trEl.style.cursor = "pointer";
    const v_1 = item.type === "YKN";
    const v_2 = v_1 ? "<span style=\"background: rgba(16, 185, 129, 0.15); color: var(--emerald-400); padding: 2px 7px; border-radius: 4px; font-weight: 700; font-size: 10.5px;\">YKN</span>" : "<span style=\"background: rgba(245, 158, 11, 0.15); color: var(--amber-400); padding: 2px 7px; border-radius: 4px; font-weight: 700; font-size: 10.5px;\">DN</span>";
    let str = "";
    if (item.roadDistM !== null) {
      if (item.roadDistM <= 15) {
        str = "<span style=\"color: var(--emerald-400); font-weight: 600;\"><i class=\"fa-solid fa-road\"></i> Yol Kenarı (~" + item.roadDistM + "m)</span>";
      } else {
        str = "<span style=\"color: var(--cyan-400); font-weight: 600;\"><i class=\"fa-solid fa-person-walking\"></i> Yola " + item.roadDistM + "m</span>";
      }
    } else {
      str = "<span style=\"color: var(--text-muted);\"><i class=\"fa-solid fa-mountain\"></i> Açık Arazi</span>";
    }
    trEl.innerHTML = "\n            <td style=\"text-align: center; font-family: var(--font-mono); color: var(--text-muted);\">" + item.id + "</td>\n            <td style=\"text-align: left; font-weight: 700;\" class=\"text-main font-mono\">" + item.name + "</td>\n            <td style=\"text-align: center;\">" + v_2 + "</td>\n            <td style=\"text-align: right; font-family: var(--font-mono);\">" + item.lat.toFixed(7) + "°</td>\n            <td style=\"text-align: right; font-family: var(--font-mono);\">" + item.lon.toFixed(7) + "°</td>\n            <td style=\"text-align: right; font-family: var(--font-mono); font-weight: 600; color: var(--cyan-400);\">" + item.itrfY.toFixed(3) + "</td>\n            <td style=\"text-align: right; font-family: var(--font-mono); font-weight: 600; color: var(--cyan-400);\">" + item.itrfX.toFixed(3) + "</td>\n            <td style=\"text-align: center; font-family: var(--font-mono); color: var(--indigo-400); font-weight: 600;\">" + item.dom + "°</td>\n            <td style=\"text-align: left; font-size: 11px;\">" + str + "</td>\n            <td style=\"text-align: center;\">\n                <button class=\"btn btn-icon btn-danger btn-xs\" style=\"padding: 2px 7px; font-size: 11px; background: rgba(239, 68, 68, 0.2); border: 1px solid rgba(239, 68, 68, 0.4); color: #f87171; border-radius: 4px; cursor: pointer;\" onclick=\"event.stopPropagation(); window.deleteGcpPoint(" + item.id + ")\" title=\"" + item.name + " Noktasını Sil\">\n                    <i class=\"fa-solid fa-xmark\"></i>\n                </button>\n            </td>\n        ";
    trEl.addEventListener("click", () => {
      if (state.flightMap) {
        state.flightMap.setView([item.lat, item.lon], Math.max(state.flightMap.getZoom(), 17), {
          animate: true
        });
        highlightTableRow(item.id);
      }
    });
    domEl.appendChild(trEl);
  });
}
function filterGcpTable(arg1) {
  const domEl = document.getElementById("tbodyFlightGcpResults");
  if (!domEl) {
    return;
  }
  const elementsList = domEl.querySelectorAll("tr");
  let num = 0;
  elementsList.forEach(item => {
    const v_1 = item.textContent.toLowerCase();
    if (!arg1 || v_1.includes(arg1)) {
      item.style.display = "";
      num++;
    } else {
      item.style.display = "none";
    }
  });
  const tableEl = document.getElementById("badgeGcpTableCount");
  if (tableEl) {
    tableEl.textContent = num + " Nokta";
  }
}
window.toggleExportDropdown = function (arg1) {
  if (arg1) {
    arg1.preventDefault();
    arg1.stopPropagation();
  }
  const domEl = document.getElementById("menuExportDropdown");
  if (!domEl) {
    return;
  }
  const v_2 = domEl.style.display === "flex" || domEl.classList.contains("show");
  if (v_2) {
    domEl.style.display = "none";
    domEl.classList.remove("show");
  } else {
    domEl.style.display = "flex";
    domEl.classList.add("show");
  }
};
window.exportFlightFile = function (arg1) {
  const domEl = document.getElementById("menuExportDropdown");
  if (domEl) {
    domEl.style.display = "none";
    domEl.classList.remove("show");
  }
  if (!state.flightEngine) {
    state.flightEngine = new FlightPlannerEngine();
  }
  if (arg1 === "dji_kml") {
    const v_1 = state.flightEngine.simplifiedPolygon || state.flightEngine.originalPolygon;
    if (!v_1 || v_1.length === 0) {
      showToast("Dışa aktarmak için önce bir uçuş sahası yükleyin.", "warning");
      return;
    }
    const v_2 = state.flightEngine.exportFlightKml(true);
    downloadTextFile("GNSS_Studio_Ucus_Plani_Sadelestirilmis.kml", v_2, "application/vnd.google-earth.kml+xml");
    showToast("✈️ DJI Pilot 2 uyumlu sadeleştirilmiş KML indirildi.", "success");
  } else if (arg1 === "netcad_ncn") {
    if (!state.flightEngine.gcpPoints || state.flightEngine.gcpPoints.length === 0) {
      showToast("Dışa aktarmak için önce YKN noktası üretin.", "warning");
      return;
    }
    const v_1 = state.flightEngine.exportGcpNcn();
    downloadTextFile("IHA_YKN_Noktalari.ncn", v_1, "text/plain");
    showToast("📍 Netcad .NCN koordinat dosyası indirildi.", "success");
  } else if (arg1 === "autocad_dxf") {
    if (!state.flightEngine.gcpPoints || state.flightEngine.gcpPoints.length === 0) {
      showToast("Dışa aktarmak için önce YKN noktası üretin.", "warning");
      return;
    }
    const v_1 = state.flightEngine.exportGcpDxf();
    downloadTextFile("IHA_Ucus_Plani_ve_YKN.dxf", v_1, "application/dxf");
    showToast("📐 AutoCAD .DXF plan dosyası indirildi.", "success");
  } else if (arg1 === "excel_csv") {
    if (!state.flightEngine.gcpPoints || state.flightEngine.gcpPoints.length === 0) {
      showToast("Dışa aktarmak için önce YKN noktası üretin.", "warning");
      return;
    }
    const v_1 = state.flightEngine.exportGcpCsv();
    downloadTextFile("IHA_YKN_Koordinatlari.csv", v_1, "text/csv");
    showToast("📊 Excel .CSV koordinat çizelgesi indirildi.", "success");
  } else if (arg1 === "google_kml") {
    if (!state.flightEngine.gcpPoints || state.flightEngine.gcpPoints.length === 0) {
      showToast("Dışa aktarmak için önce YKN noktası üretin.", "warning");
      return;
    }
    const v_1 = state.flightEngine.exportGcpKml();
    downloadTextFile("IHA_YKN_Noktalari_3D.kml", v_1, "application/vnd.google-earth.kml+xml");
    showToast("🌐 Google Earth YKN KML dosyası indirildi.", "success");
  }
};
document.addEventListener("click", event => {
  const btnEl = document.getElementById("btnToggleExportMenu");
  const domEl = document.getElementById("menuExportDropdown");
  if (domEl && btnEl && !btnEl.contains(event.target) && !domEl.contains(event.target)) {
    domEl.style.display = "none";
    domEl.classList.remove("show");
  }
});
function bindFlightExportHandlers() {}
function getSampleFlightKmlString() {
  return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<kml xmlns=\"http://www.opengis.net/kml/2.2\">\n  <Document>\n    <name>Milas_Maden_Saha_Siniri</name>\n    <Placemark>\n      <name>Ucus_Alani_38_Krikli</name>\n      <Polygon>\n        <outerBoundaryIs>\n          <LinearRing>\n            <coordinates>\n              27.7850,37.3100,120 27.7880,37.3120,125 27.7870,37.3145,130 27.7910,37.3160,135\n              27.7900,37.3180,140 27.7940,37.3200,145 27.7925,37.3225,150 27.7960,37.3250,155\n              27.7990,37.3240,150 27.8020,37.3270,160 27.8060,37.3260,158 27.8080,37.3290,165\n              27.8120,37.3280,162 27.8150,37.3305,170 27.8180,37.3275,165 27.8210,37.3290,168\n              27.8250,37.3260,160 27.8220,37.3220,150 27.8260,37.3190,145 27.8230,37.3160,140\n              27.8270,37.3130,135 27.8240,37.3100,130 27.8200,37.3080,125 27.8160,37.3095,128\n              27.8120,37.3060,120 27.8080,37.3075,122 27.8040,37.3040,115 27.8000,37.3060,118\n              27.7960,37.3030,112 27.7920,37.3050,115 27.7880,37.3020,110 27.7850,37.3100,120\n            </coordinates>\n          </LinearRing>\n        </outerBoundaryIs>\n      </Polygon>\n    </Placemark>\n  </Document>\n</kml>";
}
function startDrawingRoad() {
  if (!state.flightMap) {
    showToast("Lütfen önce uçuş stüdyosu haritasını açınız.", "warning");
    return;
  }
  if (state.isDrawingRoad) {
    cancelDrawingRoad();
    return;
  }
  state.isDrawingRoad = true;
  state.activeRoadPoints = [];
  state.activeRoadMarkers = [];
  state.flightMap.getContainer().style.cursor = "crosshair";
  if (state.flightGcpLayer) {
    state.flightGcpLayer.eachLayer(arg1 => {
      if (arg1.getElement) {
        arg1.getElement()?.style.setProperty("pointer-events", "none");
      }
    });
  }
  if (state.flightOriginalLayer) {
    state.flightOriginalLayer.eachLayer(arg1 => {
      if (arg1.getElement) {
        arg1.getElement()?.style.setProperty("pointer-events", "none");
      }
    });
  }
  if (state.flightSimplifiedLayer) {
    state.flightSimplifiedLayer.eachLayer(arg1 => {
      if (arg1.getElement) {
        arg1.getElement()?.style.setProperty("pointer-events", "none");
      }
    });
  }
  const btnEl = document.getElementById("btnDrawCustomRoad");
  const btnEl_1 = document.getElementById("txtDrawRoadBtn");
  const btnEl_2 = document.getElementById("btnPanelDrawRoad");
  const btnEl_3 = document.getElementById("btnFinishDrawRoad");
  const btnEl_4 = document.getElementById("btnCancelDrawRoad");
  if (btnEl_1) {
    btnEl_1.textContent = "Çiziliyor (0 Nokta)...";
  }
  if (btnEl_3) {
    btnEl_3.style.display = "inline-flex";
    btnEl_3.textContent = "✔️ Tamamla";
  }
  if (btnEl_4) {
    btnEl_4.style.display = "inline-flex";
    btnEl_4.classList.remove("hidden");
  }
  if (btnEl) {
    btnEl.style.borderColor = "#f59e0b";
    btnEl.style.background = "rgba(245, 158, 11, 0.25)";
  }
  if (btnEl_2) {
    btnEl_2.style.borderColor = "#f59e0b";
    btnEl_2.style.background = "rgba(245, 158, 11, 0.25)";
  }
  showToast("✏️ Uyduda gördüğünüz toprak yol güzergahına sırayla tıklayın. Bitirmek için Tamamla veya Çift Tık!", "info");
  logMessage("✏️ [YOL ÇİZİMİ] Manuel toprak yol çizim modu aktif. Harita üzerinde güzergaha tıklayınız.");
}
function finishDrawingRoad() {
  if (!state.isDrawingRoad) {
    return;
  }
  if (state.activeRoadPoints.length >= 2) {
    const v_1 = state.activeRoadPoints.map(item => ({
      lat: item[0],
      lon: item[1]
    }));
    const v_2 = "Uydudan Çizilen Arazi Yolu #" + ((state.flightEngine.customDrawnRoads || []).length + 1);
    const v_3 = state.flightEngine.addCustomRoad(v_1, v_2, "custom_track");
    renderRoadNetworkOnMap(state.flightEngine.roadWays);
    if (state.flightEngine.gcpPoints && state.flightEngine.gcpPoints.length > 0) {
      state.flightEngine.gcpPoints.forEach(item => {
        state.flightEngine.recalculatePointRoadDistance(item, 600);
      });
      renderGcpMarkersOnMap(state.flightEngine.gcpPoints);
      renderGcpTable(state.flightEngine.gcpPoints);
    }
    showToast("✅ " + v_1.length + " noktalı toprak yol eklendi! YKN mesafeleri bu yola bağlandı.", "success");
    logMessage("✅ [YOL ÇİZİMİ] " + v_1.length + " noktalı toprak yol kaydedildi. YKN'ler bu yola bağlandı.");
  } else {
    showToast("Yol oluşturmak için haritada en az 2 noktaya tıklamalısınız.", "warning");
  }
  cancelDrawingRoad();
}
function cancelDrawingRoad() {
  state.isDrawingRoad = false;
  state.activeRoadPoints = [];
  if (state.flightMap) {
    state.flightMap.getContainer().style.cursor = "";
    if (state.activeRoadPolyline) {
      state.flightMap.removeLayer(state.activeRoadPolyline);
      state.activeRoadPolyline = null;
    }
    if (state.activeRoadRubberBand) {
      state.flightMap.removeLayer(state.activeRoadRubberBand);
      state.activeRoadRubberBand = null;
    }
    if (state.activeRoadMarkers) {
      state.activeRoadMarkers.forEach(item => state.flightMap.removeLayer(item));
      state.activeRoadMarkers = [];
    }
    if (state.flightGcpLayer) {
      state.flightGcpLayer.eachLayer(arg1 => {
        if (arg1.getElement) {
          arg1.getElement()?.style.removeProperty("pointer-events");
        }
      });
    }
    if (state.flightOriginalLayer) {
      state.flightOriginalLayer.eachLayer(arg1 => {
        if (arg1.getElement) {
          arg1.getElement()?.style.removeProperty("pointer-events");
        }
      });
    }
    if (state.flightSimplifiedLayer) {
      state.flightSimplifiedLayer.eachLayer(arg1 => {
        if (arg1.getElement) {
          arg1.getElement()?.style.removeProperty("pointer-events");
        }
      });
    }
  }
  const btnEl = document.getElementById("btnDrawCustomRoad");
  const btnEl_1 = document.getElementById("txtDrawRoadBtn");
  const btnEl_2 = document.getElementById("btnPanelDrawRoad");
  const btnEl_3 = document.getElementById("btnFinishDrawRoad");
  const btnEl_4 = document.getElementById("btnCancelDrawRoad");
  if (btnEl_1) {
    btnEl_1.textContent = "Yol Çiz";
  }
  if (btnEl_3) {
    btnEl_3.style.display = "none";
    btnEl_3.classList.add("hidden");
  }
  if (btnEl_4) {
    btnEl_4.style.display = "none";
    btnEl_4.classList.add("hidden");
  }
  if (btnEl) {
    btnEl.style.borderColor = "rgba(245, 158, 11, 0.5)";
    btnEl.style.background = "";
  }
  if (btnEl_2) {
    btnEl_2.style.borderColor = "rgba(245, 158, 11, 0.4)";
    btnEl_2.style.background = "";
  }
}
function bindRoadDrawingMapEvents() {
  if (!state.flightMap || state.isRoadDrawingBound) {
    return;
  }
  state.isRoadDrawingBound = true;
  state.flightMap.on("click", arg1 => {
    if (!state.isDrawingRoad) {
      return;
    }
    const items = [arg1.latlng.lat, arg1.latlng.lng];
    state.activeRoadPoints.push(items);
    const v_2 = L.circleMarker(items, {
      radius: 5,
      color: "#f59e0b",
      fillColor: "#ffffff",
      fillOpacity: 1,
      weight: 2.5
    }).addTo(state.flightMap);
    state.activeRoadMarkers.push(v_2);
    if (state.activeRoadPolyline) {
      state.activeRoadPolyline.setLatLngs(state.activeRoadPoints);
    } else {
      state.activeRoadPolyline = L.polyline(state.activeRoadPoints, {
        color: "#f59e0b",
        weight: 3.5,
        dashArray: "6, 4",
        opacity: 0.95
      }).addTo(state.flightMap);
    }
    const btnEl = document.getElementById("txtDrawRoadBtn");
    const btnEl_1 = document.getElementById("btnFinishDrawRoad");
    if (btnEl) {
      btnEl.textContent = "Çiziliyor (" + state.activeRoadPoints.length + " Nokta)...";
    }
    if (btnEl_1) {
      btnEl_1.textContent = "✔️ Tamamla (" + state.activeRoadPoints.length + " Nokta)";
    }
  });
  state.flightMap.on("mousemove", arg1 => {
    if (!state.isDrawingRoad || state.activeRoadPoints.length === 0) {
      return;
    }
    const v_2 = state.activeRoadPoints[state.activeRoadPoints.length - 1];
    const items = [arg1.latlng.lat, arg1.latlng.lng];
    if (state.activeRoadRubberBand) {
      state.activeRoadRubberBand.setLatLngs([v_2, items]);
    } else {
      state.activeRoadRubberBand = L.polyline([v_2, items], {
        color: "#f59e0b",
        weight: 2,
        dashArray: "3, 4",
        opacity: 0.7
      }).addTo(state.flightMap);
    }
  });
  state.flightMap.on("dblclick", arg1 => {
    if (state.isDrawingRoad) {
      L.DomEvent.stopPropagation(arg1);
      finishDrawingRoad();
    }
  });
  document.addEventListener("keydown", event => {
    if (!state.isDrawingRoad) {
      return;
    }
    if (event.key === "Escape") {
      cancelDrawingRoad();
    } else if (event.key === "Enter") {
      finishDrawingRoad();
    }
  });
}
function computeDelaunayEdges(arg1) {
  if (!arg1 || arg1.length < 3) {
    return [];
  }
  const v_2 = arg1.map(item => ({
    id: item.id,
    name: item.name,
    lat: item.lat,
    lon: item.lon,
    x: item.itrfY || item.lon * 100000,
    y: item.itrfX || item.lat * 100000
  }));
  let v_3 = Infinity;
  let v_4 = -Infinity;
  let v_5 = Infinity;
  let v_6 = -Infinity;
  v_2.forEach(item => {
    if (item.x < v_3) {
      v_3 = item.x;
    }
    if (item.x > v_4) {
      v_4 = item.x;
    }
    if (item.y < v_5) {
      v_5 = item.y;
    }
    if (item.y > v_6) {
      v_6 = item.y;
    }
  });
  const v_7 = (v_4 - v_3) * 10;
  const v_8 = (v_6 - v_5) * 10;
  const v_9 = (v_3 + v_4) / 2;
  const v_10 = (v_5 + v_6) / 2;
  const obj = {
    x: v_9 - v_7,
    y: v_10 - v_8,
    isSuper: true
  };
  const obj_1 = {
    x: v_9,
    y: v_10 + v_8 * 2,
    isSuper: true
  };
  const obj_2 = {
    x: v_9 + v_7 * 2,
    y: v_10 - v_8,
    isSuper: true
  };
  let items = [{
    a: obj,
    b: obj_1,
    c: obj_2,
    circle: _getCircumcircle(obj, obj_1, obj_2)
  }];
  for (const v_1 of v_2) {
    const items_2 = [];
    const items_3 = [];
    for (const v_1_1 of items) {
      const v_1_2 = Math.hypot(v_1.x - v_1_1.circle.x, v_1.y - v_1_1.circle.y);
      if (v_1_2 < v_1_1.circle.r) {
        items_3.push(v_1_1);
      }
    }
    for (const v_1_1 of items_3) {
      const items_4 = [[v_1_1.a, v_1_1.b], [v_1_1.b, v_1_1.c], [v_1_1.c, v_1_1.a]];
      for (const v_1_2 of items_4) {
        let flag = false;
        for (const v_1_3 of items_3) {
          if (v_1_3 === v_1_1) {
            continue;
          }
          const items_5 = [[v_1_3.a, v_1_3.b], [v_1_3.b, v_1_3.c], [v_1_3.c, v_1_3.a]];
          if (items_5.some(item => item[0] === v_1_2[0] && item[1] === v_1_2[1] || item[0] === v_1_2[1] && item[1] === v_1_2[0])) {
            flag = true;
            break;
          }
        }
        if (!flag) {
          items_2.push(v_1_2);
        }
      }
    }
    items = items.filter(item => !items_3.includes(item));
    for (const v_1_1 of items_2) {
      const obj_3 = {
        a: v_1_1[0],
        b: v_1_1[1],
        c: v_1
      };
      obj_3.circle = _getCircumcircle(obj_3.a, obj_3.b, obj_3.c);
      items.push(obj_3);
    }
  }
  items = items.filter(item => !item.a.isSuper && !item.b.isSuper && !item.c.isSuper);
  const v_11 = new Set();
  const items_1 = [];
  items.forEach(item => {
    const items_2 = [[item.a, item.b], [item.b, item.c], [item.c, item.a]];
    items_2.forEach(([item_1, item_2]) => {
      const v_1 = item_1.id < item_2.id ? item_1.id + "-" + item_2.id : item_2.id + "-" + item_1.id;
      if (!v_11.has(v_1)) {
        v_11.add(v_1);
        items_1.push([item_1, item_2]);
      }
    });
  });
  return items_1;
}
function _getCircumcircle(arg1, arg2, arg3) {
  const v_4 = (arg1.x * (arg2.y - arg3.y) + arg2.x * (arg3.y - arg1.y) + arg3.x * (arg1.y - arg2.y)) * 2;
  if (Math.abs(v_4) < 1e-7) {
    return {
      x: 0,
      y: 0,
      r: Infinity
    };
  }
  const v_5 = ((arg1.x * arg1.x + arg1.y * arg1.y) * (arg2.y - arg3.y) + (arg2.x * arg2.x + arg2.y * arg2.y) * (arg3.y - arg1.y) + (arg3.x * arg3.x + arg3.y * arg3.y) * (arg1.y - arg2.y)) / v_4;
  const v_6 = ((arg1.x * arg1.x + arg1.y * arg1.y) * (arg3.x - arg2.x) + (arg2.x * arg2.x + arg2.y * arg2.y) * (arg1.x - arg3.x) + (arg3.x * arg3.x + arg3.y * arg3.y) * (arg2.x - arg1.x)) / v_4;
  return {
    x: v_5,
    y: v_6,
    r: Math.hypot(arg1.x - v_5, arg1.y - v_6)
  };
}
function bindPhotogrammetryHandlers() {
  initDroneDatabaseUI();
}
function renderFlightGridOnMap(arg1) {
  if (!state.flightMap) {
    return;
  }
  if (!state.flightLinesLayer) {
    state.flightLinesLayer = L.layerGroup().addTo(state.flightMap);
  }
  if (!state.flightWaypointsLayer) {
    state.flightWaypointsLayer = L.layerGroup().addTo(state.flightMap);
  }
  if (!state.flightHomeLayer) {
    state.flightHomeLayer = L.layerGroup().addTo(state.flightMap);
  }
  if (state.flightCorridorsLayer) {
    state.flightCorridorsLayer.clearLayers();
  }
  state.flightLinesLayer.clearLayers();
  state.flightWaypointsLayer.clearLayers();
  state.flightHomeLayer.clearLayers();
  if (!arg1 || !arg1.lines || arg1.lines.length === 0) {
    return;
  }
  if (arg1.turnArcs && arg1.turnArcs.length > 0) {
    arg1.turnArcs.forEach(item => {
      const v_1 = item.points.map(item_1 => [item_1.lat, item_1.lon || item_1.lng]);
      const v_2 = L.polyline(v_1, {
        color: "#f59e0b",
        weight: 1.8,
        dashArray: "4, 4",
        opacity: 0.75
      });
      state.flightLinesLayer.addLayer(v_2);
    });
  }
  if (arg1.lines && arg1.lines.length > 0) {
    arg1.lines.forEach((item, idx) => {
      const items = [item.start.lat, item.start.lon || item.start.lng];
      const items_1 = [item.end.lat, item.end.lon || item.end.lng];
      const v_1 = L.polyline([items, items_1], {
        color: "#00f2ff",
        weight: 3,
        opacity: 0.95,
        lineCap: "round",
        lineJoin: "round"
      });
      v_1.bindTooltip("<b>✈️ Koridor Hattı #" + (idx + 1) + "</b><br/>Uzunluk: " + item.lengthM + " m<br/>İrtifa: " + arg1.flightAltitudeM + " m AGL", {
        sticky: true
      });
      state.flightLinesLayer.addLayer(v_1);
      const v_2 = (item.start.lat + item.end.lat) / 2;
      const v_3 = ((item.start.lon || item.start.lng) + (item.end.lon || item.end.lng)) / 2;
      const v_4 = item.end.lat - item.start.lat;
      const v_5 = ((item.end.lon || item.end.lng) - (item.start.lon || item.start.lng)) * Math.cos(v_2 * Math.PI / 180);
      let v_6 = Math.atan2(v_5, v_4) * (180 / Math.PI);
      if (v_6 < 0) {
        v_6 += 360;
      }
      const v_7 = L.divIcon({
        className: "flight-dir-arrow-icon",
        html: "<div style=\"transform: rotate(" + v_6.toFixed(0) + "deg); color: #00f2ff; font-size: 11px; text-shadow: 0 0 5px rgba(0,242,255,0.9); display: flex; align-items: center; justify-content: center;\"><i class=\"fa-solid fa-chevron-up\"></i></div>",
        iconSize: [14, 14],
        iconAnchor: [7, 7]
      });
      const v_8 = L.marker([v_2, v_3], {
        icon: v_7,
        interactive: false
      });
      state.flightLinesLayer.addLayer(v_8);
    });
  }
  if (arg1.waypoints && arg1.waypoints.length > 0) {
    const v_1 = arg1.waypoints.length;
    const v_2 = v_1 > 350 ? Math.ceil(v_1 / 350) : 1;
    for (let num = 0; num < v_1; num += v_2) {
      const v_1_1 = arg1.waypoints[num];
      const v_2_1 = L.circleMarker([v_1_1.lat, v_1_1.lon || v_1_1.lng], {
        radius: 2.2,
        color: "#fbbf24",
        fillColor: "#fbbf24",
        fillOpacity: 0.9,
        weight: 1
      });
      state.flightWaypointsLayer.addLayer(v_2_1);
    }
  }
  if (arg1.homePoint) {
    const v_1 = arg1.homePoint;
    const items = [v_1.lat, v_1.lon || v_1.lng];
    const v_2 = v_1.isRoadSnapped;
    const v_3 = L.divIcon({
      className: "flight-home-icon",
      html: "<div style=\"width: 24px; height: 24px; border-radius: 50%; background: " + (v_2 ? "#10b981" : "#f59e0b") + "; border: 2px solid #ffffff; box-shadow: 0 0 10px " + (v_2 ? "rgba(16, 185, 129, 0.9)" : "rgba(245, 158, 11, 0.9)") + "; display: flex; align-items: center; justify-content: center; color: #ffffff; font-size: 11px; font-weight: 900; font-family: var(--font-display);\">H</div>",
      iconSize: [24, 24],
      iconAnchor: [12, 12]
    });
    const v_4 = L.marker(items, {
      icon: v_3
    });
    v_4.bindPopup("<b>🚀 Önerilen Kalkış/İniş Noktası (Home)</b><br/>" + (v_2 ? "🛣️ En Yakın Yola Hizalandı (" + v_1.distanceM + "m mesafede)" : "Uçuş Başlangıç Konumu") + "<br/><b>WGS-84:</b> " + v_1.lat.toFixed(6) + ", " + (v_1.lon || v_1.lng).toFixed(6));
    state.flightHomeLayer.addLayer(v_4);
    if (arg1.lines.length > 0) {
      const items_1 = [arg1.lines[0].start.lat, arg1.lines[0].start.lon || arg1.lines[0].start.lng];
      const v_1_1 = L.polyline([items, items_1], {
        color: v_2 ? "#10b981" : "#f59e0b",
        weight: 1.5,
        dashArray: "4, 5",
        opacity: 0.8
      });
      state.flightHomeLayer.addLayer(v_1_1);
      const v_2_1 = arg1.lines[arg1.lines.length - 1];
      const items_2 = [v_2_1.end.lat, v_2_1.end.lon || v_2_1.end.lng];
      const v_3_1 = L.polyline([items_2, items], {
        color: v_2 ? "#10b981" : "#f59e0b",
        weight: 1.5,
        dashArray: "4, 5",
        opacity: 0.8
      });
      state.flightHomeLayer.addLayer(v_3_1);
    }
  }
}